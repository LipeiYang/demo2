require 'test_helper'

class PayablesHelperTest < ActionView::TestCase
end
