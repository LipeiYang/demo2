require 'test_helper'

class InvestsHelperTest < ActionView::TestCase
end
