require 'test_helper'

class CostItemsHelperTest < ActionView::TestCase
end
