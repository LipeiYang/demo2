module InvestsHelper
end
