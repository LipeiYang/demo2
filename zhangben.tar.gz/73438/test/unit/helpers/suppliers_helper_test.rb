require 'test_helper'

class SuppliersHelperTest < ActionView::TestCase
end
