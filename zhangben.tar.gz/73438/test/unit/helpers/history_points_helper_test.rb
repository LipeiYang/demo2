require 'test_helper'

class HistoryPointsHelperTest < ActionView::TestCase
end
