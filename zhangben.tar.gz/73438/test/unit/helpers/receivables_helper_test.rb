require 'test_helper'

class ReceivablesHelperTest < ActionView::TestCase
end
