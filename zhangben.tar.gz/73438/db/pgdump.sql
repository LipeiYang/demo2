--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: leaf_000000; Type: SCHEMA; Schema: -; Owner: oeulrfrvfh
--

CREATE SCHEMA leaf_000000;


ALTER SCHEMA leaf_000000 OWNER TO oeulrfrvfh;

--
-- Name: leaf_057788813958; Type: SCHEMA; Schema: -; Owner: oeulrfrvfh
--

CREATE SCHEMA leaf_057788813958;


ALTER SCHEMA leaf_057788813958 OWNER TO oeulrfrvfh;

SET search_path = leaf_000000, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: customers; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE customers (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_000000.customers OWNER TO oeulrfrvfh;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.customers_id_seq OWNER TO oeulrfrvfh;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE customers_id_seq OWNED BY customers.id;


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('customers_id_seq', 1, false);


--
-- Name: orders; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE orders (
    id integer NOT NULL,
    date date,
    price double precision DEFAULT 0.0,
    volume double precision DEFAULT 0.0,
    manfee double precision DEFAULT 0.0,
    customer_id integer,
    product_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_paied character varying(255),
    seq_no integer
);


ALTER TABLE leaf_000000.orders OWNER TO oeulrfrvfh;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.orders_id_seq OWNER TO oeulrfrvfh;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE orders_id_seq OWNED BY orders.id;


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('orders_id_seq', 1, false);


--
-- Name: products; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE products (
    id integer NOT NULL,
    name character varying(255),
    price double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_000000.products OWNER TO oeulrfrvfh;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.products_id_seq OWNER TO oeulrfrvfh;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE products_id_seq OWNED BY products.id;


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('products_id_seq', 1, false);


--
-- Name: purchases; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE purchases (
    id integer NOT NULL,
    date date,
    product_id integer,
    price double precision DEFAULT 0.0,
    volume double precision DEFAULT 0.0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    seq_no integer
);


ALTER TABLE leaf_000000.purchases OWNER TO oeulrfrvfh;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.purchases_id_seq OWNER TO oeulrfrvfh;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE purchases_id_seq OWNED BY purchases.id;


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('purchases_id_seq', 1, false);


--
-- Name: receivables; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE receivables (
    id integer NOT NULL,
    seq_no integer,
    date date,
    customer_id integer,
    amount double precision DEFAULT 0.0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_000000.receivables OWNER TO oeulrfrvfh;

--
-- Name: receivables_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE receivables_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.receivables_id_seq OWNER TO oeulrfrvfh;

--
-- Name: receivables_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE receivables_id_seq OWNED BY receivables.id;


--
-- Name: receivables_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('receivables_id_seq', 1, false);


--
-- Name: schema_migrations; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE leaf_000000.schema_migrations OWNER TO oeulrfrvfh;

--
-- Name: suppliers; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE suppliers (
    id integer NOT NULL,
    seq_no integer,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_000000.suppliers OWNER TO oeulrfrvfh;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.suppliers_id_seq OWNER TO oeulrfrvfh;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE suppliers_id_seq OWNED BY suppliers.id;


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('suppliers_id_seq', 1, false);


--
-- Name: users; Type: TABLE; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(255),
    crypted_password character varying(255),
    password_salt character varying(255),
    persistence_token character varying(255),
    name character varying(255),
    address character varying(255),
    email character varying(255),
    telephone character varying(255),
    cell_phone character varying(255),
    id_no character varying(255),
    business_no character varying(255),
    company character varying(255),
    addtional text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_000000.users OWNER TO oeulrfrvfh;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: leaf_000000; Owner: oeulrfrvfh
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_000000.users_id_seq OWNER TO oeulrfrvfh;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: leaf_000000; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('users_id_seq', 1, false);


SET search_path = leaf_057788813958, pg_catalog;

--
-- Name: customers; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE customers (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_057788813958.customers OWNER TO oeulrfrvfh;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE customers_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.customers_id_seq OWNER TO oeulrfrvfh;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE customers_id_seq OWNED BY customers.id;


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('customers_id_seq', 34, true);


--
-- Name: orders; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE orders (
    id integer NOT NULL,
    date date,
    price double precision DEFAULT 0.0,
    volume double precision DEFAULT 0.0,
    manfee double precision DEFAULT 0.0,
    customer_id integer,
    product_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_paied character varying(255),
    seq_no integer
);


ALTER TABLE leaf_057788813958.orders OWNER TO oeulrfrvfh;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE orders_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.orders_id_seq OWNER TO oeulrfrvfh;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE orders_id_seq OWNED BY orders.id;


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('orders_id_seq', 575, true);


--
-- Name: products; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE products (
    id integer NOT NULL,
    name character varying(255),
    price double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_057788813958.products OWNER TO oeulrfrvfh;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE products_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.products_id_seq OWNER TO oeulrfrvfh;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE products_id_seq OWNED BY products.id;


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('products_id_seq', 25, true);


--
-- Name: purchases; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE purchases (
    id integer NOT NULL,
    date date,
    product_id integer,
    price double precision DEFAULT 0.0,
    volume double precision DEFAULT 0.0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    seq_no integer
);


ALTER TABLE leaf_057788813958.purchases OWNER TO oeulrfrvfh;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE purchases_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.purchases_id_seq OWNER TO oeulrfrvfh;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE purchases_id_seq OWNED BY purchases.id;


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('purchases_id_seq', 83, true);


--
-- Name: receivables; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE receivables (
    id integer NOT NULL,
    seq_no integer,
    date date,
    customer_id integer,
    amount double precision DEFAULT 0.0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_057788813958.receivables OWNER TO oeulrfrvfh;

--
-- Name: receivables_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE receivables_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.receivables_id_seq OWNER TO oeulrfrvfh;

--
-- Name: receivables_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE receivables_id_seq OWNED BY receivables.id;


--
-- Name: receivables_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('receivables_id_seq', 29, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE leaf_057788813958.schema_migrations OWNER TO oeulrfrvfh;

--
-- Name: suppliers; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE suppliers (
    id integer NOT NULL,
    seq_no integer,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_057788813958.suppliers OWNER TO oeulrfrvfh;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.suppliers_id_seq OWNER TO oeulrfrvfh;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE suppliers_id_seq OWNED BY suppliers.id;


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('suppliers_id_seq', 1, false);


--
-- Name: users; Type: TABLE; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(255),
    crypted_password character varying(255),
    password_salt character varying(255),
    persistence_token character varying(255),
    name character varying(255),
    address character varying(255),
    email character varying(255),
    telephone character varying(255),
    cell_phone character varying(255),
    id_no character varying(255),
    business_no character varying(255),
    company character varying(255),
    addtional text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE leaf_057788813958.users OWNER TO oeulrfrvfh;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE leaf_057788813958.users_id_seq OWNER TO oeulrfrvfh;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('users_id_seq', 1, false);


SET search_path = public, pg_catalog;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE customers (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.customers OWNER TO oeulrfrvfh;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE customers_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO oeulrfrvfh;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE customers_id_seq OWNED BY customers.id;


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('customers_id_seq', 34, true);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE orders (
    id integer NOT NULL,
    date date,
    price double precision DEFAULT 0.0,
    volume double precision DEFAULT 0.0,
    manfee double precision DEFAULT 0.0,
    customer_id integer,
    product_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_paied character varying(255),
    seq_no integer
);


ALTER TABLE public.orders OWNER TO oeulrfrvfh;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE orders_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO oeulrfrvfh;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE orders_id_seq OWNED BY orders.id;


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('orders_id_seq', 554, true);


--
-- Name: products; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE products (
    id integer NOT NULL,
    name character varying(255),
    price double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.products OWNER TO oeulrfrvfh;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE products_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO oeulrfrvfh;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE products_id_seq OWNED BY products.id;


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('products_id_seq', 25, true);


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE purchases (
    id integer NOT NULL,
    date date,
    product_id integer,
    price double precision DEFAULT 0,
    volume double precision DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    seq_no integer
);


ALTER TABLE public.purchases OWNER TO oeulrfrvfh;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE purchases_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.purchases_id_seq OWNER TO oeulrfrvfh;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE purchases_id_seq OWNED BY purchases.id;


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('purchases_id_seq', 82, true);


--
-- Name: receivables; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE receivables (
    id integer NOT NULL,
    seq_no integer,
    date date,
    customer_id integer,
    amount double precision DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.receivables OWNER TO oeulrfrvfh;

--
-- Name: receivables_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE receivables_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.receivables_id_seq OWNER TO oeulrfrvfh;

--
-- Name: receivables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE receivables_id_seq OWNED BY receivables.id;


--
-- Name: receivables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('receivables_id_seq', 29, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO oeulrfrvfh;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE suppliers (
    id integer NOT NULL,
    seq_no integer,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.suppliers OWNER TO oeulrfrvfh;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.suppliers_id_seq OWNER TO oeulrfrvfh;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE suppliers_id_seq OWNED BY suppliers.id;


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('suppliers_id_seq', 1, false);


--
-- Name: users; Type: TABLE; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(255),
    email character varying(255),
    crypted_password character varying(255),
    password_salt character varying(255),
    persistence_token character varying(255),
    name character varying(255),
    address character varying(255),
    telephone character varying(255),
    cell_phone character varying(255),
    id_no character varying(255),
    business_no character varying(255),
    company character varying(255),
    addtional text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO oeulrfrvfh;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: oeulrfrvfh
--

CREATE SEQUENCE users_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO oeulrfrvfh;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oeulrfrvfh
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oeulrfrvfh
--

SELECT pg_catalog.setval('users_id_seq', 2, true);


SET search_path = leaf_000000, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE customers ALTER COLUMN id SET DEFAULT nextval('customers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE orders ALTER COLUMN id SET DEFAULT nextval('orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE products ALTER COLUMN id SET DEFAULT nextval('products_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE purchases ALTER COLUMN id SET DEFAULT nextval('purchases_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE receivables ALTER COLUMN id SET DEFAULT nextval('receivables_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE suppliers ALTER COLUMN id SET DEFAULT nextval('suppliers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_000000; Owner: oeulrfrvfh
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


SET search_path = leaf_057788813958, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE customers ALTER COLUMN id SET DEFAULT nextval('customers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE orders ALTER COLUMN id SET DEFAULT nextval('orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE products ALTER COLUMN id SET DEFAULT nextval('products_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE purchases ALTER COLUMN id SET DEFAULT nextval('purchases_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE receivables ALTER COLUMN id SET DEFAULT nextval('receivables_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE suppliers ALTER COLUMN id SET DEFAULT nextval('suppliers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


SET search_path = public, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE customers ALTER COLUMN id SET DEFAULT nextval('customers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE orders ALTER COLUMN id SET DEFAULT nextval('orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE products ALTER COLUMN id SET DEFAULT nextval('products_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE purchases ALTER COLUMN id SET DEFAULT nextval('purchases_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE receivables ALTER COLUMN id SET DEFAULT nextval('receivables_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE suppliers ALTER COLUMN id SET DEFAULT nextval('suppliers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: oeulrfrvfh
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


SET search_path = leaf_000000, pg_catalog;

--
-- Data for Name: customers; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY customers (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY orders (id, date, price, volume, manfee, customer_id, product_id, created_at, updated_at, is_paied, seq_no) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY products (id, name, price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY purchases (id, date, product_id, price, volume, created_at, updated_at, seq_no) FROM stdin;
\.


--
-- Data for Name: receivables; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY receivables (id, seq_no, date, customer_id, amount, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY schema_migrations (version) FROM stdin;
20100826132305
20100703101301
20100705150624
20100705151124
20100705151548
20100707144524
20100707144821
20100710084758
20100710085040
20100711152631
20100715141845
20100719163739
20100801142229
20100801160437
20100814143227
20100819142530
20100820173049
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY suppliers (id, seq_no, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: leaf_000000; Owner: oeulrfrvfh
--

COPY users (id, username, crypted_password, password_salt, persistence_token, name, address, email, telephone, cell_phone, id_no, business_no, company, addtional, created_at, updated_at) FROM stdin;
\.


SET search_path = leaf_057788813958, pg_catalog;

--
-- Data for Name: customers; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY customers (id, name, created_at, updated_at) FROM stdin;
2	阿浩	2010-07-11 13:18:25.953046	2010-07-11 13:18:25.953046
3	克和	2010-07-11 15:43:43.934748	2010-07-11 15:43:43.934748
4	小宝	2010-07-12 12:28:23.384988	2010-07-12 12:28:23.384988
5	晓秋	2010-07-12 12:30:18.215332	2010-07-12 12:30:18.215332
6	阿松	2010-07-12 12:32:28.70216	2010-07-12 12:32:28.70216
7	五金厂	2010-07-12 12:35:10.372226	2010-07-12 12:35:10.372226
8	万里	2010-07-12 12:38:54.343754	2010-07-12 12:38:54.343754
9	畅旺	2010-07-15 12:23:32.534134	2010-07-15 12:23:32.534134
10	阿杰	2010-07-15 12:24:01.685021	2010-07-15 12:24:01.685021
11	李义	2010-07-15 12:24:43.931687	2010-07-15 12:24:43.931687
12	珍飞	2010-07-15 12:25:03.313239	2010-07-15 12:25:03.313239
13	阿志	2010-07-15 12:25:18.555094	2010-07-15 12:25:18.555094
14	阿雨	2010-07-15 12:25:39.521204	2010-07-15 12:25:39.521204
15	剑波	2010-07-15 12:25:59.757387	2010-07-15 12:25:59.757387
16	章才	2010-07-15 12:26:29.615089	2010-07-15 12:26:29.615089
17	江伟	2010-07-15 12:26:46.780314	2010-07-15 12:26:46.780314
18	吴阿克	2010-07-15 12:27:18.167061	2010-07-15 12:27:18.167061
19	阿寿	2010-07-15 12:27:45.39133	2010-07-15 12:27:45.39133
20	金鹿	2010-07-15 12:31:36.922785	2010-07-15 12:31:36.922785
21	阿进	2010-07-15 12:41:33.285822	2010-07-15 12:41:33.285822
22	金阿锐	2010-07-15 13:00:03.541786	2010-07-15 13:00:03.541786
23	阿海	2010-07-16 12:49:43.345227	2010-07-16 12:49:43.345227
24	阿鸿	2010-07-20 13:06:41.015066	2010-07-20 13:06:41.015066
25	阿微	2010-07-20 13:11:05.360023	2010-07-20 13:11:05.360023
26	阿隆	2010-07-21 13:29:30.28039	2010-07-21 13:29:30.28039
1	未定	2010-07-09 17:56:36.551537	2010-07-21 15:32:18.230204
27	再年	2010-07-25 13:43:44.096266	2010-07-25 13:43:44.096266
28	昌旺	2010-07-25 13:44:12.558854	2010-07-25 13:44:12.558854
29	南塘	2010-07-27 13:20:29.345442	2010-07-27 13:20:29.345442
30	阿武	2010-07-27 13:21:42.312487	2010-07-27 13:21:42.312487
31	阿权	2010-07-30 14:43:28.18268	2010-07-30 14:43:28.18268
32	厂里	2010-08-01 11:37:51.934905	2010-08-01 11:37:51.934905
33	下垟头	2010-08-10 13:52:17.26306	2010-08-10 13:52:17.26306
34	车床	2010-08-10 13:52:39.320233	2010-08-10 13:52:39.320233
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY orders (id, date, price, volume, manfee, customer_id, product_id, created_at, updated_at, is_paied, seq_no) FROM stdin;
21	2010-07-13	5.2000000000000002	31.600000000000001	0	1	2	2010-07-15 11:01:06.915946	2010-07-15 15:45:50.598611	yes	21
30	2010-07-13	17	4.5	20	20	3	2010-07-15 11:55:33.65578	2010-07-15 15:45:50.628448	no	30
25	2010-07-13	10	10.5	2	1	10	2010-07-15 11:40:13.680668	2010-07-15 15:45:50.756758	yes	25
58	2010-07-16	10	0.90000000000000002	1	1	10	2010-07-16 12:20:28.435942	2010-07-16 12:20:28.435942	yes	58
59	2010-07-16	4.7000000000000002	3.5	4	3	1	2010-07-16 12:22:53.793868	2010-07-16 12:22:53.793868	no	59
68	2010-07-17	5.2000000000000002	13	4	1	2	2010-07-17 11:40:36.418675	2010-07-17 11:40:36.418675	yes	68
56	2010-07-16	1.8200000000000001	169	0	1	13	2010-07-16 11:32:25.111047	2010-08-10 14:04:35.010778	yes	55
90	2010-07-19	17	20	0	1	18	2010-07-19 11:53:19.566183	2010-07-22 14:43:51.665771	yes	90
4	2010-07-11	5.2000000000000002	5.2999999999999998	4	2	2	2010-07-11 15:38:09.637231	2010-07-15 15:45:50.489803	no	4
5	2010-07-11	0	0	8	1	6	2010-07-11 15:38:39.347547	2010-07-15 15:45:50.492893	yes	5
6	2010-07-11	5.2000000000000002	12.800000000000001	0	1	2	2010-07-11 15:39:15.133765	2010-07-15 15:45:50.495814	yes	6
7	2010-07-11	8.5	1.3999999999999999	0	2	5	2010-07-11 15:40:04.328334	2010-07-15 15:45:50.522733	no	7
8	2010-07-11	5.2000000000000002	2.8999999999999999	4	2	2	2010-07-11 15:42:24.34378	2010-07-15 15:45:50.555465	no	8
9	2010-07-11	5.2000000000000002	8.6999999999999993	40	3	2	2010-07-11 15:44:51.942291	2010-07-15 15:45:50.559147	no	9
10	2010-07-11	4.7999999999999998	22.600000000000001	40	3	1	2010-07-11 15:45:12.586204	2010-07-15 15:45:50.561876	no	10
11	2010-07-12	14	0.29999999999999999	2	4	3	2010-07-12 12:29:26.554782	2010-07-15 15:45:50.564516	no	11
12	2010-07-12	0	0	2	1	6	2010-07-12 12:29:47.409461	2010-07-15 15:45:50.56701	yes	12
13	2010-07-12	7.5	2.2000000000000002	2	5	7	2010-07-12 12:32:13.230979	2010-07-15 15:45:50.569767	no	13
14	2010-07-12	5.2000000000000002	31.800000000000001	88	6	2	2010-07-12 12:33:01.638524	2010-07-15 15:45:50.582389	no	14
15	2010-07-12	40	14.5	32	3	8	2010-07-12 12:34:29.486664	2010-07-15 15:45:50.585388	no	15
16	2010-07-12	8.5	1.3	0	7	5	2010-07-12 12:35:54.130841	2010-07-15 15:45:50.588034	no	16
17	2010-07-12	11	0.59999999999999998	0	7	3	2010-07-12 12:36:25.305233	2010-07-15 15:45:50.590604	no	17
18	2010-07-12	5.2000000000000002	2.7000000000000002	12	7	2	2010-07-12 12:37:06.816657	2010-07-15 15:45:50.59352	no	18
19	2010-07-12	10	52	52	8	9	2010-07-12 12:39:15.217089	2010-07-15 15:45:50.595893	no	19
24	2010-07-13	4.9000000000000004	7.7000000000000002	105	1	1	2010-07-15 11:34:16.401978	2010-07-15 15:45:50.601214	yes	24
26	2010-07-13	0	0	2	1	1	2010-07-15 11:41:48.856272	2010-07-15 15:45:50.603727	yes	26
27	2010-07-13	5.2000000000000002	10.199999999999999	2	1	2	2010-07-15 11:44:35.954593	2010-07-15 15:45:50.606221	yes	27
31	2010-07-14	14	1.8	2	7	3	2010-07-15 11:59:25.486618	2010-07-15 15:45:50.608896	no	31
32	2010-07-14	5.2000000000000002	5	20	1	2	2010-07-15 12:01:46.99885	2010-07-15 15:45:50.611284	yes	32
33	2010-07-14	5.2000000000000002	3.6000000000000001	2	3	2	2010-07-15 12:05:46.921082	2010-07-15 15:45:50.613756	no	33
35	2010-07-14	0	0	2	3	1	2010-07-15 12:10:16.771947	2010-07-15 15:45:50.616144	no	35
36	2010-07-14	0	0	2	3	1	2010-07-15 12:10:27.087533	2010-07-15 15:45:50.618531	no	36
38	2010-07-14	4.7999999999999998	76.5	64	3	1	2010-07-15 12:17:54.619593	2010-07-15 15:45:50.621091	no	38
28	2010-07-13	5	7.5999999999999996	0	20	1	2010-07-15 11:50:14.873128	2010-07-15 15:45:50.623661	no	28
29	2010-07-13	5.2000000000000002	5.7000000000000002	0	20	2	2010-07-15 11:53:04.706567	2010-07-15 15:45:50.626043	no	29
34	2010-07-14	5.2000000000000002	5.5	0	21	1	2010-07-15 12:08:33.126895	2010-07-15 15:45:50.644885	no	34
37	2010-07-14	7	25	16	19	2	2010-07-15 12:12:49.349374	2010-07-15 15:45:50.647483	no	37
39	2010-07-14	17	2.3999999999999999	0	1	3	2010-07-15 12:48:38.641015	2010-07-15 15:45:50.649876	yes	39
40	2010-07-14	5.2000000000000002	4.5	14	1	2	2010-07-15 12:51:43.063663	2010-07-15 15:45:50.652345	yes	40
41	2010-07-14	4.9000000000000004	7	26	3	2	2010-07-15 12:54:29.020323	2010-07-15 15:45:50.654831	no	41
42	2010-07-15	8	198.80000000000001	182	11	4	2010-07-15 12:56:50.150974	2010-07-15 15:45:50.657477	no	42
43	2010-07-15	5.5	2.2999999999999998	4	22	2	2010-07-15 13:02:55.199161	2010-07-15 15:45:50.659933	no	43
44	2010-07-15	8	59	78	11	9	2010-07-15 13:06:26.965453	2010-07-15 15:45:50.666482	no	44
45	2010-07-15	7	34.5	0	11	2	2010-07-15 13:07:53.717127	2010-07-15 15:45:50.670683	no	45
46	2010-07-15	4.7000000000000002	37.399999999999999	76	3	1	2010-07-15 13:09:56.480995	2010-07-15 15:45:50.731826	no	46
47	2010-07-15	4.9000000000000004	10.800000000000001	0	3	2	2010-07-15 13:11:39.345955	2010-07-15 15:45:50.734975	no	47
48	2010-07-15	11	7.2000000000000002	16	1	3	2010-07-15 13:14:08.705064	2010-07-15 15:45:50.738072	yes	48
49	2010-07-15	5.2000000000000002	11.199999999999999	0	1	2	2010-07-15 13:15:47.462751	2010-07-15 15:45:50.741062	yes	49
50	2010-07-15	7.5	26.5	16	22	7	2010-07-15 13:18:39.636266	2010-07-15 15:45:50.743582	no	50
51	2010-07-15	5.2000000000000002	29.100000000000001	18	2	2	2010-07-15 13:20:44.698874	2010-07-15 15:45:50.746389	no	51
52	2010-07-15	14	0.59999999999999998	0	2	3	2010-07-15 13:22:11.412935	2010-07-15 15:45:50.749101	no	52
53	2010-07-15	5.2000000000000002	0.90000000000000002	6	2	2	2010-07-15 13:23:35.89838	2010-07-15 15:45:50.751721	no	53
69	2010-07-17	5.2000000000000002	1.8999999999999999	4	1	2	2010-07-17 11:42:27.897481	2010-07-17 11:42:27.897481	yes	69
60	2010-07-16	10	2.5	8	1	10	2010-07-16 12:25:11.271359	2010-07-16 12:25:11.271359	yes	60
61	2010-07-16	4.7999999999999998	9.6999999999999993	8	19	1	2010-07-16 12:31:18.464917	2010-07-16 12:31:18.464917	no	61
63	2010-07-16	5.2000000000000002	13.699999999999999	6	1	2	2010-07-16 12:34:21.48438	2010-07-16 12:34:21.48438	yes	63
64	2010-07-16	4.7999999999999998	3.7999999999999998	4	2	1	2010-07-16 12:36:09.874038	2010-07-16 12:36:09.874038	no	64
65	2010-07-16	8	56.5	52	11	9	2010-07-16 12:38:03.594085	2010-07-16 12:38:03.594085	no	65
66	2010-07-16	5.2000000000000002	1	0	1	2	2010-07-16 12:39:37.172827	2010-07-16 12:39:37.172827	yes	66
62	2010-07-16	0	0	4	3	6	2010-07-16 12:32:44.934092	2010-07-16 12:43:16.236372	no	62
57	2010-07-16	140	2.2000000000000002	0	23	3	2010-07-16 11:35:41.170341	2010-07-16 12:50:02.492282	no	57
67	2010-07-17	5.2000000000000002	1.7	4	1	2	2010-07-17 11:38:53.190674	2010-07-17 11:38:53.190674	yes	67
70	2010-07-17	4.7000000000000002	27.800000000000001	0	3	1	2010-07-17 11:45:33.173536	2010-07-17 11:45:33.173536	no	70
71	2010-07-17	4.9000000000000004	13.5	72	3	2	2010-07-17 11:47:12.698409	2010-07-17 11:47:12.698409	no	71
72	2010-07-17	5	35.200000000000003	32	19	1	2010-07-17 11:49:49.492529	2010-07-17 11:49:49.492529	no	72
73	2010-07-17	14	0.5	1	1	3	2010-07-17 11:52:01.208886	2010-07-17 11:52:01.208886	yes	73
74	2010-07-17	0	0	75	19	6	2010-07-17 11:53:21.476606	2010-07-17 11:53:21.476606	no	74
75	2010-07-17	14	1.6000000000000001	12	14	3	2010-07-17 11:55:06.023232	2010-07-17 11:55:06.023232	no	75
76	2010-07-17	5.2000000000000002	5	15	1	2	2010-07-17 11:56:41.806204	2010-07-17 11:56:41.806204	yes	76
77	2010-07-17	5.2000000000000002	2.1000000000000001	0	1	2	2010-07-17 11:58:05.048933	2010-07-17 11:58:05.048933	yes	77
78	2010-07-18	14	1.2	2	1	3	2010-07-18 11:03:46.63723	2010-07-18 11:03:46.63723	yes	78
79	2010-07-18	4.9000000000000004	3.2999999999999998	0	3	2	2010-07-18 11:06:33.317829	2010-07-18 11:06:33.317829	no	79
80	2010-07-18	4.7000000000000002	17.800000000000001	36	3	1	2010-07-18 11:08:24.445236	2010-07-18 11:08:24.445236	no	80
81	2010-07-18	7.5	40	21	19	7	2010-07-18 11:10:30.226732	2010-07-18 11:10:30.226732	no	81
82	2010-07-18	5.5	3.7999999999999998	8	1	2	2010-07-18 11:13:43.388902	2010-07-18 11:13:43.388902	yes	82
83	2010-07-18	5	7.0999999999999996	20	1	1	2010-07-18 11:15:18.365798	2010-07-18 11:15:18.365798	yes	83
85	2010-07-18	5.2000000000000002	10.5	16	1	2	2010-07-18 11:19:17.877514	2010-07-18 11:19:17.877514	yes	85
86	2010-07-19	4.9000000000000004	8	0	3	2	2010-07-19 11:45:07.778513	2010-07-19 11:45:07.778513	no	86
87	2010-07-19	4.7000000000000002	12.6	48	3	1	2010-07-19 11:47:07.972137	2010-07-19 11:47:07.972137	no	87
88	2010-07-19	4.7999999999999998	279	77	14	1	2010-07-19 11:49:43.266239	2010-07-19 11:49:43.266239	no	88
89	2010-07-19	5.2000000000000002	8.5999999999999996	6	1	2	2010-07-19 11:51:33.359448	2010-07-19 11:51:33.359448	yes	89
91	2010-07-19	5.2000000000000002	30	55	1	2	2010-07-19 11:55:11.892785	2010-07-19 11:55:11.892785	yes	91
3	2010-07-11	5.2000000000000002	5.7000000000000002	8	2	14	2010-07-11 15:37:32.771432	2010-07-21 13:46:56.383335	no	3
54	2010-07-15	0	0	8	3	6	2010-07-15 13:24:49.400087	2010-07-23 16:41:29.76867	no	54
92	2010-07-19	5.2000000000000002	8.5999999999999996	6	2	2	2010-07-19 11:58:33.90635	2010-07-19 11:58:33.90635	no	92
93	2010-07-19	14	0.59999999999999998	10	14	3	2010-07-19 12:01:18.401119	2010-07-19 12:01:18.401119	no	93
94	2010-07-19	8	68	52	11	9	2010-07-19 12:03:55.305949	2010-07-19 12:03:55.305949	no	94
95	2010-07-19	5	4.5999999999999996	6	1	1	2010-07-19 12:06:13.574153	2010-07-19 12:06:13.574153	yes	95
97	2010-07-20	5	3.3999999999999999	4	7	1	2010-07-20 12:07:20.68926	2010-07-20 12:07:20.68926	no	97
102	2010-07-20	4.7000000000000002	17	48	3	1	2010-07-20 12:56:34.416414	2010-07-20 12:56:34.416414	no	102
104	2010-07-20	4.7999999999999998	0.69999999999999996	2	1	1	2010-07-20 13:01:39.936239	2010-07-20 13:01:39.936239	yes	104
105	2010-07-20	8	65	52	11	9	2010-07-20 13:03:25.293929	2010-07-20 13:03:25.293929	no	105
147	2010-07-24	8.5	0.65000000000000002	0	1	5	2010-07-24 14:26:09.208179	2010-07-24 14:26:09.208179	yes	147
84	2010-07-18	5.2000000000000002	261.39999999999998	165	25	2	2010-07-18 11:17:35.538997	2010-07-20 13:11:35.856418	no	84
149	2010-07-24	5.2000000000000002	78	98	1	2	2010-07-24 14:30:40.248867	2010-07-24 14:30:40.248867	yes	149
150	2010-07-24	5.2000000000000002	17.800000000000001	24	19	2	2010-07-24 14:33:07.816538	2010-07-24 14:33:07.816538	no	150
108	2010-07-21	0	0	8	1	6	2010-07-21 13:18:16.485317	2010-07-21 13:18:16.485317	yes	108
109	2010-07-21	8	55.5	52	11	4	2010-07-21 13:21:45.521074	2010-07-21 13:21:45.521074	no	109
110	2010-07-21	0	0	4	1	6	2010-07-21 13:23:02.922925	2010-07-21 13:23:02.922925	yes	110
111	2010-07-21	5.2000000000000002	10.6	8	1	14	2010-07-21 13:26:19.086767	2010-07-21 13:26:19.086767	yes	111
112	2010-07-21	5.2000000000000002	4.9000000000000004	24	26	14	2010-07-21 13:28:58.87892	2010-07-21 13:29:58.941128	yes	112
113	2010-07-21	5.2000000000000002	44.5	16	22	14	2010-07-21 13:32:09.787488	2010-07-21 13:32:09.787488	no	113
115	2010-07-22	4.7000000000000002	26.899999999999999	46	3	1	2010-07-22 13:04:32.577606	2010-07-22 13:04:32.577606	no	115
118	2010-07-22	5.2000000000000002	19.300000000000001	16	2	14	2010-07-22 13:08:10.492781	2010-07-22 13:08:10.492781	no	116
120	2010-07-22	4.7000000000000002	26.800000000000001	72	3	1	2010-07-22 13:12:30.518328	2010-07-22 13:12:30.518328	no	120
122	2010-07-22	0	0	8	14	6	2010-07-22 13:19:23.806625	2010-07-22 13:19:23.806625	no	122
124	2010-07-22	17	27.5	36	7	18	2010-07-22 13:22:14.576997	2010-07-22 13:22:14.576997	no	123
151	2010-07-24	9	79	104	1	4	2010-07-24 14:34:52.585356	2010-07-24 14:34:52.585356	yes	151
152	2010-07-24	5	6.75	4	1	22	2010-07-24 14:37:18.078209	2010-07-24 14:37:18.078209	yes	152
128	2010-07-22	14	0.41999999999999998	15	7	3	2010-07-22 13:42:40.342032	2010-07-22 13:42:40.342032	no	128
129	2010-07-22	5.2000000000000002	1.3999999999999999	0	7	1	2010-07-22 13:44:08.766441	2010-07-22 13:44:08.766441	no	129
153	2010-07-24	10	1	0	3	19	2010-07-24 14:39:03.050288	2010-07-24 14:39:03.050288	no	153
154	2010-07-24	5.2000000000000002	21.699999999999999	54	7	2	2010-07-24 14:40:51.135472	2010-07-24 14:40:51.135472	no	154
130	2010-07-22	10	4.7000000000000002	10	1	19	2010-07-22 13:46:50.931963	2010-07-22 13:57:56.39303	yes	130
107	2010-07-21	15	1	0	19	20	2010-07-21 11:48:50.809239	2010-07-22 14:04:08.252132	no	107
98	2010-07-20	5.2000000000000002	3.2999999999999998	4	1	14	2010-07-20 12:44:23.89691	2010-07-22 14:21:42.135988	yes	98
101	2010-07-20	5.2000000000000002	6.0999999999999996	4	1	14	2010-07-20 12:51:02.077503	2010-07-22 14:22:13.330953	yes	101
155	2010-07-24	0	0	22	14	6	2010-07-24 14:41:59.97642	2010-07-24 14:41:59.97642	no	155
106	2010-07-20	5.2000000000000002	10.199999999999999	26	24	14	2010-07-20 13:05:32.886862	2010-07-22 14:23:17.140393	no	106
131	2010-07-23	5.2000000000000002	17.300000000000001	43.600000000000001	6	22	2010-07-23 13:48:07.601611	2010-07-23 13:48:07.601611	no	131
133	2010-07-23	5.2000000000000002	10	12	19	2	2010-07-23 13:53:58.424576	2010-07-23 13:53:58.424576	no	132
134	2010-07-23	5.2000000000000002	1.5	2.5	1	2	2010-07-23 13:57:52.473812	2010-07-23 13:57:52.473812	yes	134
135	2010-07-23	0	0	20	1	6	2010-07-23 14:00:39.670438	2010-07-23 14:00:39.670438	yes	135
136	2010-07-23	0	0	100	22	6	2010-07-23 14:02:15.261771	2010-07-23 14:02:15.261771	no	136
137	2010-07-23	10	51	52	8	9	2010-07-23 14:05:24.806545	2010-07-23 14:05:24.806545	no	137
138	2010-07-23	0	0	2	22	6	2010-07-23 14:10:32.936876	2010-07-23 14:10:32.936876	no	138
139	2010-07-23	7	11	8	14	11	2010-07-23 14:12:57.875516	2010-07-23 14:12:57.875516	no	139
141	2010-07-23	0	0	4	2	6	2010-07-23 14:17:06.600943	2010-07-23 14:17:06.600943	no	141
126	2010-07-22	8	26	26	11	4	2010-07-22 13:34:06.079125	2010-07-23 15:54:11.744737	no	126
125	2010-07-22	5.2000000000000002	21	24	7	5	2010-07-22 13:25:36.093573	2010-07-23 15:58:53.225963	no	125
121	2010-07-22	5.2000000000000002	1.6000000000000001	2	1	14	2010-07-22 13:16:36.039212	2010-07-23 16:02:00.320984	yes	121
119	2010-07-22	4.9000000000000004	8.9000000000000004	0	3	2	2010-07-22 13:10:15.305245	2010-07-23 16:06:03.504617	no	119
114	2010-07-22	4.9000000000000004	16.699999999999999	46	3	2	2010-07-22 13:02:12.353081	2010-07-23 16:08:38.855218	no	114
103	2010-07-20	4.9000000000000004	5.7999999999999998	0	3	2	2010-07-20 13:00:12.15893	2010-07-23 16:16:58.953051	no	103
100	2010-07-20	0	0	8	19	6	2010-07-20 12:48:02.332487	2010-07-23 16:21:09.504008	no	100
99	2010-07-20	0	0	2	22	6	2010-07-20 12:46:10.545847	2010-07-23 16:22:05.324992	no	99
96	2010-07-19	5.2000000000000002	0.80000000000000004	4	26	2	2010-07-19 12:08:49.564124	2010-07-23 16:25:20.441574	yes	96
142	2010-07-24	7.5	120.5	128	19	15	2010-07-24 13:59:52.557186	2010-07-24 13:59:52.557186	no	142
143	2010-07-24	4.9000000000000004	10.4	0	3	2	2010-07-24 14:02:47.466955	2010-07-24 14:02:47.466955	no	143
144	2010-07-24	4.7000000000000002	36.399999999999999	76	3	1	2010-07-24 14:05:24.382847	2010-07-24 14:05:24.382847	no	144
145	2010-07-24	14	0.69999999999999996	0	1	3	2010-07-24 14:08:17.164187	2010-07-24 14:08:17.164187	yes	145
146	2010-07-24	5.2000000000000002	0.80000000000000004	2	1	2	2010-07-24 14:24:22.731213	2010-07-24 14:24:22.731213	yes	146
156	2010-07-25	5	7	2	1	22	2010-07-25 12:43:57.886832	2010-07-25 12:43:57.886832	yes	156
157	2010-07-25	0	0	2	3	6	2010-07-25 12:46:50.296672	2010-07-25 12:46:50.296672	no	157
158	2010-07-25	14	15	0	9	20	2010-07-25 12:49:30.073473	2010-07-25 12:49:30.073473	no	158
160	2010-07-25	4.7999999999999998	235	280	19	1	2010-07-25 12:52:36.951734	2010-07-25 12:52:36.951734	no	159
161	2010-07-25	5.2000000000000002	39.5	36	2	2	2010-07-25 12:55:54.819934	2010-07-25 12:55:54.819934	no	161
162	2010-07-25	7	5.5	3	19	11	2010-07-25 12:58:30.649627	2010-07-25 12:58:30.649627	no	162
163	2010-07-25	14	0.69999999999999996	2	7	3	2010-07-25 13:00:42.409942	2010-07-25 13:00:42.409942	no	163
148	2010-07-24	5	3	2	27	14	2010-07-24 14:28:25.564658	2010-07-25 13:47:01.167786	no	148
140	2010-07-23	5	14.699999999999999	16	27	14	2010-07-23 14:15:38.064165	2010-07-25 13:49:02.519719	no	140
164	2010-07-26	4.9000000000000004	6.5999999999999996	0	3	2	2010-07-26 12:24:52.350203	2010-07-26 12:24:52.350203	no	164
165	2010-07-26	4.7000000000000002	10.5	48	3	1	2010-07-26 12:28:12.073013	2010-07-26 12:28:12.073013	no	165
166	2010-07-26	0	0	4	26	6	2010-07-26 13:55:42.07297	2010-07-26 13:55:42.07297	yes	166
167	2010-07-26	0	0	6	14	6	2010-07-26 13:56:56.780297	2010-07-26 13:56:56.780297	no	167
168	2010-07-26	15	3	4	1	20	2010-07-26 13:59:22.892903	2010-07-26 13:59:22.892903	yes	168
169	2010-07-26	10	51	52	8	9	2010-07-26 14:01:08.39474	2010-07-26 14:01:08.39474	no	169
170	2010-07-26	8	25	26	11	4	2010-07-26 14:03:16.265664	2010-07-26 14:03:16.265664	no	170
172	2010-07-26	10	89	78	18	4	2010-07-26 14:05:25.518614	2010-07-26 14:05:25.518614	no	171
173	2010-07-26	10	2.2000000000000002	4	1	19	2010-07-26 14:08:36.475671	2010-07-26 14:08:36.475671	yes	173
174	2010-07-26	10	1.2	5	1	19	2010-07-26 14:10:46.330842	2010-07-26 14:10:46.330842	yes	174
175	2010-07-26	5.5	2.1000000000000001	4	2	2	2010-07-26 14:12:24.632601	2010-07-26 14:12:24.632601	no	175
176	2010-07-27	0	0	4	2	6	2010-07-27 10:49:06.733381	2010-07-27 10:49:06.733381	no	176
177	2010-07-27	5.2000000000000002	2.1000000000000001	2	27	2	2010-07-27 10:50:44.227883	2010-07-27 10:50:44.227883	no	177
178	2010-07-27	0	0	26	1	6	2010-07-27 10:51:58.896882	2010-07-27 10:51:58.896882	yes	178
179	2010-07-27	0	0	8	3	6	2010-07-27 10:53:02.222033	2010-07-27 10:53:02.222033	no	179
180	2010-07-27	8.5	1	0	7	5	2010-07-27 10:55:01.129934	2010-07-27 13:04:13.800136	no	180
181	2010-07-27	5.2000000000000002	6	12	7	2	2010-07-27 13:10:56.868529	2010-07-27 13:10:56.868529	no	181
182	2010-07-27	5.2000000000000002	12.1	4	2	2	2010-07-27 13:13:07.887621	2010-07-27 13:13:07.887621	no	182
184	2010-07-27	5.2000000000000002	375.19999999999999	504	30	2	2010-07-27 13:17:35.232952	2010-07-27 13:23:10.99578	no	184
183	2010-07-27	10	1.6000000000000001	4	29	19	2010-07-27 13:15:00.508935	2010-07-27 13:22:37.310733	no	183
187	2010-07-28	5.2000000000000002	12.1	4	2	2	2010-07-28 12:45:08.038883	2010-07-28 12:45:08.038883	no	187
186	2010-07-28	1.8	245	0	1	13	2010-07-28 12:42:26.069108	2010-07-28 12:45:54.396912	yes	185
188	2010-07-28	4.9000000000000004	11.5	26	3	2	2010-07-28 12:48:10.889331	2010-07-28 12:48:10.889331	no	188
189	2010-07-28	4.7000000000000002	12	26	3	1	2010-07-28 12:55:12.107159	2010-07-28 12:55:12.107159	no	189
191	2010-07-28	5.2000000000000002	260.60000000000002	304	2	2	2010-07-28 13:35:02.393816	2010-07-28 13:35:02.393816	no	191
190	2010-07-28	5.2000000000000002	8.8000000000000007	20	2	14	2010-07-28 13:32:20.084097	2010-07-28 13:36:07.878738	no	190
192	2010-07-28	4.9000000000000004	5	8	3	2	2010-07-28 13:38:12.631573	2010-07-28 13:38:12.631573	no	192
193	2010-07-28	8.5	3.5	0	2	5	2010-07-28 13:40:19.296361	2010-07-28 13:40:19.296361	no	193
194	2010-07-28	5.2000000000000002	2.5	4	2	2	2010-07-28 13:42:34.562943	2010-07-28 13:42:34.562943	no	194
196	2010-07-28	14	0.55000000000000004	2	7	3	2010-07-28 13:47:31.432201	2010-07-28 13:47:31.432201	no	196
198	2010-07-28	0	0	10	1	6	2010-07-28 14:07:32.608594	2010-07-28 14:07:32.608594	yes	198
197	2010-07-28	0	0	2	1	6	2010-07-28 14:05:41.214133	2010-07-28 14:08:00.795665	yes	197
199	2010-07-28	0	0	6	1	6	2010-07-28 14:09:27.704312	2010-07-28 14:09:27.704312	yes	199
200	2010-07-28	5.2000000000000002	3.2999999999999998	2	1	2	2010-07-28 14:11:03.171279	2010-07-28 14:11:03.171279	yes	200
201	2010-07-28	0	0	10	1	6	2010-07-28 14:14:44.853874	2010-07-28 14:14:44.853874	yes	201
202	2010-07-29	5.2000000000000002	2.3999999999999999	4	21	22	2010-07-29 11:13:32.851888	2010-07-29 11:13:32.851888	no	202
203	2010-07-29	15	183.5	945	12	20	2010-07-29 11:15:35.067969	2010-07-29 11:15:35.067969	no	203
204	2010-07-29	7.5	2.5	5	3	16	2010-07-29 11:17:36.916924	2010-07-29 11:18:11.652049	no	204
205	2010-07-29	4.9000000000000004	15.4	5	3	2	2010-07-29 11:20:18.535077	2010-07-29 11:20:18.535077	no	205
206	2010-07-29	4.7000000000000002	38	110	3	1	2010-07-29 11:21:57.449302	2010-07-29 11:21:57.449302	no	206
207	2010-07-29	5.2000000000000002	10.4	28	30	2	2010-07-29 11:29:05.148742	2010-07-29 11:29:05.148742	yes	207
208	2010-07-29	6	228	55	30	24	2010-07-29 11:31:02.855783	2010-07-29 11:31:02.855783	yes	208
210	2010-07-29	5.2000000000000002	17.5	32	1	2	2010-07-29 11:35:15.047663	2010-07-29 11:35:15.047663	yes	209
211	2010-07-29	5.2000000000000002	3.7999999999999998	30	1	2	2010-07-29 11:37:20.021893	2010-07-29 11:37:20.021893	yes	211
212	2010-07-29	5.2000000000000002	45.600000000000001	28	1	2	2010-07-29 11:39:17.900275	2010-07-29 11:39:17.900275	yes	212
213	2010-07-29	17	17.800000000000001	18	1	12	2010-07-29 11:41:21.651986	2010-07-29 11:41:21.651986	yes	213
214	2010-07-29	10	12.5	20	1	19	2010-07-29 11:42:51.763534	2010-07-29 11:42:51.763534	yes	214
215	2010-07-29	5.2000000000000002	10.6	5	2	2	2010-07-29 11:44:50.905011	2010-07-29 11:44:50.905011	no	215
216	2010-07-30	8.5	1.8999999999999999	4	7	5	2010-07-30 12:04:22.924239	2010-07-30 12:04:22.924239	no	216
217	2010-07-30	14	0.59999999999999998	5	7	3	2010-07-30 12:08:12.100508	2010-07-30 12:08:12.100508	no	217
218	2010-07-30	5.2000000000000002	4.2999999999999998	2	19	2	2010-07-30 13:16:43.834974	2010-07-30 13:16:43.834974	no	218
219	2010-07-30	5.2000000000000002	3.5	0	1	14	2010-07-30 13:18:56.285415	2010-07-30 13:18:56.285415	yes	219
220	2010-07-30	5.2000000000000002	6.2999999999999998	4	1	2	2010-07-30 13:21:02.526165	2010-07-30 13:21:02.526165	yes	220
221	2010-07-30	0	0	26	1	6	2010-07-30 13:22:46.812851	2010-07-30 13:22:46.812851	yes	221
222	2010-07-30	10	24.800000000000001	26	8	9	2010-07-30 13:24:34.997664	2010-07-30 13:24:34.997664	no	222
223	2010-07-30	8	46.799999999999997	52	11	9	2010-07-30 13:26:45.286839	2010-07-30 13:26:45.286839	no	223
224	2010-07-30	5.2000000000000002	3.7999999999999998	31	1	2	2010-07-30 13:28:44.945672	2010-07-30 13:28:44.945672	yes	224
225	2010-07-30	8	28.5	26	11	9	2010-07-30 13:30:37.571983	2010-07-30 13:30:37.571983	no	225
195	2010-07-28	5.2000000000000002	21.600000000000001	40	31	2	2010-07-28 13:45:46.354394	2010-07-30 14:49:40.92605	no	195
226	2010-07-31	9	28.5	32	19	4	2010-08-01 11:21:13.372435	2010-08-01 11:23:07.767016	no	226
227	2010-07-31	0	0	4	1	6	2010-08-01 11:25:24.002336	2010-08-01 11:25:24.002336	yes	227
228	2010-07-31	0	0	10	14	6	2010-08-01 11:26:28.96826	2010-08-01 11:26:54.216325	no	228
229	2010-07-31	10	50	52	8	9	2010-08-01 11:28:17.362133	2010-08-01 11:28:45.705605	no	229
230	2010-08-01	5.2000000000000002	236.69999999999999	120	25	2	2010-08-01 11:36:38.000511	2010-08-01 11:36:38.000511	no	230
231	2010-08-01	9	26	32	32	4	2010-08-01 11:40:16.095796	2010-08-01 11:40:16.095796	no	231
232	2010-08-01	4.7999999999999998	138.5	96	14	1	2010-08-01 11:42:27.386976	2010-08-01 11:42:27.386976	no	232
233	2010-08-01	7.5	14	16	19	7	2010-08-01 11:44:40.897426	2010-08-01 11:44:40.897426	no	233
234	2010-08-01	5.2000000000000002	7.2999999999999998	10.4	19	22	2010-08-01 11:47:02.661412	2010-08-01 11:47:02.661412	no	234
235	2010-08-01	7.5	2	2	19	16	2010-08-01 12:05:54.319649	2010-08-01 12:05:54.319649	no	235
236	2010-08-01	4.9000000000000004	5.5999999999999996	8	3	2	2010-08-01 12:07:21.713914	2010-08-01 12:07:21.713914	no	236
237	2010-08-01	4.7000000000000002	14.199999999999999	32	3	1	2010-08-01 12:09:01.026548	2010-08-01 12:09:01.026548	no	237
238	2010-08-01	4.7999999999999998	105	96	19	1	2010-08-01 12:10:56.318808	2010-08-01 12:10:56.318808	no	238
239	2010-08-01	0	0	26	26	6	2010-08-01 12:12:35.140979	2010-08-01 12:13:43.959492	no	239
240	2010-08-01	0	0	20	26	6	2010-08-01 12:15:00.780441	2010-08-01 12:15:00.780441	yes	240
241	2010-08-01	4.9000000000000004	13.6	8	3	2	2010-08-01 12:17:33.75516	2010-08-01 12:18:17.45273	no	241
242	2010-08-01	4.7000000000000002	27.600000000000001	64	3	1	2010-08-01 12:21:06.908052	2010-08-01 12:21:06.908052	no	242
243	2010-08-01	5.2000000000000002	0.80000000000000004	8	19	2	2010-08-01 12:22:30.870709	2010-08-01 12:22:30.870709	no	243
245	2010-08-02	5.2000000000000002	5.7999999999999998	0	1	2	2010-08-02 16:04:11.077122	2010-08-02 16:04:33.010441	yes	245
244	2010-08-02	5.2000000000000002	10.199999999999999	43	6	22	2010-08-02 16:02:07.535376	2010-08-02 16:05:11.876995	no	244
247	2010-08-02	8.5	24.5	26	11	9	2010-08-02 16:08:38.898959	2010-08-02 16:08:38.898959	no	247
248	2010-08-02	4.9000000000000004	7.2000000000000002	12	3	2	2010-08-02 16:10:36.867933	2010-08-02 16:10:36.867933	no	248
249	2010-08-02	4.7000000000000002	11.800000000000001	32	3	1	2010-08-02 16:12:12.692074	2010-08-02 16:12:12.692074	no	249
250	2010-08-02	8.5	0.69999999999999996	0	7	5	2010-08-02 16:14:17.101524	2010-08-02 16:14:17.101524	no	250
251	2010-08-02	10	3	15	7	19	2010-08-02 16:16:19.452264	2010-08-02 16:16:19.452264	no	251
252	2010-08-02	5.2000000000000002	17.300000000000001	84	7	2	2010-08-02 16:17:47.621313	2010-08-02 16:17:47.621313	no	252
253	2010-08-02	5.2000000000000002	59.600000000000001	64	1	2	2010-08-02 16:19:44.346085	2010-08-02 16:19:44.346085	yes	253
246	2010-08-02	0	0	5	1	6	2010-08-02 16:06:35.592833	2010-08-03 03:47:48.865195	yes	246
254	2010-08-03	5	31.5	40	31	2	2010-08-03 10:54:40.048778	2010-08-03 10:54:40.048778	no	254
255	2010-08-03	0	0	8	14	6	2010-08-03 10:56:01.520865	2010-08-03 10:56:01.520865	no	255
256	2010-08-03	5.2000000000000002	4.5999999999999996	4	2	2	2010-08-03 10:57:40.946274	2010-08-03 10:57:40.946274	no	256
257	2010-08-03	5.2000000000000002	3.2999999999999998	2	1	14	2010-08-03 10:59:26.845325	2010-08-03 10:59:26.845325	yes	257
259	2010-08-03	0	0	14	3	6	2010-08-03 11:02:35.818751	2010-08-03 11:02:35.818751	no	259
260	2010-08-03	4.7999999999999998	88	36	32	1	2010-08-03 11:04:19.973707	2010-08-03 11:04:19.973707	no	260
263	2010-08-03	8.5	1	0	7	5	2010-08-03 11:08:29.928224	2010-08-03 11:08:29.928224	no	263
264	2010-08-03	17	1.7	12	7	18	2010-08-03 11:10:23.530161	2010-08-03 11:10:23.530161	no	264
265	2010-08-03	5.2000000000000002	15.4	30	7	2	2010-08-03 11:11:48.0639	2010-08-03 11:11:48.0639	no	265
266	2010-08-03	5.2000000000000002	2.1000000000000001	2	32	14	2010-08-03 11:13:25.640149	2010-08-03 11:13:25.640149	no	266
267	2010-08-04	4.7999999999999998	2.8999999999999999	8	7	1	2010-08-04 13:20:16.427878	2010-08-04 13:20:37.087063	no	267
268	2010-08-04	4.7999999999999998	1.3	4	7	1	2010-08-04 13:21:56.240412	2010-08-04 13:21:56.240412	no	268
269	2010-08-04	5.2000000000000002	1.6000000000000001	14	27	2	2010-08-04 13:23:20.008214	2010-08-04 13:23:20.008214	no	269
270	2010-08-04	5.2000000000000002	4.5999999999999996	12	29	2	2010-08-04 13:24:43.173607	2010-08-04 13:24:43.173607	yes	270
271	2010-08-04	4.9000000000000004	7.7999999999999998	10	3	2	2010-08-04 13:26:13.20489	2010-08-04 13:26:13.20489	no	271
272	2010-08-04	4.7000000000000002	14.4	30	3	1	2010-08-04 13:27:32.439655	2010-08-04 13:27:32.439655	no	272
273	2010-08-04	5.2000000000000002	6.2000000000000002	12	19	2	2010-08-04 13:29:08.04846	2010-08-04 13:29:08.04846	no	273
274	2010-08-04	0	0	2	1	6	2010-08-04 13:30:24.639456	2010-08-04 13:30:24.639456	yes	274
275	2010-08-04	4.7999999999999998	262	160	14	1	2010-08-04 13:32:03.506828	2010-08-04 13:32:03.506828	no	275
276	2010-08-04	5.2000000000000002	100.90000000000001	48	1	2	2010-08-04 13:33:55.2564	2010-08-04 13:33:55.2564	yes	276
277	2010-08-04	17	32.600000000000001	27	1	18	2010-08-04 13:35:23.099474	2010-08-04 13:35:23.099474	yes	277
278	2010-08-04	14	1	2	2	3	2010-08-04 13:36:56.04482	2010-08-04 13:36:56.04482	no	278
258	2010-08-03	5.2000000000000002	81.400000000000006	196	30	2	2010-08-03 11:01:21.781301	2010-08-04 13:52:10.460574	yes	258
281	2010-08-05	5.2000000000000002	18	8	2	2	2010-08-05 16:33:57.817629	2010-08-05 16:33:57.817629	no	281
283	2010-08-05	4.7999999999999998	17	4	19	1	2010-08-05 16:48:58.679736	2010-08-05 16:48:58.679736	no	283
284	2010-08-05	7.5	6.2000000000000002	8	19	15	2010-08-05 16:55:27.833818	2010-08-05 16:55:27.833818	no	284
285	2010-08-05	4.7999999999999998	3.3999999999999999	4	26	1	2010-08-05 17:12:42.875521	2010-08-05 17:12:42.875521	yes	285
287	2010-08-05	4.7999999999999998	185	128	14	1	2010-08-05 17:17:07.078793	2010-08-05 17:17:07.078793	no	287
288	2010-08-06	4.7999999999999998	1.2	4	3	1	2010-08-06 10:47:03.308786	2010-08-06 10:47:03.308786	no	288
289	2010-08-06	5.2000000000000002	2.5	8	32	1	2010-08-06 10:48:27.57658	2010-08-06 10:48:27.57658	no	289
290	2010-08-06	9	26.5	28	32	4	2010-08-06 10:49:55.597984	2010-08-06 10:49:55.597984	no	290
291	2010-08-06	0	0	6	27	6	2010-08-06 10:51:03.520121	2010-08-06 10:51:03.520121	no	291
292	2010-08-06	0	0	2	7	6	2010-08-06 10:52:02.800729	2010-08-06 10:52:02.800729	no	292
293	2010-08-06	10	59	52	8	9	2010-08-06 10:53:20.088332	2010-08-06 10:53:20.088332	no	293
294	2010-08-06	0	0	6	14	6	2010-08-06 10:54:37.282661	2010-08-06 10:54:37.282661	no	294
279	2010-08-05	5.2000000000000002	18	8	2	2	2010-08-05 16:29:45.942166	2010-08-06 10:56:53.900857	no	279
286	2010-08-05	0	0	2	3	6	2010-08-05 17:13:53.147958	2010-08-06 10:58:13.645367	no	286
295	2010-07-01	0	0	10	14	6	2010-08-06 11:07:03.253924	2010-08-06 11:07:03.253924	no	295
296	2010-07-01	4.7999999999999998	8.3000000000000007	7	2	1	2010-08-06 11:08:35.395307	2010-08-06 11:10:01.301019	no	296
297	2010-07-01	4.9000000000000004	23.699999999999999	10	3	2	2010-08-06 11:13:35.381458	2010-08-06 11:13:35.381458	no	297
298	2010-07-01	5.2000000000000002	1.6000000000000001	4	19	1	2010-08-06 11:15:52.489272	2010-08-06 11:15:52.489272	no	298
299	2010-07-02	5.2000000000000002	11.800000000000001	16	14	2	2010-08-06 11:18:07.289021	2010-08-06 11:18:07.289021	no	299
344	2010-08-08	4.7000000000000002	27.699999999999999	64	3	1	2010-08-08 10:36:38.455893	2010-08-08 10:36:38.455893	no	344
301	2010-07-02	4.9000000000000004	5.7000000000000002	10	3	2	2010-08-06 11:26:18.894716	2010-08-06 11:26:18.894716	no	301
302	2010-07-02	4.7000000000000002	13	30	3	1	2010-08-06 11:27:50.32424	2010-08-06 11:27:50.32424	no	302
303	2010-07-03	5.5	18	60	2	2	2010-08-06 11:31:05.09767	2010-08-06 11:31:05.09767	no	303
304	2010-07-03	4.9000000000000004	6.5999999999999996	4	2	1	2010-08-06 11:32:40.794221	2010-08-06 11:32:40.794221	no	304
305	2010-07-03	4.9000000000000004	2.2999999999999998	6	3	2	2010-08-06 11:34:36.01572	2010-08-06 11:34:36.01572	no	305
306	2010-07-03	4.7000000000000002	8.5	26	3	1	2010-08-06 11:35:54.622705	2010-08-06 11:35:54.622705	no	306
307	2010-07-03	5.2000000000000002	9.1999999999999993	16	19	2	2010-08-06 11:39:21.187246	2010-08-06 11:39:21.187246	no	307
309	2010-07-04	4.9000000000000004	11	6	3	2	2010-08-06 11:46:35.16219	2010-08-06 11:46:35.16219	no	308
310	2010-07-04	4.7000000000000002	46.899999999999999	70	3	1	2010-08-06 11:48:15.929315	2010-08-06 11:48:15.929315	no	310
311	2010-07-04	14	0.14999999999999999	2	7	3	2010-08-06 11:50:25.675302	2010-08-06 11:50:25.675302	no	311
312	2010-07-05	8.5	2	1	2	5	2010-08-06 11:53:33.258404	2010-08-06 11:53:33.258404	no	312
313	2010-07-06	5.2000000000000002	44.299999999999997	36	2	2	2010-08-06 11:59:03.923821	2010-08-06 11:59:03.923821	no	313
314	2010-07-06	4.9000000000000004	1.6000000000000001	7	3	2	2010-08-06 12:52:12.970539	2010-08-06 12:52:12.970539	no	314
315	2010-07-07	4.9000000000000004	4	8	3	2	2010-08-06 12:53:49.806013	2010-08-06 12:53:49.806013	no	315
316	2010-07-07	14	0.40000000000000002	2	7	3	2010-08-06 12:55:33.649054	2010-08-06 12:55:33.649054	no	316
317	2010-07-07	5.2000000000000002	10	40	19	2	2010-08-06 12:57:07.51174	2010-08-06 12:57:07.51174	no	317
318	2010-07-08	5.2000000000000002	4.2999999999999998	16	19	2	2010-08-06 12:58:50.341197	2010-08-06 12:58:50.341197	no	318
319	2010-07-08	5.2000000000000002	7.2000000000000002	12	14	2	2010-08-06 13:00:58.189633	2010-08-06 13:00:58.189633	no	319
320	2010-07-08	14	1.1000000000000001	6	7	3	2010-08-06 13:02:54.293395	2010-08-06 13:02:54.293395	no	320
321	2010-07-09	4.9000000000000004	10.800000000000001	6	3	2	2010-08-06 13:04:37.011364	2010-08-06 13:04:37.011364	no	321
322	2010-07-09	4.7000000000000002	26.199999999999999	70	3	1	2010-08-06 13:05:55.868994	2010-08-06 13:05:55.868994	no	322
323	2010-07-10	8.5	1.2	2	2	5	2010-08-06 13:08:35.177698	2010-08-06 13:08:35.177698	no	323
324	2010-07-10	4.9000000000000004	3.2999999999999998	2	2	1	2010-08-06 13:10:03.097251	2010-08-06 13:10:03.097251	no	324
345	2010-08-08	5.2000000000000002	6.5	4	2	2	2010-08-08 10:38:02.333558	2010-08-08 10:38:02.333558	no	345
346	2010-08-08	10	0.80000000000000004	8	19	10	2010-08-08 10:39:25.534248	2010-08-08 10:39:25.534248	no	346
325	2010-07-01	4.7000000000000002	49.799999999999997	150	3	1	2010-08-07 13:07:18.036267	2010-08-07 13:07:18.036267	no	325
326	2010-07-05	4.9000000000000004	3	3	2	1	2010-08-07 13:08:57.828282	2010-08-07 13:08:57.828282	no	326
300	2010-07-02	4.9000000000000004	17	16	2	1	2010-08-06 11:24:03.992981	2010-08-07 13:11:08.367887	no	300
327	2010-07-02	5.2000000000000002	1.25	0	2	2	2010-08-07 13:11:53.162559	2010-08-07 13:11:53.162559	no	327
328	2010-08-07	5.2000000000000002	5.7000000000000002	9	15	22	2010-08-07 16:24:35.192718	2010-08-07 16:24:35.192718	no	328
329	2010-08-07	0	0	2	26	6	2010-08-07 16:26:04.535414	2010-08-07 16:26:04.535414	yes	329
330	2010-08-07	14	3.5	4	1	3	2010-08-07 16:27:46.567993	2010-08-07 16:27:46.567993	yes	330
331	2010-08-07	5.2000000000000002	2.7999999999999998	2	32	2	2010-08-07 16:29:45.675065	2010-08-07 16:29:45.675065	no	331
332	2010-08-07	5.2000000000000002	42.299999999999997	97	6	22	2010-08-07 16:31:19.766118	2010-08-07 16:31:19.766118	no	332
333	2010-08-07	5.2000000000000002	62.600000000000001	210	6	14	2010-08-07 16:33:15.484349	2010-08-07 16:33:15.484349	no	333
334	2010-08-07	5.2000000000000002	3.7000000000000002	14	24	2	2010-08-07 16:34:49.282111	2010-08-07 16:34:49.282111	no	334
335	2010-08-07	5.2000000000000002	18	93.400000000000006	6	14	2010-08-07 16:36:36.327636	2010-08-07 16:36:36.327636	no	335
336	2010-08-07	5.2000000000000002	9.8000000000000007	10	14	2	2010-08-07 16:38:25.707012	2010-08-07 16:38:25.707012	no	336
338	2010-08-07	5.2000000000000002	6.7999999999999998	12	32	2	2010-08-07 16:41:49.203244	2010-08-07 16:41:49.203244	no	338
339	2010-08-07	5.2000000000000002	11.300000000000001	28	19	2	2010-08-07 16:43:44.982713	2010-08-07 16:43:44.982713	no	339
337	2010-08-07	0	0	13	1	6	2010-08-07 16:39:57.938044	2010-08-07 16:53:40.585795	yes	337
341	2010-07-05	0	0	20	3	6	2010-08-08 09:45:23.089753	2010-08-08 09:45:23.089753	no	341
342	2010-07-05	4.7999999999999998	1.8	6	2	1	2010-08-08 09:47:49.80143	2010-08-08 09:47:49.80143	no	342
343	2010-08-08	4.9000000000000004	15.1	20	3	2	2010-08-08 10:35:16.123629	2010-08-08 10:35:16.123629	no	343
347	2010-08-08	0	0	5	32	6	2010-08-08 10:40:36.388291	2010-08-08 10:40:52.351354	yes	347
348	2010-08-08	4.7999999999999998	4.7999999999999998	0.080000000000000002	1	1	2010-08-08 10:42:14.404966	2010-08-08 10:42:14.404966	yes	348
349	2010-08-08	10	1.5	4	1	10	2010-08-08 10:43:40.625654	2010-08-08 10:43:40.625654	yes	349
350	2010-08-08	5.2000000000000002	2	9.5999999999999996	6	14	2010-08-08 10:45:10.193689	2010-08-08 10:45:10.193689	no	350
351	2010-08-08	10	1	2	1	10	2010-08-08 10:46:29.773045	2010-08-08 10:46:29.773045	yes	351
352	2010-08-08	5.2000000000000002	2.1000000000000001	2	14	14	2010-08-08 10:47:42.946929	2010-08-08 10:47:42.946929	no	352
353	2010-08-08	4.9000000000000004	14.699999999999999	16	3	2	2010-08-08 10:49:11.885153	2010-08-08 10:49:11.885153	no	353
354	2010-08-08	4.7000000000000002	42.5	96	3	1	2010-08-08 10:50:22.755616	2010-08-08 10:50:22.755616	no	354
355	2010-08-08	14	37.600000000000001	0	9	20	2010-08-08 10:51:37.421648	2010-08-08 10:51:37.421648	no	355
356	2010-08-08	0	0	2	26	6	2010-08-08 10:52:54.00014	2010-08-08 10:52:54.00014	no	356
357	2010-08-09	4.9000000000000004	10	16	3	2	2010-08-09 11:49:08.180936	2010-08-09 11:49:08.180936	no	357
358	2010-08-09	0	0	2	1	6	2010-08-09 11:50:24.812523	2010-08-09 11:50:24.812523	yes	358
359	2010-08-09	0	0	4	32	6	2010-08-09 11:51:18.928177	2010-08-09 11:51:18.928177	yes	359
360	2010-08-09	8.5	31.5	26	11	9	2010-08-09 11:52:46.597666	2010-08-09 11:52:46.597666	no	360
361	2010-08-09	8	95.5	91	11	4	2010-08-09 11:53:44.315898	2010-08-09 11:53:44.315898	no	361
362	2010-08-10	4.9000000000000004	20	20	3	2	2010-08-10 11:31:24.480311	2010-08-10 11:31:24.480311	no	362
363	2010-08-10	4.7000000000000002	47.700000000000003	96	3	1	2010-08-10 11:32:52.656603	2010-08-10 11:32:52.656603	no	363
365	2010-08-10	5.2000000000000002	0.5	5	19	2	2010-08-10 11:38:52.963412	2010-08-10 11:38:52.963412	no	365
366	2010-08-10	5.2000000000000002	3.7999999999999998	8	2	2	2010-08-10 11:40:18.40135	2010-08-10 11:40:18.40135	no	366
370	2010-08-10	10	26.5	26	8	9	2010-08-10 13:28:53.790609	2010-08-10 13:28:53.790609	no	370
371	2010-08-10	4.9000000000000004	10.1	16	3	2	2010-08-10 13:30:22.881558	2010-08-10 13:30:22.881558	no	371
372	2010-08-10	4.7000000000000002	28.600000000000001	56	3	1	2010-08-10 13:32:12.865739	2010-08-10 13:32:12.865739	no	372
373	2010-08-10	5.2000000000000002	5.7000000000000002	2	1	14	2010-08-10 13:34:12.20167	2010-08-10 13:34:12.20167	yes	373
376	2010-08-10	0	0	3	1	6	2010-08-10 13:38:23.134628	2010-08-10 13:38:23.134628	yes	376
369	2010-08-10	0	0	3	1	6	2010-08-10 13:27:35.955078	2010-08-10 13:38:59.337103	yes	369
368	2010-08-10	5.2000000000000002	30.100000000000001	8	1	14	2010-08-10 11:45:10.74518	2010-08-10 13:39:37.962932	yes	368
421	2010-08-15	14	0.29999999999999999	2	7	3	2010-08-15 11:27:18.395	2010-08-15 11:27:18.395	no	421
364	2010-08-10	0	0	3	1	6	2010-08-10 11:35:21.203752	2010-08-10 13:40:38.554862	yes	364
374	2010-08-10	7.5	68	48	33	15	2010-08-10 13:35:52.800891	2010-08-10 13:53:31.565443	no	374
367	2010-08-10	10	3.7999999999999998	28	34	10	2010-08-10 11:42:47.398644	2010-08-10 13:54:11.178772	yes	367
375	2010-08-10	4.7999999999999998	92	64	33	1	2010-08-10 13:37:25.164797	2010-08-10 13:54:27.798844	no	375
340	2010-08-07	7.5	13.6	8	33	16	2010-08-07 16:46:02.984286	2010-08-10 13:56:12.384029	yes	340
280	2010-08-05	5.2000000000000002	5.9000000000000004	6	34	14	2010-08-05 16:31:34.537698	2010-08-10 13:56:40.840349	yes	280
377	2010-08-07	1.46	239	0	1	13	2010-08-10 14:02:44.184804	2010-08-10 14:05:29.995838	yes	377
261	2010-08-03	4.7999999999999998	65.5	28	33	1	2010-08-03 11:05:50.668724	2010-08-10 16:18:50.624911	no	261
262	2010-08-03	7.5	54	32	33	15	2010-08-03 11:07:09.352161	2010-08-10 16:19:04.105274	no	262
378	2010-08-11	14	0.40000000000000002	2	15	3	2010-08-11 15:41:41.061754	2010-08-11 15:41:41.061754	no	378
379	2010-08-11	5.2000000000000002	9.0999999999999996	13	15	22	2010-08-11 15:43:19.752687	2010-08-11 15:43:19.752687	no	379
380	2010-08-11	4.7999999999999998	4.5999999999999996	8	19	1	2010-08-11 15:45:59.495715	2010-08-11 15:45:59.495715	no	380
381	2010-08-11	5.2000000000000002	2.5	8	1	2	2010-08-11 15:47:24.800307	2010-08-11 15:47:41.824848	yes	381
382	2010-08-11	14	0.69999999999999996	0	23	3	2010-08-11 15:49:22.638371	2010-08-11 15:49:22.638371	no	382
383	2010-08-11	4.7999999999999998	75.5	64	32	1	2010-08-11 15:50:49.933504	2010-08-11 15:50:49.933504	yes	383
384	2010-08-11	9	25.699999999999999	16	32	4	2010-08-11 15:53:43.868891	2010-08-11 15:53:54.613395	yes	384
385	2010-08-11	5.2000000000000002	8.9000000000000004	12	32	2	2010-08-11 15:55:37.968828	2010-08-11 15:55:37.968828	yes	385
386	2010-08-11	5.2000000000000002	65.5	4.2000000000000002	30	2	2010-08-11 15:59:23.40356	2010-08-11 15:59:23.40356	yes	386
387	2010-08-11	6	177.40000000000001	55	30	17	2010-08-11 16:01:24.96805	2010-08-11 16:17:59.145496	yes	387
388	2010-08-12	0	0	55	1	6	2010-08-12 12:31:57.655554	2010-08-12 12:33:03.860842	yes	388
389	2010-08-12	4.9000000000000004	23.699999999999999	0	3	2	2010-08-12 12:35:13.179194	2010-08-12 12:35:13.179194	yes	389
390	2010-08-12	4.7000000000000002	38.600000000000001	132	3	1	2010-08-12 12:37:54.807022	2010-08-12 12:37:54.807022	no	390
391	2010-08-12	7.5	106.5	140	19	15	2010-08-12 12:40:32.628878	2010-08-12 12:40:32.628878	no	391
392	2010-08-12	4.7999999999999998	248	312	19	1	2010-08-12 12:43:03.860504	2010-08-12 12:43:03.860504	no	392
422	2010-08-15	5.2000000000000002	0.80000000000000004	4	7	2	2010-08-15 11:28:41.712907	2010-08-15 11:28:41.712907	no	422
394	2010-08-12	4.9000000000000004	4.5	8	3	2	2010-08-12 12:48:15.617472	2010-08-12 12:48:15.617472	no	394
395	2010-08-12	4.7000000000000002	11.5	32	3	1	2010-08-12 12:52:08.835549	2010-08-12 12:52:08.835549	no	395
393	2010-08-12	5.2999999999999998	3.1000000000000001	16	1	24	2010-08-12 12:45:41.599883	2010-08-12 12:55:29.614108	yes	393
397	2010-08-12	10	0.5	7	14	10	2010-08-12 12:57:28.263009	2010-08-12 12:57:28.263009	no	397
398	2010-08-12	5.2000000000000002	10.5	4	2	2	2010-08-12 13:00:43.411079	2010-08-12 13:00:43.411079	no	398
399	2010-08-12	5.2000000000000002	8.0999999999999996	4	2	2	2010-08-12 13:02:21.014611	2010-08-12 13:02:21.014611	no	399
401	2010-08-13	7	13	8	19	11	2010-08-13 11:48:15.103516	2010-08-13 11:48:15.103516	no	401
402	2010-08-13	0	0	8	14	6	2010-08-13 11:49:56.538029	2010-08-13 11:49:56.538029	yes	402
403	2010-08-13	5.2000000000000002	1.2	4	1	23	2010-08-13 11:51:49.198505	2010-08-13 11:51:49.198505	yes	403
404	2010-08-13	5.2000000000000002	5.7000000000000002	22	26	2	2010-08-13 11:53:10.962685	2010-08-13 11:53:10.962685	no	404
405	2010-08-13	0	0	6	14	6	2010-08-13 11:54:17.901696	2010-08-13 11:54:17.901696	no	405
396	2010-08-12	5.2000000000000002	3.1000000000000001	7	1	2	2010-08-12 12:53:37.382252	2010-08-13 12:59:02.942024	yes	396
400	2010-08-12	5.2000000000000002	2.3999999999999999	4	34	14	2010-08-12 13:04:13.69478	2010-08-13 12:59:50.146653	yes	400
406	2010-08-14	5.2000000000000002	0.59999999999999998	4	2	2	2010-08-14 10:56:18.881447	2010-08-14 10:56:18.881447	no	406
407	2010-08-14	8	47.5	75.5	11	4	2010-08-14 10:58:04.608885	2010-08-14 10:58:04.608885	no	407
408	2010-08-14	0	0	6	32	6	2010-08-14 10:59:26.605353	2010-08-14 10:59:42.698898	yes	408
409	2010-08-14	17	11.4	40	1	20	2010-08-14 11:01:21.00993	2010-08-14 11:01:21.00993	yes	409
410	2010-08-14	5.2000000000000002	3.8999999999999999	4	1	2	2010-08-14 11:04:14.333107	2010-08-14 11:04:14.333107	yes	410
411	2010-08-14	5.2000000000000002	1.8999999999999999	0	34	14	2010-08-14 11:05:37.327943	2010-08-14 11:05:37.327943	yes	411
412	2010-08-14	4.9000000000000004	6.0999999999999996	8	3	2	2010-08-14 11:06:55.876157	2010-08-14 11:06:55.876157	no	412
413	2010-08-14	0	0	2	14	6	2010-08-14 11:08:12.682649	2010-08-14 11:08:12.682649	no	413
414	2010-08-15	2	185	0	1	13	2010-08-15 11:10:17.120681	2010-08-15 11:10:17.120681	yes	414
415	2010-08-15	14	0.80000000000000004	2	7	3	2010-08-15 11:12:16.235382	2010-08-15 11:12:16.235382	no	415
416	2010-08-15	17	2.6000000000000001	8	7	18	2010-08-15 11:13:44.344216	2010-08-15 11:13:44.344216	no	416
417	2010-08-15	5.2000000000000002	6.4000000000000004	32	7	2	2010-08-15 11:15:02.972803	2010-08-15 11:15:02.972803	no	417
418	2010-08-15	5.2000000000000002	8.1999999999999993	8	1	2	2010-08-15 11:21:38.035469	2010-08-15 11:21:38.035469	yes	418
419	2010-08-15	14	1.1499999999999999	2	1	3	2010-08-15 11:23:51.735475	2010-08-15 11:23:51.735475	yes	419
420	2010-08-15	5.2000000000000002	7.5	6	1	14	2010-08-15 11:25:16.893307	2010-08-15 11:25:16.893307	yes	420
423	2010-08-15	4.7000000000000002	12.300000000000001	32	3	1	2010-08-15 11:29:54.513423	2010-08-15 11:29:54.513423	no	423
424	2010-08-15	5.2000000000000002	6	6	19	2	2010-08-15 11:31:10.558079	2010-08-15 11:31:10.558079	no	424
426	2010-08-16	0	0	15	32	6	2010-08-16 12:06:10.264337	2010-08-16 12:06:26.55199	yes	426
427	2010-08-16	10	26.5	26	8	9	2010-08-16 12:07:40.798518	2010-08-16 12:07:40.798518	no	427
428	2010-08-16	5.2000000000000002	270	640	6	14	2010-08-16 12:09:18.193315	2010-08-16 12:09:18.193315	no	428
429	2010-08-16	0	0	6	3	6	2010-08-16 12:10:33.070783	2010-08-16 12:10:33.070783	no	429
430	2010-08-16	4.9000000000000004	12.300000000000001	16	3	2	2010-08-16 12:11:52.47481	2010-08-16 12:11:52.47481	no	430
431	2010-08-16	4.7000000000000002	26.300000000000001	64	3	1	2010-08-16 12:13:06.370673	2010-08-16 12:13:06.370673	no	431
432	2010-08-17	5.2000000000000002	40.799999999999997	76	30	2	2010-08-17 12:49:56.764921	2010-08-17 12:49:56.764921	yes	432
433	2010-08-17	17	5	4	20	18	2010-08-17 12:53:20.334727	2010-08-17 12:53:20.334727	no	433
434	2010-08-17	4.7999999999999998	8.6999999999999993	12	20	1	2010-08-17 12:55:31.722208	2010-08-17 12:55:31.722208	no	434
435	2010-08-17	5.2000000000000002	17.699999999999999	8	20	2	2010-08-17 12:57:15.021809	2010-08-17 12:57:15.021809	no	435
436	2010-08-17	7.5	67	16	30	15	2010-08-17 13:00:44.501261	2010-08-17 13:00:44.501261	yes	436
437	2010-08-17	7	37.5	32	30	2	2010-08-17 13:02:15.65124	2010-08-17 13:02:15.65124	yes	437
438	2010-08-18	5.2000000000000002	1.6000000000000001	2	1	14	2010-08-18 13:05:06.203698	2010-08-18 13:05:06.203698	yes	438
439	2010-08-18	5.2000000000000002	1.2	1	1	14	2010-08-18 13:06:30.529198	2010-08-18 13:06:30.529198	yes	439
440	2010-08-18	4.7999999999999998	83	40	32	1	2010-08-18 13:08:10.308452	2010-08-18 13:08:38.763413	no	440
441	2010-08-18	4.7999999999999998	40	18	2	1	2010-08-18 13:10:34.609832	2010-08-18 13:10:34.609832	no	441
442	2010-08-18	5.2000000000000002	3.7000000000000002	2	7	22	2010-08-18 13:13:47.417319	2010-08-18 13:13:47.417319	no	442
443	2010-08-18	4.9000000000000004	5.9000000000000004	8	3	2	2010-08-18 13:16:40.759537	2010-08-18 13:16:40.759537	no	443
444	2010-08-18	4.7000000000000002	8.9000000000000004	28	3	1	2010-08-18 13:18:11.220052	2010-08-19 13:08:58.643153	no	444
446	2010-08-18	8	48	52	11	4	2010-08-18 14:28:19.518204	2010-08-18 14:28:19.518204	no	445
447	2010-08-18	4.7999999999999998	1.3	6	1	1	2010-08-18 14:30:04.877059	2010-08-18 14:30:04.877059	yes	447
448	2010-08-18	7.5	13	8	19	15	2010-08-18 14:31:26.577211	2010-08-18 14:31:26.577211	no	448
449	2010-08-18	5.2000000000000002	18	40	19	2	2010-08-18 14:32:55.53085	2010-08-18 14:32:55.53085	no	449
450	2010-08-19	5.2000000000000002	62.799999999999997	24	5	2	2010-08-19 11:35:50.253697	2010-08-19 11:35:50.253697	no	450
451	2010-08-19	5.2000000000000002	9.5	18	15	22	2010-08-19 11:37:10.89921	2010-08-19 11:37:10.89921	no	451
453	2010-08-19	5.2000000000000002	2	2	1	2	2010-08-19 11:40:34.378427	2010-08-19 11:40:34.378427	yes	452
454	2010-08-19	5.2000000000000002	0.29999999999999999	0	32	2	2010-08-19 11:42:17.456232	2010-08-19 11:42:17.456232	no	454
455	2010-08-19	10	22	26	8	9	2010-08-19 11:43:46.698554	2010-08-19 11:43:46.698554	no	455
456	2010-08-19	5.2000000000000002	5	16	19	2	2010-08-19 11:45:26.631966	2010-08-19 11:45:26.631966	no	456
457	2010-08-20	5.2000000000000002	0.90000000000000002	65	7	14	2010-08-20 13:32:01.501101	2010-08-20 13:32:01.501101	no	457
459	2010-08-20	7.5	9.5	5	1	15	2010-08-20 13:34:53.026829	2010-08-20 13:34:53.026829	yes	459
460	2010-08-20	5.2000000000000002	3.7999999999999998	8	1	2	2010-08-20 13:36:22.186124	2010-08-20 13:36:22.186124	yes	460
461	2010-08-20	5.2000000000000002	7.2999999999999998	8	33	2	2010-08-20 13:37:36.332489	2010-08-20 13:37:36.332489	yes	461
462	2010-08-20	5.2000000000000002	7.2999999999999998	8	19	2	2010-08-20 13:38:56.714988	2010-08-20 13:38:56.714988	no	462
463	2010-08-20	14	30	0	28	20	2010-08-20 13:40:12.545875	2010-08-20 13:40:12.545875	no	463
464	2010-08-20	5.2000000000000002	0.59999999999999998	1	1	2	2010-08-20 13:41:41.835755	2010-08-20 13:41:41.835755	yes	464
465	2010-08-20	5.2000000000000002	2.5	10	26	2	2010-08-20 13:43:43.537907	2010-08-20 13:43:43.537907	yes	465
466	2010-08-20	10	4.0999999999999996	11	29	10	2010-08-20 13:45:03.434721	2010-08-20 13:45:03.434721	no	466
467	2010-08-20	14	1.2	2	34	3	2010-08-20 13:47:02.75373	2010-08-20 13:47:02.75373	yes	467
468	2010-08-20	5.2000000000000002	8.5	3	34	14	2010-08-20 13:48:24.585152	2010-08-20 13:48:24.585152	yes	468
469	2010-08-20	5.2000000000000002	104.3	124	30	2	2010-08-20 13:49:45.985276	2010-08-20 15:13:32.661034	yes	469
458	2010-08-20	7.5	68.5	30	30	15	2010-08-20 13:33:30.44151	2010-08-20 15:14:02.516764	yes	458
470	2010-08-21	9	21	26	1	4	2010-08-21 11:50:01.266568	2010-08-21 11:50:01.266568	yes	470
471	2010-08-21	0	0	55	26	6	2010-08-21 11:51:43.824395	2010-08-21 11:51:43.824395	no	471
472	2010-08-21	5.2000000000000002	0.59999999999999998	2	34	14	2010-08-21 11:52:56.651332	2010-08-21 11:52:56.651332	yes	472
473	2010-08-21	5.2000000000000002	5	4	1	2	2010-08-21 11:54:42.664546	2010-08-21 11:54:42.664546	yes	473
474	2010-08-21	0	0	168	22	6	2010-08-21 11:55:46.420441	2010-08-21 11:55:46.420441	no	474
475	2010-08-21	4.9000000000000004	7.4000000000000004	12	3	2	2010-08-21 11:57:13.033878	2010-08-21 11:57:13.033878	no	475
476	2010-08-21	4.7000000000000002	17	32	3	1	2010-08-21 11:58:23.176555	2010-08-21 11:58:23.176555	no	476
477	2010-08-21	5.2000000000000002	5.5	7	1	2	2010-08-21 11:59:48.893217	2010-08-21 11:59:48.893217	yes	477
478	2010-08-21	10	4.5999999999999996	2	34	10	2010-08-21 12:01:00.673463	2010-08-21 12:01:00.673463	yes	478
479	2010-08-21	10	30.5	26	8	9	2010-08-21 12:02:13.712074	2010-08-21 12:02:13.712074	no	479
480	2010-08-21	8.5	56.5	52	11	9	2010-08-21 12:03:35.363165	2010-08-21 12:03:35.363165	no	480
481	2010-08-21	5.2000000000000002	5.0999999999999996	4	1	2	2010-08-21 12:04:54.853606	2010-08-21 12:04:54.853606	yes	481
482	2010-08-22	5.2000000000000002	5	7	1	2	2010-08-22 11:45:58.630895	2010-08-22 11:45:58.630895	yes	482
483	2010-08-22	5.2000000000000002	6.25	4	1	2	2010-08-22 11:47:03.20287	2010-08-22 11:47:03.20287	yes	483
484	2010-08-22	4.9000000000000004	9.8000000000000007	16	3	2	2010-08-22 11:48:22.020981	2010-08-22 11:48:22.020981	no	484
485	2010-08-22	4.7000000000000002	16.600000000000001	32	3	1	2010-08-22 11:50:01.005441	2010-08-22 11:50:01.005441	no	485
487	2010-08-22	4.7999999999999998	96.5	32	14	1	2010-08-22 11:52:12.032356	2010-08-22 11:52:12.032356	no	487
488	2010-08-22	4.7999999999999998	26	24	2	1	2010-08-22 11:53:43.529796	2010-08-22 11:53:43.529796	no	488
489	2010-08-22	4.7999999999999998	40.5	32	31	1	2010-08-22 11:55:23.71644	2010-08-22 11:55:23.71644	no	489
491	2010-08-22	5.2000000000000002	1.3999999999999999	0	34	14	2010-08-22 11:59:43.239573	2010-08-22 11:59:43.239573	no	491
492	2010-08-22	5.2000000000000002	15.300000000000001	20	1	2	2010-08-22 12:02:26.978822	2010-08-22 12:02:26.978822	yes	492
493	2010-08-22	5.2000000000000002	13.199999999999999	12	1	2	2010-08-22 12:03:57.758787	2010-08-22 12:04:10.859716	yes	493
494	2010-08-22	5.2000000000000002	4.9000000000000004	8	1	2	2010-08-22 12:05:47.350774	2010-08-22 12:06:00.353434	yes	494
495	2010-08-22	5.2000000000000002	5.7999999999999998	8	1	2	2010-08-22 12:07:30.452384	2010-08-22 12:07:40.799154	yes	495
496	2010-08-22	5.2000000000000002	1.2	2	34	14	2010-08-22 12:10:56.790222	2010-08-22 12:10:56.790222	yes	496
490	2010-08-22	4.7999999999999998	36	38	31	1	2010-08-22 11:56:58.81883	2010-08-22 12:21:08.075428	no	490
497	2010-08-23	2	125	0	1	13	2010-08-23 11:52:02.719988	2010-08-23 11:52:11.910612	yes	497
498	2010-08-23	0	0	4	22	6	2010-08-23 11:53:22.386372	2010-08-23 11:53:22.386372	no	498
499	2010-08-23	9	11.199999999999999	8	29	4	2010-08-23 11:54:38.204817	2010-08-23 11:54:38.204817	no	499
500	2010-08-23	10	7.3499999999999996	2	34	10	2010-08-23 11:56:13.577384	2010-08-23 11:56:13.577384	yes	500
501	2010-08-23	5.2000000000000002	4.5999999999999996	2	34	2	2010-08-23 11:58:34.775063	2010-08-23 11:58:34.775063	yes	501
502	2010-08-23	4.7999999999999998	21	56	1	1	2010-08-23 12:00:30.383653	2010-08-23 12:00:30.383653	yes	502
503	2010-08-23	0	0	6	29	6	2010-08-23 12:02:01.420428	2010-08-23 12:02:01.420428	no	503
504	2010-08-23	9	31.5	24	32	4	2010-08-23 12:04:54.616882	2010-08-23 12:04:54.616882	no	504
505	2010-08-23	5.5	2.7999999999999998	8	32	24	2010-08-23 12:06:56.931259	2010-08-23 12:06:56.931259	no	505
506	2010-08-23	9	57.5	48	32	4	2010-08-23 12:08:34.032406	2010-08-23 12:08:34.032406	no	506
507	2010-08-24	5.2000000000000002	1.3	4	1	2	2010-08-24 11:31:32.031698	2010-08-24 11:31:32.031698	yes	507
508	2010-08-24	0	0	6	14	6	2010-08-24 11:32:58.802088	2010-08-24 11:32:58.802088	no	508
509	2010-08-24	5.2000000000000002	22	32	32	2	2010-08-24 11:34:54.992663	2010-08-24 11:34:54.992663	no	509
510	2010-08-24	5.2000000000000002	4	12	6	22	2010-08-24 11:36:18.76754	2010-08-24 11:36:18.76754	no	510
511	2010-08-24	5.2000000000000002	4.2000000000000002	16	33	2	2010-08-24 11:37:40.284565	2010-08-24 11:37:40.284565	yes	511
512	2010-08-24	5.2000000000000002	2.2000000000000002	8	22	2	2010-08-24 11:38:56.401512	2010-08-24 11:38:56.401512	no	512
513	2010-08-24	5.2000000000000002	4.5	8	34	14	2010-08-24 11:41:14.156709	2010-08-24 11:41:14.156709	yes	513
514	2010-08-24	5.2000000000000002	8.3000000000000007	0	21	22	2010-08-24 11:42:44.661167	2010-08-24 11:42:44.661167	no	514
515	2010-08-24	0	0	6	32	6	2010-08-24 11:43:58.708385	2010-08-24 11:43:58.708385	no	515
516	2010-08-24	0	0	5	22	6	2010-08-24 11:44:58.167867	2010-08-24 11:44:58.167867	no	516
518	2010-08-25	5.2000000000000002	2	0	34	14	2010-08-25 12:19:26.680794	2010-08-25 12:19:46.035943	yes	518
517	2010-08-25	8.5	3.2999999999999998	0	34	5	2010-08-25 12:18:05.035342	2010-08-25 12:20:00.277761	yes	517
519	2010-08-25	5	2.5	8	3	2	2010-08-25 12:21:31.427311	2010-08-25 12:21:31.427311	no	519
520	2010-08-25	4.7999999999999998	22.199999999999999	60	3	1	2010-08-25 12:22:51.347465	2010-08-25 12:22:51.347465	no	520
521	2010-08-25	5.2000000000000002	20	32	2	2	2010-08-25 12:24:38.063446	2010-08-25 12:24:38.063446	no	521
522	2010-08-25	5.2000000000000002	19.399999999999999	12	24	14	2010-08-25 12:26:42.414537	2010-08-25 12:26:42.414537	no	522
523	2010-08-25	14.5	9.6999999999999993	12	24	3	2010-08-25 12:27:51.601061	2010-08-25 12:27:51.601061	no	523
524	2010-08-25	17	5.5	22	24	18	2010-08-25 12:29:21.998103	2010-08-25 12:29:21.998103	no	524
525	2010-08-25	4.7999999999999998	117	96	31	1	2010-08-25 12:30:53.643943	2010-08-25 12:30:53.643943	no	525
526	2010-08-25	10	121.5	104	8	9	2010-08-25 12:32:11.892208	2010-08-25 12:32:11.892208	no	526
527	2010-08-25	8	19	26	10	4	2010-08-25 12:33:43.099607	2010-08-25 12:33:43.099607	no	527
528	2010-08-25	8	63	52	11	4	2010-08-25 12:35:18.050214	2010-08-25 12:35:18.050214	no	528
529	2010-08-25	5.2000000000000002	5.5999999999999996	16	2	2	2010-08-25 12:36:37.657714	2010-08-25 12:36:37.657714	no	529
530	2010-08-25	4.7999999999999998	3.7999999999999998	26	14	1	2010-08-25 12:38:22.521015	2010-08-25 12:38:22.521015	no	530
531	2010-08-25	5.2000000000000002	13	48	19	2	2010-08-25 12:39:56.540113	2010-08-25 12:39:56.540113	no	531
532	2010-08-25	9	0	6	14	6	2010-08-25 12:40:49.765634	2010-08-25 12:40:49.765634	no	532
533	2010-08-26	5	25.300000000000001	28	3	2	2010-08-26 11:45:13.572257	2010-08-26 11:45:13.572257	no	533
534	2010-08-26	4.7999999999999998	55.399999999999999	128	3	1	2010-08-26 11:46:49.506171	2010-08-26 11:46:49.506171	no	534
535	2010-08-26	5.2000000000000002	7.2999999999999998	22	29	2	2010-08-26 11:48:03.886578	2010-08-26 11:48:03.886578	yes	535
537	2010-08-26	5.2000000000000002	3.2999999999999998	4	32	2	2010-08-26 11:51:05.005244	2010-08-26 11:51:05.005244	no	537
543	2010-08-26	0	0	5	22	6	2010-08-26 12:00:57.249732	2010-08-26 12:00:57.249732	no	543
544	2010-08-27	8	53.5	105	11	9	2010-08-27 11:38:09.172524	2010-08-27 11:38:09.172524	no	544
545	2010-08-27	5.2000000000000002	2.1000000000000001	0	1	22	2010-08-27 11:39:48.073738	2010-08-27 11:39:48.073738	yes	545
546	2010-08-27	5.2000000000000002	5.7999999999999998	2	34	14	2010-08-27 11:41:24.651983	2010-08-27 11:41:24.651983	yes	546
547	2010-08-27	5.2000000000000002	72	32	30	2	2010-08-27 11:42:39.601579	2010-08-27 11:42:39.601579	yes	547
550	2010-08-27	19	4.5	49	10	18	2010-08-27 11:46:42.070519	2010-08-27 11:46:42.070519	no	550
551	2010-08-27	5.2000000000000002	2.2999999999999998	0	34	14	2010-08-27 11:47:49.328641	2010-08-27 11:47:49.328641	yes	551
552	2010-08-27	5.2000000000000002	6.7000000000000002	8	14	23	2010-08-27 11:49:16.455694	2010-08-27 11:49:16.455694	no	552
549	2010-08-27	5.2000000000000002	135.09999999999999	128	1	2	2010-08-27 11:45:07.794151	2010-08-28 13:51:57.803984	yes	549
548	2010-08-27	5.2000000000000002	73.599999999999994	45	1	2	2010-08-27 11:44:09.791014	2010-08-28 13:52:23.976382	yes	548
542	2010-08-26	5.2000000000000002	2.3999999999999999	6	1	14	2010-08-26 11:59:58.5441	2010-08-28 13:52:53.488635	yes	542
553	2010-08-27	5	16	20	3	2	2010-08-27 11:50:15.947561	2010-08-27 11:50:15.947561	no	553
554	2010-08-27	4.7999999999999998	40.600000000000001	64	3	1	2010-08-27 11:51:15.303254	2010-08-27 11:51:15.303254	no	554
540	2010-08-26	7	77	60	30	11	2010-08-26 11:55:18.174463	2010-08-27 11:51:44.059817	yes	540
539	2010-08-26	5.2000000000000002	10	20	30	2	2010-08-26 11:54:07.70512	2010-08-27 11:52:12.379302	yes	539
536	2010-08-26	5.2000000000000002	75	32	30	2	2010-08-26 11:49:50.989793	2010-08-27 11:52:40.633574	yes	536
541	2010-08-26	5.2000000000000002	9.0999999999999996	32	34	14	2010-08-26 11:56:42.325111	2010-08-27 11:53:21.414195	yes	541
538	2010-08-26	17	10	10	29	18	2010-08-26 11:52:46.190493	2010-08-27 11:53:46.898273	yes	538
560	2010-08-28	11	2	8	1	19	2010-08-28 13:21:01.684579	2010-08-28 13:21:01.684579	yes	555
561	2010-08-28	5.2000000000000002	0.5	0	1	22	2010-08-28 13:22:52.415384	2010-08-28 13:22:52.415384	yes	561
562	2010-08-28	4.7999999999999998	16	22	32	1	2010-08-28 13:23:46.683799	2010-08-28 13:23:46.683799	no	562
563	2010-08-28	5.2000000000000002	118	210	6	22	2010-08-28 13:26:40.579108	2010-08-28 13:26:40.579108	no	563
564	2010-08-28	5	5.5	10	3	2	2010-08-28 13:28:13.168034	2010-08-28 13:28:13.168034	no	564
565	2010-08-28	4.7999999999999998	11.6	30	3	1	2010-08-28 13:29:20.010998	2010-08-28 13:29:20.010998	no	565
566	2010-08-28	5	2.5	8	3	2	2010-08-28 13:30:32.676496	2010-08-28 13:30:32.676496	no	566
567	2010-08-28	17	6.5	0	20	18	2010-08-28 13:31:56.052454	2010-08-28 13:31:56.052454	no	567
568	2010-08-28	5.2000000000000002	7	0	20	2	2010-08-28 13:33:07.496616	2010-08-28 13:33:07.496616	no	568
569	2010-08-28	5.2000000000000002	7	0	20	2	2010-08-28 13:33:15.934509	2010-08-28 13:33:15.934509	no	568
570	2010-08-28	5	6.5	16	20	1	2010-08-28 13:34:33.041846	2010-08-28 13:34:33.041846	no	570
571	2010-08-28	14	54.5	0	28	20	2010-08-28 13:35:47.291192	2010-08-28 13:35:47.291192	no	571
572	2010-08-28	5.2000000000000002	2.7000000000000002	2	7	2	2010-08-28 13:37:24.856123	2010-08-28 13:37:24.856123	no	572
573	2010-08-28	8.5	0.80000000000000004	0	7	5	2010-08-28 13:38:49.966278	2010-08-28 13:38:49.966278	no	573
574	2010-08-28	4.7999999999999998	10	48	7	1	2010-08-28 13:40:12.72261	2010-08-28 13:40:12.72261	no	574
575	2010-08-28	5.2000000000000002	54.5	40	5	2	2010-08-28 13:41:24.358099	2010-08-28 13:41:24.358099	no	575
425	2010-08-15	0	0	2	3	6	2010-08-15 11:32:05.187721	2010-08-28 13:47:37.203814	no	425
486	2010-08-22	0	0	10	3	6	2010-08-22 11:50:46.861581	2010-08-28 13:48:46.641275	no	486
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY products (id, name, price, created_at, updated_at) FROM stdin;
9	原钢板	6.7999999999999998	2010-07-12 12:38:00.055862	2010-07-21 12:53:49.107187
5	冲头柄	6	2010-07-11 13:16:50.925067	2010-07-21 13:00:33.12482
8	2钨8	38	2010-07-12 12:33:57.084385	2010-07-21 13:01:07.660829
10	弹簧钢	7.5	2010-07-15 13:26:22.584052	2010-07-21 13:01:23.151229
11	中碳锻件	6.5	2010-07-15 13:28:12.78282	2010-07-21 13:01:44.543842
13	铁削	0.5	2010-07-16 12:46:09.376583	2010-07-21 13:12:03.938122
15	40铬锻件	7.0999999999999996	2010-07-19 18:15:12.441836	2010-07-21 15:35:26.14649
7	40铬	5.7999999999999998	2010-07-12 12:31:41.70436	2010-07-21 15:41:37.834128
18	铬12板	14	2010-07-21 15:53:01.522713	2010-07-21 15:53:01.522713
19	铬12一般	7.5	2010-07-22 13:57:11.881216	2010-07-22 13:57:11.881216
20	4铬13	11.199999999999999	2010-07-22 14:03:37.163971	2010-07-22 14:03:37.163971
4	42Cy板	6.7999999999999998	2010-07-10 10:43:56.561367	2010-07-22 14:05:07.626506
21	42Cy锻	8.4000000000000004	2010-07-22 14:05:29.57258	2010-07-22 14:05:29.57258
16	40铬板	5.7999999999999998	2010-07-19 18:15:38.53075	2010-07-22 14:08:04.900016
3	铬12圆钢	12	2010-07-10 10:43:56.552027	2010-07-22 14:19:32.821139
1	A3板	4.5999999999999996	2010-07-09 17:56:12.251746	2010-07-22 14:32:21.205372
22	A3圆	4.5	2010-07-22 14:32:46.992869	2010-07-22 14:32:46.992869
14	中碳圆	4.5	2010-07-19 18:13:44.486842	2010-07-22 14:36:29.029249
23	中碳板12	5	2010-07-27 13:35:11.135868	2010-07-27 13:35:11.135868
24	中碳板10	5.2000000000000002	2010-07-27 13:35:35.160121	2010-07-27 13:35:35.160121
2	中碳板16	4.7999999999999998	2010-07-10 10:43:55.795157	2010-07-27 13:36:02.867819
17	中碳方块50	5.5	2010-07-21 13:04:38.492183	2010-08-11 16:15:50.240274
25	中碳方块55	5.5999999999999996	2010-08-11 16:16:28.949346	2010-08-11 16:16:28.949346
12	铬12正锻	14.380000000000001	2010-07-15 13:28:42.526965	2010-08-21 14:08:26.24296
6	加工	0	2010-07-11 15:36:15.581661	2010-08-22 03:14:18.114805
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY purchases (id, date, product_id, price, volume, created_at, updated_at, seq_no) FROM stdin;
52	2010-08-14	14	4.7000000000000002	38	2010-08-14 11:15:22.401978	2010-08-14 11:15:22.401978	52
53	2010-08-16	15	7.0999999999999996	3.2000000000000002	2010-08-16 15:03:21.735584	2010-08-16 15:03:21.735584	53
54	2010-08-17	15	7.0999999999999996	67	2010-08-17 13:03:54.530717	2010-08-17 13:03:54.530717	54
55	2010-08-17	11	6.2000000000000002	37.5	2010-08-17 13:05:38.506505	2010-08-17 13:05:38.506505	55
57	2010-08-17	6	55	2	2010-08-17 13:07:46.235852	2010-08-17 13:07:46.235852	57
58	2010-08-10	1	4.5999999999999996	75.5	2010-08-18 14:37:47.825972	2010-08-18 14:37:47.825972	58
59	2010-08-10	1	4.5999999999999996	92	2010-08-18 14:38:59.963958	2010-08-18 14:38:59.963958	59
1	2010-07-19	1	4.5999999999999996	279	2010-07-19 18:11:23.636713	2010-08-01 15:49:40.906588	1
6	2010-07-18	16	5.7999999999999998	197	2010-07-20 12:32:34.021728	2010-08-01 15:49:40.985438	6
9	2010-07-20	16	5.7999999999999998	186	2010-07-20 12:35:52.83438	2010-08-01 15:49:40.988236	9
10	2010-07-22	12	14	11.5	2010-07-22 14:24:53.228107	2010-08-01 15:49:40.99078	10
11	2010-07-22	11	6.5	11	2010-07-22 14:26:19.447497	2010-08-01 15:49:40.99353	11
12	2010-07-22	15	7.0999999999999996	120.5	2010-07-22 14:29:11.749044	2010-08-01 15:49:40.996278	12
5	2010-07-18	15	7.0999999999999996	40	2010-07-20 12:31:12.708206	2010-08-01 15:49:40.998739	5
8	2010-07-17	2	4.7000000000000002	568	2010-07-20 12:34:41.137553	2010-08-01 15:49:41.001259	8
2	2010-07-20	14	4.2000000000000002	57	2010-07-20 12:25:07.756401	2010-08-01 15:49:41.003815	2
7	2010-07-18	2	4.7000000000000002	36	2010-07-20 12:33:34.072992	2010-08-01 15:49:41.006332	7
13	2010-07-11	1	4.4000000000000004	557	2010-07-25 13:19:34.143676	2010-08-01 15:49:41.008781	13
14	2010-07-14	1	4.4000000000000004	442.5	2010-07-25 13:21:28.776819	2010-08-01 15:49:41.01149	14
16	2010-07-14	1	4.5999999999999996	76.5	2010-07-25 13:23:40.819298	2010-08-01 15:49:41.014038	16
18	2010-07-18	1	4.5999999999999996	279	2010-07-25 13:27:22.18995	2010-08-01 15:49:41.016514	18
19	2010-07-23	1	4.5999999999999996	235	2010-07-25 13:30:21.830422	2010-08-01 15:49:41.019108	19
20	2010-07-18	11	6.5	5.5	2010-07-25 13:32:39.540401	2010-08-01 15:49:41.021527	20
21	2010-07-19	12	14.5	9	2010-07-25 13:33:49.872481	2010-08-01 15:49:41.024014	21
22	2010-07-25	2	4.7000000000000002	493	2010-07-25 13:35:50.345914	2010-08-01 15:49:41.026702	22
23	2010-07-19	14	4.2000000000000002	57	2010-07-25 13:52:36.958862	2010-08-01 15:49:41.029163	23
24	2010-07-19	14	4.25	175	2010-07-25 13:53:44.589343	2010-08-01 15:49:41.031617	24
25	2010-07-24	22	4.2999999999999998	174	2010-07-25 13:56:13.759103	2010-08-01 15:49:41.034164	25
26	2010-07-27	2	4.7999999999999998	217.5	2010-07-27 13:29:56.164546	2010-08-01 15:49:41.036652	26
27	2010-07-27	23	5	104	2010-07-27 13:31:36.718437	2010-08-01 15:49:41.039158	27
28	2010-07-29	12	14.5	8.8000000000000007	2010-07-29 11:48:59.35421	2010-08-01 15:49:41.041692	28
29	2010-07-29	24	5.4000000000000004	228	2010-07-29 11:50:41.588259	2010-08-01 15:49:41.044209	29
30	2010-08-01	15	7.0999999999999996	8	2010-08-01 11:30:18.398529	2010-08-01 15:49:41.046739	30
31	2010-08-01	2	4.7999999999999998	299	2010-08-01 11:31:25.099456	2010-08-01 15:49:41.049197	31
32	2010-08-01	16	5.7000000000000002	225.5	2010-08-01 11:32:59.49655	2010-08-01 15:49:41.051662	32
33	2010-08-03	1	4.5999999999999996	415.5	2010-08-03 11:27:03.62044	2010-08-03 11:27:33.845546	33
34	2010-08-03	1	4.4000000000000004	343	2010-08-03 11:28:32.813065	2010-08-03 11:28:32.813065	34
35	2010-08-03	15	7.0999999999999996	54	2010-08-03 11:29:27.560494	2010-08-03 11:29:27.560494	35
36	2010-08-04	12	14.5	17.5	2010-08-04 13:40:38.242148	2010-08-04 13:40:38.242148	36
37	2010-08-04	2	4.7999999999999998	187.5	2010-08-04 13:42:06.086869	2010-08-04 13:42:06.086869	37
39	2010-08-05	1	4.5999999999999996	185	2010-08-05 17:29:49.066951	2010-08-05 17:29:49.066951	39
40	2010-08-05	1	4.5999999999999996	17	2010-08-05 17:30:47.429243	2010-08-05 17:30:47.429243	40
38	2010-08-05	15	7.0999999999999996	6.2000000000000002	2010-08-05 17:28:30.145036	2010-08-06 13:19:11.765595	38
41	2010-08-09	15	7.0999999999999996	171	2010-08-09 11:54:43.671725	2010-08-09 11:54:43.671725	41
42	2010-08-09	11	6.2000000000000002	13	2010-08-09 11:57:19.583008	2010-08-09 11:57:19.583008	42
44	2010-08-10	16	5.7000000000000002	716	2010-08-10 13:44:45.506562	2010-08-10 13:44:45.506562	43
45	2010-08-10	16	5.7000000000000002	216.5	2010-08-10 13:45:51.14827	2010-08-10 13:45:51.14827	45
46	2010-08-11	15	7.0999999999999996	36.5	2010-08-11 16:09:21.922252	2010-08-11 16:09:21.922252	46
47	2010-08-11	2	5	439	2010-08-11 16:10:27.429639	2010-08-11 16:10:27.429639	47
60	2010-08-10	1	4.5999999999999996	248	2010-08-18 14:40:55.808427	2010-08-18 14:40:55.808427	60
48	2010-08-11	17	5.5	94	2010-08-11 16:11:48.295192	2010-08-11 16:16:54.211529	48
49	2010-08-11	25	5.5999999999999996	68.5	2010-08-11 16:13:38.142648	2010-08-11 16:17:10.350541	49
50	2010-08-14	22	4.5	86	2010-08-14 11:12:53.552006	2010-08-14 11:12:53.552006	50
51	2010-08-14	14	4.5999999999999996	90	2010-08-14 11:14:34.588774	2010-08-14 11:14:34.588774	51
61	2010-08-18	15	7.0999999999999996	13	2010-08-18 14:42:02.960598	2010-08-18 14:42:02.960598	61
62	2010-08-18	1	4.5999999999999996	83	2010-08-18 14:42:56.283152	2010-08-18 14:42:56.283152	62
63	2010-08-18	1	4.5999999999999996	40	2010-08-18 14:44:25.442625	2010-08-18 14:44:25.442625	63
64	2010-08-18	1	4.4000000000000004	122	2010-08-18 14:46:44.065526	2010-08-18 14:46:44.065526	64
65	2010-08-18	1	4.4000000000000004	322	2010-08-18 14:48:06.895274	2010-08-18 14:48:06.895274	65
66	2010-08-19	15	7.0999999999999996	68.5	2010-08-19 11:47:11.130295	2010-08-19 11:47:11.130295	66
56	2010-08-17	6	110	2	2010-08-17 13:07:12.042086	2010-08-19 13:11:44.152754	56
67	2010-08-20	2	5	115.5	2010-08-20 13:50:48.231653	2010-08-20 13:50:48.231653	67
68	2010-08-20	23	5.2000000000000002	45.5	2010-08-20 13:51:47.629214	2010-08-20 13:51:47.629214	68
69	2010-08-21	23	5.2000000000000002	33.5	2010-08-21 12:06:55.724936	2010-08-21 12:06:55.724936	69
70	2010-08-21	1	4.5999999999999996	199	2010-08-21 12:07:35.502695	2010-08-21 12:07:35.502695	70
71	2010-08-23	21	8	10	2010-08-23 12:11:51.209711	2010-08-23 12:11:51.209711	71
72	2010-08-23	20	11.5	895	2010-08-23 12:17:05.181619	2010-08-23 12:17:05.181619	72
73	2010-08-23	4	6.7999999999999998	2315	2010-08-23 12:18:47.43556	2010-08-23 12:18:47.43556	73
74	2010-08-23	18	12.699999999999999	360	2010-08-23 12:21:46.20652	2010-08-23 12:22:40.222645	74
75	2010-08-23	3	12.199999999999999	89	2010-08-23 12:24:13.303584	2010-08-23 12:24:13.303584	75
76	2010-08-23	3	11.699999999999999	106	2010-08-23 12:25:43.017137	2010-08-23 12:26:33.450896	76
77	2010-08-24	1	4.5999999999999996	117	2010-08-24 11:46:25.536856	2010-08-24 11:46:25.536856	77
78	2010-08-25	15	7.0999999999999996	78	2010-08-25 12:42:29.362259	2010-08-25 12:42:29.362259	78
79	2010-08-25	11	6.2000000000000002	77	2010-08-25 12:43:18.417853	2010-08-25 12:43:18.417853	79
80	2010-08-25	3	12.199999999999999	46	2010-08-25 12:44:04.568485	2010-08-25 12:44:04.568485	80
81	2010-08-26	15	7.0999999999999996	118	2010-08-26 12:01:59.853417	2010-08-26 12:01:59.853417	81
82	2010-08-27	2	5	94.5	2010-08-27 12:00:36.825262	2010-08-27 12:00:36.825262	82
83	2010-08-28	7	7.0999999999999996	308	2010-08-28 13:42:31.770306	2010-08-28 13:42:31.770306	83
\.


--
-- Data for Name: receivables; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY receivables (id, seq_no, date, customer_id, amount, created_at, updated_at) FROM stdin;
2	1	2010-08-02	5	10000	2010-08-03 11:32:14.690084	2010-08-03 11:32:14.690084
3	3	2010-07-01	28	-5215	2010-08-03 11:36:48.51923	2010-08-03 11:36:48.51923
4	4	2010-07-01	10	-8123	2010-08-03 11:37:29.845313	2010-08-03 11:37:29.845313
5	5	2010-07-01	11	-26653	2010-08-03 11:38:06.903435	2010-08-03 11:38:32.42744
6	6	2010-07-01	12	-9766	2010-08-03 11:39:24.55479	2010-08-03 11:39:24.55479
7	7	2010-07-01	13	-7413	2010-08-03 11:40:06.148901	2010-08-03 11:40:06.148901
8	8	2010-07-01	2	-9692	2010-08-03 11:40:42.41345	2010-08-03 11:40:42.41345
9	9	2010-07-01	14	-2058	2010-08-03 11:41:27.208269	2010-08-03 11:41:27.208269
10	10	2010-07-01	3	-31761	2010-08-03 11:42:00.336718	2010-08-03 11:42:00.336718
12	12	2010-07-01	15	-12080	2010-08-03 11:43:28.059292	2010-08-03 11:43:28.059292
13	13	2010-07-01	7	-7312	2010-08-03 11:43:54.000739	2010-08-03 11:43:54.000739
15	15	2010-07-01	17	-7093	2010-08-03 11:45:08.008545	2010-08-03 11:45:08.008545
17	17	2010-07-16	18	7000	2010-08-03 13:23:59.774823	2010-08-03 13:23:59.774823
18	18	2010-07-01	19	-25155	2010-08-03 13:25:29.834875	2010-08-03 13:25:29.834875
19	19	2010-07-16	12	9766	2010-08-03 13:28:51.180026	2010-08-03 13:28:51.180026
20	20	2010-07-26	12	2000	2010-08-03 13:29:26.661778	2010-08-03 13:29:26.661778
21	21	2010-08-04	25	2870	2010-08-04 13:43:24.101625	2010-08-04 13:44:05.978074
22	22	2010-08-05	32	1980	2010-08-05 17:32:00.906245	2010-08-05 17:32:00.906245
24	24	2010-08-08	16	8000	2010-08-08 10:55:21.69474	2010-08-08 10:55:21.69474
25	25	2010-08-08	32	350	2010-08-08 10:55:56.288306	2010-08-08 10:55:56.288306
11	11	2010-07-01	5	-14076	2010-08-03 11:42:49.654201	2010-08-08 10:59:37.394225
26	26	2010-07-01	18	-7028	2010-08-10 15:01:40.419155	2010-08-10 15:01:40.419155
27	27	2010-07-01	16	-8144	2010-08-10 15:02:14.639257	2010-08-10 15:02:14.639257
23	23	2010-08-06	33	848	2010-08-06 11:00:38.436031	2010-08-10 15:06:42.727135
28	28	2010-07-01	32	-1242	2010-08-10 16:24:04.337575	2010-08-10 16:24:04.337575
29	29	2010-08-11	33	1090	2010-08-11 16:03:37.528707	2010-08-11 16:08:03.419857
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY schema_migrations (version) FROM stdin;
20100826132305
20100703101301
20100705150624
20100705151124
20100705151548
20100707144524
20100707144821
20100710084758
20100710085040
20100711152631
20100715141845
20100719163739
20100801142229
20100801160437
20100814143227
20100819142530
20100820173049
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY suppliers (id, seq_no, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: leaf_057788813958; Owner: oeulrfrvfh
--

COPY users (id, username, crypted_password, password_salt, persistence_token, name, address, email, telephone, cell_phone, id_no, business_no, company, addtional, created_at, updated_at) FROM stdin;
\.


SET search_path = public, pg_catalog;

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY customers (id, name, created_at, updated_at) FROM stdin;
2	阿浩	2010-07-11 13:18:25.953046	2010-07-11 13:18:25.953046
3	克和	2010-07-11 15:43:43.934748	2010-07-11 15:43:43.934748
4	小宝	2010-07-12 12:28:23.384988	2010-07-12 12:28:23.384988
5	晓秋	2010-07-12 12:30:18.215332	2010-07-12 12:30:18.215332
6	阿松	2010-07-12 12:32:28.70216	2010-07-12 12:32:28.70216
7	五金厂	2010-07-12 12:35:10.372226	2010-07-12 12:35:10.372226
8	万里	2010-07-12 12:38:54.343754	2010-07-12 12:38:54.343754
9	畅旺	2010-07-15 12:23:32.534134	2010-07-15 12:23:32.534134
10	阿杰	2010-07-15 12:24:01.685021	2010-07-15 12:24:01.685021
11	李义	2010-07-15 12:24:43.931687	2010-07-15 12:24:43.931687
12	珍飞	2010-07-15 12:25:03.313239	2010-07-15 12:25:03.313239
13	阿志	2010-07-15 12:25:18.555094	2010-07-15 12:25:18.555094
14	阿雨	2010-07-15 12:25:39.521204	2010-07-15 12:25:39.521204
15	剑波	2010-07-15 12:25:59.757387	2010-07-15 12:25:59.757387
16	章才	2010-07-15 12:26:29.615089	2010-07-15 12:26:29.615089
17	江伟	2010-07-15 12:26:46.780314	2010-07-15 12:26:46.780314
18	吴阿克	2010-07-15 12:27:18.167061	2010-07-15 12:27:18.167061
19	阿寿	2010-07-15 12:27:45.39133	2010-07-15 12:27:45.39133
20	金鹿	2010-07-15 12:31:36.922785	2010-07-15 12:31:36.922785
21	阿进	2010-07-15 12:41:33.285822	2010-07-15 12:41:33.285822
22	金阿锐	2010-07-15 13:00:03.541786	2010-07-15 13:00:03.541786
23	阿海	2010-07-16 12:49:43.345227	2010-07-16 12:49:43.345227
24	阿鸿	2010-07-20 13:06:41.015066	2010-07-20 13:06:41.015066
25	阿微	2010-07-20 13:11:05.360023	2010-07-20 13:11:05.360023
26	阿隆	2010-07-21 13:29:30.28039	2010-07-21 13:29:30.28039
1	未定	2010-07-09 17:56:36.551537	2010-07-21 15:32:18.230204
27	再年	2010-07-25 13:43:44.096266	2010-07-25 13:43:44.096266
28	昌旺	2010-07-25 13:44:12.558854	2010-07-25 13:44:12.558854
29	南塘	2010-07-27 13:20:29.345442	2010-07-27 13:20:29.345442
30	阿武	2010-07-27 13:21:42.312487	2010-07-27 13:21:42.312487
31	阿权	2010-07-30 14:43:28.18268	2010-07-30 14:43:28.18268
32	厂里	2010-08-01 11:37:51.934905	2010-08-01 11:37:51.934905
33	下垟头	2010-08-10 13:52:17.26306	2010-08-10 13:52:17.26306
34	车床	2010-08-10 13:52:39.320233	2010-08-10 13:52:39.320233
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY orders (id, date, price, volume, manfee, customer_id, product_id, created_at, updated_at, is_paied, seq_no) FROM stdin;
21	2010-07-13	5.2000000000000002	31.600000000000001	0	1	2	2010-07-15 11:01:06.915946	2010-07-15 15:45:50.598611	yes	21
30	2010-07-13	17	4.5	20	20	3	2010-07-15 11:55:33.65578	2010-07-15 15:45:50.628448	no	30
25	2010-07-13	10	10.5	2	1	10	2010-07-15 11:40:13.680668	2010-07-15 15:45:50.756758	yes	25
58	2010-07-16	10	0.90000000000000002	1	1	10	2010-07-16 12:20:28.435942	2010-07-16 12:20:28.435942	yes	58
59	2010-07-16	4.7000000000000002	3.5	4	3	1	2010-07-16 12:22:53.793868	2010-07-16 12:22:53.793868	no	59
68	2010-07-17	5.2000000000000002	13	4	1	2	2010-07-17 11:40:36.418675	2010-07-17 11:40:36.418675	yes	68
56	2010-07-16	1.8200000000000001	169	0	1	13	2010-07-16 11:32:25.111047	2010-08-10 14:04:35.010778	yes	55
90	2010-07-19	17	20	0	1	18	2010-07-19 11:53:19.566183	2010-07-22 14:43:51.665771	yes	90
4	2010-07-11	5.2000000000000002	5.2999999999999998	4	2	2	2010-07-11 15:38:09.637231	2010-07-15 15:45:50.489803	no	4
5	2010-07-11	0	0	8	1	6	2010-07-11 15:38:39.347547	2010-07-15 15:45:50.492893	yes	5
6	2010-07-11	5.2000000000000002	12.800000000000001	0	1	2	2010-07-11 15:39:15.133765	2010-07-15 15:45:50.495814	yes	6
7	2010-07-11	8.5	1.3999999999999999	0	2	5	2010-07-11 15:40:04.328334	2010-07-15 15:45:50.522733	no	7
8	2010-07-11	5.2000000000000002	2.8999999999999999	4	2	2	2010-07-11 15:42:24.34378	2010-07-15 15:45:50.555465	no	8
9	2010-07-11	5.2000000000000002	8.6999999999999993	40	3	2	2010-07-11 15:44:51.942291	2010-07-15 15:45:50.559147	no	9
10	2010-07-11	4.7999999999999998	22.600000000000001	40	3	1	2010-07-11 15:45:12.586204	2010-07-15 15:45:50.561876	no	10
11	2010-07-12	14	0.29999999999999999	2	4	3	2010-07-12 12:29:26.554782	2010-07-15 15:45:50.564516	no	11
12	2010-07-12	0	0	2	1	6	2010-07-12 12:29:47.409461	2010-07-15 15:45:50.56701	yes	12
13	2010-07-12	7.5	2.2000000000000002	2	5	7	2010-07-12 12:32:13.230979	2010-07-15 15:45:50.569767	no	13
14	2010-07-12	5.2000000000000002	31.800000000000001	88	6	2	2010-07-12 12:33:01.638524	2010-07-15 15:45:50.582389	no	14
15	2010-07-12	40	14.5	32	3	8	2010-07-12 12:34:29.486664	2010-07-15 15:45:50.585388	no	15
16	2010-07-12	8.5	1.3	0	7	5	2010-07-12 12:35:54.130841	2010-07-15 15:45:50.588034	no	16
17	2010-07-12	11	0.59999999999999998	0	7	3	2010-07-12 12:36:25.305233	2010-07-15 15:45:50.590604	no	17
18	2010-07-12	5.2000000000000002	2.7000000000000002	12	7	2	2010-07-12 12:37:06.816657	2010-07-15 15:45:50.59352	no	18
19	2010-07-12	10	52	52	8	9	2010-07-12 12:39:15.217089	2010-07-15 15:45:50.595893	no	19
24	2010-07-13	4.9000000000000004	7.7000000000000002	105	1	1	2010-07-15 11:34:16.401978	2010-07-15 15:45:50.601214	yes	24
26	2010-07-13	0	0	2	1	1	2010-07-15 11:41:48.856272	2010-07-15 15:45:50.603727	yes	26
27	2010-07-13	5.2000000000000002	10.199999999999999	2	1	2	2010-07-15 11:44:35.954593	2010-07-15 15:45:50.606221	yes	27
31	2010-07-14	14	1.8	2	7	3	2010-07-15 11:59:25.486618	2010-07-15 15:45:50.608896	no	31
32	2010-07-14	5.2000000000000002	5	20	1	2	2010-07-15 12:01:46.99885	2010-07-15 15:45:50.611284	yes	32
33	2010-07-14	5.2000000000000002	3.6000000000000001	2	3	2	2010-07-15 12:05:46.921082	2010-07-15 15:45:50.613756	no	33
35	2010-07-14	0	0	2	3	1	2010-07-15 12:10:16.771947	2010-07-15 15:45:50.616144	no	35
36	2010-07-14	0	0	2	3	1	2010-07-15 12:10:27.087533	2010-07-15 15:45:50.618531	no	36
38	2010-07-14	4.7999999999999998	76.5	64	3	1	2010-07-15 12:17:54.619593	2010-07-15 15:45:50.621091	no	38
28	2010-07-13	5	7.5999999999999996	0	20	1	2010-07-15 11:50:14.873128	2010-07-15 15:45:50.623661	no	28
29	2010-07-13	5.2000000000000002	5.7000000000000002	0	20	2	2010-07-15 11:53:04.706567	2010-07-15 15:45:50.626043	no	29
34	2010-07-14	5.2000000000000002	5.5	0	21	1	2010-07-15 12:08:33.126895	2010-07-15 15:45:50.644885	no	34
37	2010-07-14	7	25	16	19	2	2010-07-15 12:12:49.349374	2010-07-15 15:45:50.647483	no	37
39	2010-07-14	17	2.3999999999999999	0	1	3	2010-07-15 12:48:38.641015	2010-07-15 15:45:50.649876	yes	39
40	2010-07-14	5.2000000000000002	4.5	14	1	2	2010-07-15 12:51:43.063663	2010-07-15 15:45:50.652345	yes	40
41	2010-07-14	4.9000000000000004	7	26	3	2	2010-07-15 12:54:29.020323	2010-07-15 15:45:50.654831	no	41
42	2010-07-15	8	198.80000000000001	182	11	4	2010-07-15 12:56:50.150974	2010-07-15 15:45:50.657477	no	42
43	2010-07-15	5.5	2.2999999999999998	4	22	2	2010-07-15 13:02:55.199161	2010-07-15 15:45:50.659933	no	43
44	2010-07-15	8	59	78	11	9	2010-07-15 13:06:26.965453	2010-07-15 15:45:50.666482	no	44
45	2010-07-15	7	34.5	0	11	2	2010-07-15 13:07:53.717127	2010-07-15 15:45:50.670683	no	45
46	2010-07-15	4.7000000000000002	37.399999999999999	76	3	1	2010-07-15 13:09:56.480995	2010-07-15 15:45:50.731826	no	46
47	2010-07-15	4.9000000000000004	10.800000000000001	0	3	2	2010-07-15 13:11:39.345955	2010-07-15 15:45:50.734975	no	47
48	2010-07-15	11	7.2000000000000002	16	1	3	2010-07-15 13:14:08.705064	2010-07-15 15:45:50.738072	yes	48
49	2010-07-15	5.2000000000000002	11.199999999999999	0	1	2	2010-07-15 13:15:47.462751	2010-07-15 15:45:50.741062	yes	49
50	2010-07-15	7.5	26.5	16	22	7	2010-07-15 13:18:39.636266	2010-07-15 15:45:50.743582	no	50
51	2010-07-15	5.2000000000000002	29.100000000000001	18	2	2	2010-07-15 13:20:44.698874	2010-07-15 15:45:50.746389	no	51
52	2010-07-15	14	0.59999999999999998	0	2	3	2010-07-15 13:22:11.412935	2010-07-15 15:45:50.749101	no	52
53	2010-07-15	5.2000000000000002	0.90000000000000002	6	2	2	2010-07-15 13:23:35.89838	2010-07-15 15:45:50.751721	no	53
69	2010-07-17	5.2000000000000002	1.8999999999999999	4	1	2	2010-07-17 11:42:27.897481	2010-07-17 11:42:27.897481	yes	69
60	2010-07-16	10	2.5	8	1	10	2010-07-16 12:25:11.271359	2010-07-16 12:25:11.271359	yes	60
61	2010-07-16	4.7999999999999998	9.6999999999999993	8	19	1	2010-07-16 12:31:18.464917	2010-07-16 12:31:18.464917	no	61
63	2010-07-16	5.2000000000000002	13.699999999999999	6	1	2	2010-07-16 12:34:21.48438	2010-07-16 12:34:21.48438	yes	63
64	2010-07-16	4.7999999999999998	3.7999999999999998	4	2	1	2010-07-16 12:36:09.874038	2010-07-16 12:36:09.874038	no	64
65	2010-07-16	8	56.5	52	11	9	2010-07-16 12:38:03.594085	2010-07-16 12:38:03.594085	no	65
66	2010-07-16	5.2000000000000002	1	0	1	2	2010-07-16 12:39:37.172827	2010-07-16 12:39:37.172827	yes	66
62	2010-07-16	0	0	4	3	6	2010-07-16 12:32:44.934092	2010-07-16 12:43:16.236372	no	62
57	2010-07-16	140	2.2000000000000002	0	23	3	2010-07-16 11:35:41.170341	2010-07-16 12:50:02.492282	no	57
67	2010-07-17	5.2000000000000002	1.7	4	1	2	2010-07-17 11:38:53.190674	2010-07-17 11:38:53.190674	yes	67
70	2010-07-17	4.7000000000000002	27.800000000000001	0	3	1	2010-07-17 11:45:33.173536	2010-07-17 11:45:33.173536	no	70
71	2010-07-17	4.9000000000000004	13.5	72	3	2	2010-07-17 11:47:12.698409	2010-07-17 11:47:12.698409	no	71
72	2010-07-17	5	35.200000000000003	32	19	1	2010-07-17 11:49:49.492529	2010-07-17 11:49:49.492529	no	72
73	2010-07-17	14	0.5	1	1	3	2010-07-17 11:52:01.208886	2010-07-17 11:52:01.208886	yes	73
74	2010-07-17	0	0	75	19	6	2010-07-17 11:53:21.476606	2010-07-17 11:53:21.476606	no	74
75	2010-07-17	14	1.6000000000000001	12	14	3	2010-07-17 11:55:06.023232	2010-07-17 11:55:06.023232	no	75
76	2010-07-17	5.2000000000000002	5	15	1	2	2010-07-17 11:56:41.806204	2010-07-17 11:56:41.806204	yes	76
77	2010-07-17	5.2000000000000002	2.1000000000000001	0	1	2	2010-07-17 11:58:05.048933	2010-07-17 11:58:05.048933	yes	77
78	2010-07-18	14	1.2	2	1	3	2010-07-18 11:03:46.63723	2010-07-18 11:03:46.63723	yes	78
79	2010-07-18	4.9000000000000004	3.2999999999999998	0	3	2	2010-07-18 11:06:33.317829	2010-07-18 11:06:33.317829	no	79
80	2010-07-18	4.7000000000000002	17.800000000000001	36	3	1	2010-07-18 11:08:24.445236	2010-07-18 11:08:24.445236	no	80
81	2010-07-18	7.5	40	21	19	7	2010-07-18 11:10:30.226732	2010-07-18 11:10:30.226732	no	81
82	2010-07-18	5.5	3.7999999999999998	8	1	2	2010-07-18 11:13:43.388902	2010-07-18 11:13:43.388902	yes	82
83	2010-07-18	5	7.0999999999999996	20	1	1	2010-07-18 11:15:18.365798	2010-07-18 11:15:18.365798	yes	83
85	2010-07-18	5.2000000000000002	10.5	16	1	2	2010-07-18 11:19:17.877514	2010-07-18 11:19:17.877514	yes	85
86	2010-07-19	4.9000000000000004	8	0	3	2	2010-07-19 11:45:07.778513	2010-07-19 11:45:07.778513	no	86
87	2010-07-19	4.7000000000000002	12.6	48	3	1	2010-07-19 11:47:07.972137	2010-07-19 11:47:07.972137	no	87
88	2010-07-19	4.7999999999999998	279	77	14	1	2010-07-19 11:49:43.266239	2010-07-19 11:49:43.266239	no	88
89	2010-07-19	5.2000000000000002	8.5999999999999996	6	1	2	2010-07-19 11:51:33.359448	2010-07-19 11:51:33.359448	yes	89
91	2010-07-19	5.2000000000000002	30	55	1	2	2010-07-19 11:55:11.892785	2010-07-19 11:55:11.892785	yes	91
3	2010-07-11	5.2000000000000002	5.7000000000000002	8	2	14	2010-07-11 15:37:32.771432	2010-07-21 13:46:56.383335	no	3
54	2010-07-15	0	0	8	3	6	2010-07-15 13:24:49.400087	2010-07-23 16:41:29.76867	no	54
92	2010-07-19	5.2000000000000002	8.5999999999999996	6	2	2	2010-07-19 11:58:33.90635	2010-07-19 11:58:33.90635	no	92
93	2010-07-19	14	0.59999999999999998	10	14	3	2010-07-19 12:01:18.401119	2010-07-19 12:01:18.401119	no	93
94	2010-07-19	8	68	52	11	9	2010-07-19 12:03:55.305949	2010-07-19 12:03:55.305949	no	94
95	2010-07-19	5	4.5999999999999996	6	1	1	2010-07-19 12:06:13.574153	2010-07-19 12:06:13.574153	yes	95
97	2010-07-20	5	3.3999999999999999	4	7	1	2010-07-20 12:07:20.68926	2010-07-20 12:07:20.68926	no	97
102	2010-07-20	4.7000000000000002	17	48	3	1	2010-07-20 12:56:34.416414	2010-07-20 12:56:34.416414	no	102
104	2010-07-20	4.7999999999999998	0.69999999999999996	2	1	1	2010-07-20 13:01:39.936239	2010-07-20 13:01:39.936239	yes	104
105	2010-07-20	8	65	52	11	9	2010-07-20 13:03:25.293929	2010-07-20 13:03:25.293929	no	105
147	2010-07-24	8.5	0.65000000000000002	0	1	5	2010-07-24 14:26:09.208179	2010-07-24 14:26:09.208179	yes	147
84	2010-07-18	5.2000000000000002	261.39999999999998	165	25	2	2010-07-18 11:17:35.538997	2010-07-20 13:11:35.856418	no	84
149	2010-07-24	5.2000000000000002	78	98	1	2	2010-07-24 14:30:40.248867	2010-07-24 14:30:40.248867	yes	149
150	2010-07-24	5.2000000000000002	17.800000000000001	24	19	2	2010-07-24 14:33:07.816538	2010-07-24 14:33:07.816538	no	150
108	2010-07-21	0	0	8	1	6	2010-07-21 13:18:16.485317	2010-07-21 13:18:16.485317	yes	108
109	2010-07-21	8	55.5	52	11	4	2010-07-21 13:21:45.521074	2010-07-21 13:21:45.521074	no	109
110	2010-07-21	0	0	4	1	6	2010-07-21 13:23:02.922925	2010-07-21 13:23:02.922925	yes	110
111	2010-07-21	5.2000000000000002	10.6	8	1	14	2010-07-21 13:26:19.086767	2010-07-21 13:26:19.086767	yes	111
112	2010-07-21	5.2000000000000002	4.9000000000000004	24	26	14	2010-07-21 13:28:58.87892	2010-07-21 13:29:58.941128	yes	112
113	2010-07-21	5.2000000000000002	44.5	16	22	14	2010-07-21 13:32:09.787488	2010-07-21 13:32:09.787488	no	113
115	2010-07-22	4.7000000000000002	26.899999999999999	46	3	1	2010-07-22 13:04:32.577606	2010-07-22 13:04:32.577606	no	115
118	2010-07-22	5.2000000000000002	19.300000000000001	16	2	14	2010-07-22 13:08:10.492781	2010-07-22 13:08:10.492781	no	116
120	2010-07-22	4.7000000000000002	26.800000000000001	72	3	1	2010-07-22 13:12:30.518328	2010-07-22 13:12:30.518328	no	120
122	2010-07-22	0	0	8	14	6	2010-07-22 13:19:23.806625	2010-07-22 13:19:23.806625	no	122
124	2010-07-22	17	27.5	36	7	18	2010-07-22 13:22:14.576997	2010-07-22 13:22:14.576997	no	123
151	2010-07-24	9	79	104	1	4	2010-07-24 14:34:52.585356	2010-07-24 14:34:52.585356	yes	151
152	2010-07-24	5	6.75	4	1	22	2010-07-24 14:37:18.078209	2010-07-24 14:37:18.078209	yes	152
128	2010-07-22	14	0.41999999999999998	15	7	3	2010-07-22 13:42:40.342032	2010-07-22 13:42:40.342032	no	128
129	2010-07-22	5.2000000000000002	1.3999999999999999	0	7	1	2010-07-22 13:44:08.766441	2010-07-22 13:44:08.766441	no	129
153	2010-07-24	10	1	0	3	19	2010-07-24 14:39:03.050288	2010-07-24 14:39:03.050288	no	153
154	2010-07-24	5.2000000000000002	21.699999999999999	54	7	2	2010-07-24 14:40:51.135472	2010-07-24 14:40:51.135472	no	154
130	2010-07-22	10	4.7000000000000002	10	1	19	2010-07-22 13:46:50.931963	2010-07-22 13:57:56.39303	yes	130
107	2010-07-21	15	1	0	19	20	2010-07-21 11:48:50.809239	2010-07-22 14:04:08.252132	no	107
98	2010-07-20	5.2000000000000002	3.2999999999999998	4	1	14	2010-07-20 12:44:23.89691	2010-07-22 14:21:42.135988	yes	98
101	2010-07-20	5.2000000000000002	6.0999999999999996	4	1	14	2010-07-20 12:51:02.077503	2010-07-22 14:22:13.330953	yes	101
155	2010-07-24	0	0	22	14	6	2010-07-24 14:41:59.97642	2010-07-24 14:41:59.97642	no	155
106	2010-07-20	5.2000000000000002	10.199999999999999	26	24	14	2010-07-20 13:05:32.886862	2010-07-22 14:23:17.140393	no	106
131	2010-07-23	5.2000000000000002	17.300000000000001	43.600000000000001	6	22	2010-07-23 13:48:07.601611	2010-07-23 13:48:07.601611	no	131
133	2010-07-23	5.2000000000000002	10	12	19	2	2010-07-23 13:53:58.424576	2010-07-23 13:53:58.424576	no	132
134	2010-07-23	5.2000000000000002	1.5	2.5	1	2	2010-07-23 13:57:52.473812	2010-07-23 13:57:52.473812	yes	134
135	2010-07-23	0	0	20	1	6	2010-07-23 14:00:39.670438	2010-07-23 14:00:39.670438	yes	135
136	2010-07-23	0	0	100	22	6	2010-07-23 14:02:15.261771	2010-07-23 14:02:15.261771	no	136
137	2010-07-23	10	51	52	8	9	2010-07-23 14:05:24.806545	2010-07-23 14:05:24.806545	no	137
138	2010-07-23	0	0	2	22	6	2010-07-23 14:10:32.936876	2010-07-23 14:10:32.936876	no	138
139	2010-07-23	7	11	8	14	11	2010-07-23 14:12:57.875516	2010-07-23 14:12:57.875516	no	139
141	2010-07-23	0	0	4	2	6	2010-07-23 14:17:06.600943	2010-07-23 14:17:06.600943	no	141
126	2010-07-22	8	26	26	11	4	2010-07-22 13:34:06.079125	2010-07-23 15:54:11.744737	no	126
125	2010-07-22	5.2000000000000002	21	24	7	5	2010-07-22 13:25:36.093573	2010-07-23 15:58:53.225963	no	125
121	2010-07-22	5.2000000000000002	1.6000000000000001	2	1	14	2010-07-22 13:16:36.039212	2010-07-23 16:02:00.320984	yes	121
119	2010-07-22	4.9000000000000004	8.9000000000000004	0	3	2	2010-07-22 13:10:15.305245	2010-07-23 16:06:03.504617	no	119
114	2010-07-22	4.9000000000000004	16.699999999999999	46	3	2	2010-07-22 13:02:12.353081	2010-07-23 16:08:38.855218	no	114
103	2010-07-20	4.9000000000000004	5.7999999999999998	0	3	2	2010-07-20 13:00:12.15893	2010-07-23 16:16:58.953051	no	103
100	2010-07-20	0	0	8	19	6	2010-07-20 12:48:02.332487	2010-07-23 16:21:09.504008	no	100
99	2010-07-20	0	0	2	22	6	2010-07-20 12:46:10.545847	2010-07-23 16:22:05.324992	no	99
96	2010-07-19	5.2000000000000002	0.80000000000000004	4	26	2	2010-07-19 12:08:49.564124	2010-07-23 16:25:20.441574	yes	96
142	2010-07-24	7.5	120.5	128	19	15	2010-07-24 13:59:52.557186	2010-07-24 13:59:52.557186	no	142
143	2010-07-24	4.9000000000000004	10.4	0	3	2	2010-07-24 14:02:47.466955	2010-07-24 14:02:47.466955	no	143
144	2010-07-24	4.7000000000000002	36.399999999999999	76	3	1	2010-07-24 14:05:24.382847	2010-07-24 14:05:24.382847	no	144
145	2010-07-24	14	0.69999999999999996	0	1	3	2010-07-24 14:08:17.164187	2010-07-24 14:08:17.164187	yes	145
146	2010-07-24	5.2000000000000002	0.80000000000000004	2	1	2	2010-07-24 14:24:22.731213	2010-07-24 14:24:22.731213	yes	146
156	2010-07-25	5	7	2	1	22	2010-07-25 12:43:57.886832	2010-07-25 12:43:57.886832	yes	156
157	2010-07-25	0	0	2	3	6	2010-07-25 12:46:50.296672	2010-07-25 12:46:50.296672	no	157
158	2010-07-25	14	15	0	9	20	2010-07-25 12:49:30.073473	2010-07-25 12:49:30.073473	no	158
160	2010-07-25	4.7999999999999998	235	280	19	1	2010-07-25 12:52:36.951734	2010-07-25 12:52:36.951734	no	159
161	2010-07-25	5.2000000000000002	39.5	36	2	2	2010-07-25 12:55:54.819934	2010-07-25 12:55:54.819934	no	161
162	2010-07-25	7	5.5	3	19	11	2010-07-25 12:58:30.649627	2010-07-25 12:58:30.649627	no	162
163	2010-07-25	14	0.69999999999999996	2	7	3	2010-07-25 13:00:42.409942	2010-07-25 13:00:42.409942	no	163
148	2010-07-24	5	3	2	27	14	2010-07-24 14:28:25.564658	2010-07-25 13:47:01.167786	no	148
140	2010-07-23	5	14.699999999999999	16	27	14	2010-07-23 14:15:38.064165	2010-07-25 13:49:02.519719	no	140
164	2010-07-26	4.9000000000000004	6.5999999999999996	0	3	2	2010-07-26 12:24:52.350203	2010-07-26 12:24:52.350203	no	164
165	2010-07-26	4.7000000000000002	10.5	48	3	1	2010-07-26 12:28:12.073013	2010-07-26 12:28:12.073013	no	165
166	2010-07-26	0	0	4	26	6	2010-07-26 13:55:42.07297	2010-07-26 13:55:42.07297	yes	166
167	2010-07-26	0	0	6	14	6	2010-07-26 13:56:56.780297	2010-07-26 13:56:56.780297	no	167
168	2010-07-26	15	3	4	1	20	2010-07-26 13:59:22.892903	2010-07-26 13:59:22.892903	yes	168
169	2010-07-26	10	51	52	8	9	2010-07-26 14:01:08.39474	2010-07-26 14:01:08.39474	no	169
170	2010-07-26	8	25	26	11	4	2010-07-26 14:03:16.265664	2010-07-26 14:03:16.265664	no	170
172	2010-07-26	10	89	78	18	4	2010-07-26 14:05:25.518614	2010-07-26 14:05:25.518614	no	171
173	2010-07-26	10	2.2000000000000002	4	1	19	2010-07-26 14:08:36.475671	2010-07-26 14:08:36.475671	yes	173
174	2010-07-26	10	1.2	5	1	19	2010-07-26 14:10:46.330842	2010-07-26 14:10:46.330842	yes	174
175	2010-07-26	5.5	2.1000000000000001	4	2	2	2010-07-26 14:12:24.632601	2010-07-26 14:12:24.632601	no	175
176	2010-07-27	0	0	4	2	6	2010-07-27 10:49:06.733381	2010-07-27 10:49:06.733381	no	176
177	2010-07-27	5.2000000000000002	2.1000000000000001	2	27	2	2010-07-27 10:50:44.227883	2010-07-27 10:50:44.227883	no	177
178	2010-07-27	0	0	26	1	6	2010-07-27 10:51:58.896882	2010-07-27 10:51:58.896882	yes	178
179	2010-07-27	0	0	8	3	6	2010-07-27 10:53:02.222033	2010-07-27 10:53:02.222033	no	179
180	2010-07-27	8.5	1	0	7	5	2010-07-27 10:55:01.129934	2010-07-27 13:04:13.800136	no	180
181	2010-07-27	5.2000000000000002	6	12	7	2	2010-07-27 13:10:56.868529	2010-07-27 13:10:56.868529	no	181
182	2010-07-27	5.2000000000000002	12.1	4	2	2	2010-07-27 13:13:07.887621	2010-07-27 13:13:07.887621	no	182
184	2010-07-27	5.2000000000000002	375.19999999999999	504	30	2	2010-07-27 13:17:35.232952	2010-07-27 13:23:10.99578	no	184
183	2010-07-27	10	1.6000000000000001	4	29	19	2010-07-27 13:15:00.508935	2010-07-27 13:22:37.310733	no	183
187	2010-07-28	5.2000000000000002	12.1	4	2	2	2010-07-28 12:45:08.038883	2010-07-28 12:45:08.038883	no	187
186	2010-07-28	1.8	245	0	1	13	2010-07-28 12:42:26.069108	2010-07-28 12:45:54.396912	yes	185
188	2010-07-28	4.9000000000000004	11.5	26	3	2	2010-07-28 12:48:10.889331	2010-07-28 12:48:10.889331	no	188
189	2010-07-28	4.7000000000000002	12	26	3	1	2010-07-28 12:55:12.107159	2010-07-28 12:55:12.107159	no	189
191	2010-07-28	5.2000000000000002	260.60000000000002	304	2	2	2010-07-28 13:35:02.393816	2010-07-28 13:35:02.393816	no	191
190	2010-07-28	5.2000000000000002	8.8000000000000007	20	2	14	2010-07-28 13:32:20.084097	2010-07-28 13:36:07.878738	no	190
192	2010-07-28	4.9000000000000004	5	8	3	2	2010-07-28 13:38:12.631573	2010-07-28 13:38:12.631573	no	192
193	2010-07-28	8.5	3.5	0	2	5	2010-07-28 13:40:19.296361	2010-07-28 13:40:19.296361	no	193
194	2010-07-28	5.2000000000000002	2.5	4	2	2	2010-07-28 13:42:34.562943	2010-07-28 13:42:34.562943	no	194
196	2010-07-28	14	0.55000000000000004	2	7	3	2010-07-28 13:47:31.432201	2010-07-28 13:47:31.432201	no	196
198	2010-07-28	0	0	10	1	6	2010-07-28 14:07:32.608594	2010-07-28 14:07:32.608594	yes	198
197	2010-07-28	0	0	2	1	6	2010-07-28 14:05:41.214133	2010-07-28 14:08:00.795665	yes	197
199	2010-07-28	0	0	6	1	6	2010-07-28 14:09:27.704312	2010-07-28 14:09:27.704312	yes	199
200	2010-07-28	5.2000000000000002	3.2999999999999998	2	1	2	2010-07-28 14:11:03.171279	2010-07-28 14:11:03.171279	yes	200
201	2010-07-28	0	0	10	1	6	2010-07-28 14:14:44.853874	2010-07-28 14:14:44.853874	yes	201
202	2010-07-29	5.2000000000000002	2.3999999999999999	4	21	22	2010-07-29 11:13:32.851888	2010-07-29 11:13:32.851888	no	202
203	2010-07-29	15	183.5	945	12	20	2010-07-29 11:15:35.067969	2010-07-29 11:15:35.067969	no	203
204	2010-07-29	7.5	2.5	5	3	16	2010-07-29 11:17:36.916924	2010-07-29 11:18:11.652049	no	204
205	2010-07-29	4.9000000000000004	15.4	5	3	2	2010-07-29 11:20:18.535077	2010-07-29 11:20:18.535077	no	205
206	2010-07-29	4.7000000000000002	38	110	3	1	2010-07-29 11:21:57.449302	2010-07-29 11:21:57.449302	no	206
207	2010-07-29	5.2000000000000002	10.4	28	30	2	2010-07-29 11:29:05.148742	2010-07-29 11:29:05.148742	yes	207
208	2010-07-29	6	228	55	30	24	2010-07-29 11:31:02.855783	2010-07-29 11:31:02.855783	yes	208
210	2010-07-29	5.2000000000000002	17.5	32	1	2	2010-07-29 11:35:15.047663	2010-07-29 11:35:15.047663	yes	209
211	2010-07-29	5.2000000000000002	3.7999999999999998	30	1	2	2010-07-29 11:37:20.021893	2010-07-29 11:37:20.021893	yes	211
212	2010-07-29	5.2000000000000002	45.600000000000001	28	1	2	2010-07-29 11:39:17.900275	2010-07-29 11:39:17.900275	yes	212
213	2010-07-29	17	17.800000000000001	18	1	12	2010-07-29 11:41:21.651986	2010-07-29 11:41:21.651986	yes	213
214	2010-07-29	10	12.5	20	1	19	2010-07-29 11:42:51.763534	2010-07-29 11:42:51.763534	yes	214
215	2010-07-29	5.2000000000000002	10.6	5	2	2	2010-07-29 11:44:50.905011	2010-07-29 11:44:50.905011	no	215
216	2010-07-30	8.5	1.8999999999999999	4	7	5	2010-07-30 12:04:22.924239	2010-07-30 12:04:22.924239	no	216
217	2010-07-30	14	0.59999999999999998	5	7	3	2010-07-30 12:08:12.100508	2010-07-30 12:08:12.100508	no	217
218	2010-07-30	5.2000000000000002	4.2999999999999998	2	19	2	2010-07-30 13:16:43.834974	2010-07-30 13:16:43.834974	no	218
219	2010-07-30	5.2000000000000002	3.5	0	1	14	2010-07-30 13:18:56.285415	2010-07-30 13:18:56.285415	yes	219
220	2010-07-30	5.2000000000000002	6.2999999999999998	4	1	2	2010-07-30 13:21:02.526165	2010-07-30 13:21:02.526165	yes	220
221	2010-07-30	0	0	26	1	6	2010-07-30 13:22:46.812851	2010-07-30 13:22:46.812851	yes	221
222	2010-07-30	10	24.800000000000001	26	8	9	2010-07-30 13:24:34.997664	2010-07-30 13:24:34.997664	no	222
223	2010-07-30	8	46.799999999999997	52	11	9	2010-07-30 13:26:45.286839	2010-07-30 13:26:45.286839	no	223
224	2010-07-30	5.2000000000000002	3.7999999999999998	31	1	2	2010-07-30 13:28:44.945672	2010-07-30 13:28:44.945672	yes	224
225	2010-07-30	8	28.5	26	11	9	2010-07-30 13:30:37.571983	2010-07-30 13:30:37.571983	no	225
195	2010-07-28	5.2000000000000002	21.600000000000001	40	31	2	2010-07-28 13:45:46.354394	2010-07-30 14:49:40.92605	no	195
226	2010-07-31	9	28.5	32	19	4	2010-08-01 11:21:13.372435	2010-08-01 11:23:07.767016	no	226
227	2010-07-31	0	0	4	1	6	2010-08-01 11:25:24.002336	2010-08-01 11:25:24.002336	yes	227
228	2010-07-31	0	0	10	14	6	2010-08-01 11:26:28.96826	2010-08-01 11:26:54.216325	no	228
229	2010-07-31	10	50	52	8	9	2010-08-01 11:28:17.362133	2010-08-01 11:28:45.705605	no	229
230	2010-08-01	5.2000000000000002	236.69999999999999	120	25	2	2010-08-01 11:36:38.000511	2010-08-01 11:36:38.000511	no	230
231	2010-08-01	9	26	32	32	4	2010-08-01 11:40:16.095796	2010-08-01 11:40:16.095796	no	231
232	2010-08-01	4.7999999999999998	138.5	96	14	1	2010-08-01 11:42:27.386976	2010-08-01 11:42:27.386976	no	232
233	2010-08-01	7.5	14	16	19	7	2010-08-01 11:44:40.897426	2010-08-01 11:44:40.897426	no	233
234	2010-08-01	5.2000000000000002	7.2999999999999998	10.4	19	22	2010-08-01 11:47:02.661412	2010-08-01 11:47:02.661412	no	234
235	2010-08-01	7.5	2	2	19	16	2010-08-01 12:05:54.319649	2010-08-01 12:05:54.319649	no	235
236	2010-08-01	4.9000000000000004	5.5999999999999996	8	3	2	2010-08-01 12:07:21.713914	2010-08-01 12:07:21.713914	no	236
237	2010-08-01	4.7000000000000002	14.199999999999999	32	3	1	2010-08-01 12:09:01.026548	2010-08-01 12:09:01.026548	no	237
238	2010-08-01	4.7999999999999998	105	96	19	1	2010-08-01 12:10:56.318808	2010-08-01 12:10:56.318808	no	238
239	2010-08-01	0	0	26	26	6	2010-08-01 12:12:35.140979	2010-08-01 12:13:43.959492	no	239
240	2010-08-01	0	0	20	26	6	2010-08-01 12:15:00.780441	2010-08-01 12:15:00.780441	yes	240
241	2010-08-01	4.9000000000000004	13.6	8	3	2	2010-08-01 12:17:33.75516	2010-08-01 12:18:17.45273	no	241
242	2010-08-01	4.7000000000000002	27.600000000000001	64	3	1	2010-08-01 12:21:06.908052	2010-08-01 12:21:06.908052	no	242
243	2010-08-01	5.2000000000000002	0.80000000000000004	8	19	2	2010-08-01 12:22:30.870709	2010-08-01 12:22:30.870709	no	243
245	2010-08-02	5.2000000000000002	5.7999999999999998	0	1	2	2010-08-02 16:04:11.077122	2010-08-02 16:04:33.010441	yes	245
244	2010-08-02	5.2000000000000002	10.199999999999999	43	6	22	2010-08-02 16:02:07.535376	2010-08-02 16:05:11.876995	no	244
247	2010-08-02	8.5	24.5	26	11	9	2010-08-02 16:08:38.898959	2010-08-02 16:08:38.898959	no	247
248	2010-08-02	4.9000000000000004	7.2000000000000002	12	3	2	2010-08-02 16:10:36.867933	2010-08-02 16:10:36.867933	no	248
249	2010-08-02	4.7000000000000002	11.800000000000001	32	3	1	2010-08-02 16:12:12.692074	2010-08-02 16:12:12.692074	no	249
250	2010-08-02	8.5	0.69999999999999996	0	7	5	2010-08-02 16:14:17.101524	2010-08-02 16:14:17.101524	no	250
251	2010-08-02	10	3	15	7	19	2010-08-02 16:16:19.452264	2010-08-02 16:16:19.452264	no	251
252	2010-08-02	5.2000000000000002	17.300000000000001	84	7	2	2010-08-02 16:17:47.621313	2010-08-02 16:17:47.621313	no	252
253	2010-08-02	5.2000000000000002	59.600000000000001	64	1	2	2010-08-02 16:19:44.346085	2010-08-02 16:19:44.346085	yes	253
246	2010-08-02	0	0	5	1	6	2010-08-02 16:06:35.592833	2010-08-03 03:47:48.865195	yes	246
254	2010-08-03	5	31.5	40	31	2	2010-08-03 10:54:40.048778	2010-08-03 10:54:40.048778	no	254
255	2010-08-03	0	0	8	14	6	2010-08-03 10:56:01.520865	2010-08-03 10:56:01.520865	no	255
256	2010-08-03	5.2000000000000002	4.5999999999999996	4	2	2	2010-08-03 10:57:40.946274	2010-08-03 10:57:40.946274	no	256
257	2010-08-03	5.2000000000000002	3.2999999999999998	2	1	14	2010-08-03 10:59:26.845325	2010-08-03 10:59:26.845325	yes	257
259	2010-08-03	0	0	14	3	6	2010-08-03 11:02:35.818751	2010-08-03 11:02:35.818751	no	259
260	2010-08-03	4.7999999999999998	88	36	32	1	2010-08-03 11:04:19.973707	2010-08-03 11:04:19.973707	no	260
263	2010-08-03	8.5	1	0	7	5	2010-08-03 11:08:29.928224	2010-08-03 11:08:29.928224	no	263
264	2010-08-03	17	1.7	12	7	18	2010-08-03 11:10:23.530161	2010-08-03 11:10:23.530161	no	264
265	2010-08-03	5.2000000000000002	15.4	30	7	2	2010-08-03 11:11:48.0639	2010-08-03 11:11:48.0639	no	265
266	2010-08-03	5.2000000000000002	2.1000000000000001	2	32	14	2010-08-03 11:13:25.640149	2010-08-03 11:13:25.640149	no	266
267	2010-08-04	4.7999999999999998	2.8999999999999999	8	7	1	2010-08-04 13:20:16.427878	2010-08-04 13:20:37.087063	no	267
268	2010-08-04	4.7999999999999998	1.3	4	7	1	2010-08-04 13:21:56.240412	2010-08-04 13:21:56.240412	no	268
269	2010-08-04	5.2000000000000002	1.6000000000000001	14	27	2	2010-08-04 13:23:20.008214	2010-08-04 13:23:20.008214	no	269
270	2010-08-04	5.2000000000000002	4.5999999999999996	12	29	2	2010-08-04 13:24:43.173607	2010-08-04 13:24:43.173607	yes	270
271	2010-08-04	4.9000000000000004	7.7999999999999998	10	3	2	2010-08-04 13:26:13.20489	2010-08-04 13:26:13.20489	no	271
272	2010-08-04	4.7000000000000002	14.4	30	3	1	2010-08-04 13:27:32.439655	2010-08-04 13:27:32.439655	no	272
273	2010-08-04	5.2000000000000002	6.2000000000000002	12	19	2	2010-08-04 13:29:08.04846	2010-08-04 13:29:08.04846	no	273
274	2010-08-04	0	0	2	1	6	2010-08-04 13:30:24.639456	2010-08-04 13:30:24.639456	yes	274
275	2010-08-04	4.7999999999999998	262	160	14	1	2010-08-04 13:32:03.506828	2010-08-04 13:32:03.506828	no	275
276	2010-08-04	5.2000000000000002	100.90000000000001	48	1	2	2010-08-04 13:33:55.2564	2010-08-04 13:33:55.2564	yes	276
277	2010-08-04	17	32.600000000000001	27	1	18	2010-08-04 13:35:23.099474	2010-08-04 13:35:23.099474	yes	277
278	2010-08-04	14	1	2	2	3	2010-08-04 13:36:56.04482	2010-08-04 13:36:56.04482	no	278
258	2010-08-03	5.2000000000000002	81.400000000000006	196	30	2	2010-08-03 11:01:21.781301	2010-08-04 13:52:10.460574	yes	258
281	2010-08-05	5.2000000000000002	18	8	2	2	2010-08-05 16:33:57.817629	2010-08-05 16:33:57.817629	no	281
283	2010-08-05	4.7999999999999998	17	4	19	1	2010-08-05 16:48:58.679736	2010-08-05 16:48:58.679736	no	283
284	2010-08-05	7.5	6.2000000000000002	8	19	15	2010-08-05 16:55:27.833818	2010-08-05 16:55:27.833818	no	284
285	2010-08-05	4.7999999999999998	3.3999999999999999	4	26	1	2010-08-05 17:12:42.875521	2010-08-05 17:12:42.875521	yes	285
287	2010-08-05	4.7999999999999998	185	128	14	1	2010-08-05 17:17:07.078793	2010-08-05 17:17:07.078793	no	287
288	2010-08-06	4.7999999999999998	1.2	4	3	1	2010-08-06 10:47:03.308786	2010-08-06 10:47:03.308786	no	288
289	2010-08-06	5.2000000000000002	2.5	8	32	1	2010-08-06 10:48:27.57658	2010-08-06 10:48:27.57658	no	289
290	2010-08-06	9	26.5	28	32	4	2010-08-06 10:49:55.597984	2010-08-06 10:49:55.597984	no	290
291	2010-08-06	0	0	6	27	6	2010-08-06 10:51:03.520121	2010-08-06 10:51:03.520121	no	291
292	2010-08-06	0	0	2	7	6	2010-08-06 10:52:02.800729	2010-08-06 10:52:02.800729	no	292
293	2010-08-06	10	59	52	8	9	2010-08-06 10:53:20.088332	2010-08-06 10:53:20.088332	no	293
294	2010-08-06	0	0	6	14	6	2010-08-06 10:54:37.282661	2010-08-06 10:54:37.282661	no	294
279	2010-08-05	5.2000000000000002	18	8	2	2	2010-08-05 16:29:45.942166	2010-08-06 10:56:53.900857	no	279
286	2010-08-05	0	0	2	3	6	2010-08-05 17:13:53.147958	2010-08-06 10:58:13.645367	no	286
295	2010-07-01	0	0	10	14	6	2010-08-06 11:07:03.253924	2010-08-06 11:07:03.253924	no	295
296	2010-07-01	4.7999999999999998	8.3000000000000007	7	2	1	2010-08-06 11:08:35.395307	2010-08-06 11:10:01.301019	no	296
297	2010-07-01	4.9000000000000004	23.699999999999999	10	3	2	2010-08-06 11:13:35.381458	2010-08-06 11:13:35.381458	no	297
298	2010-07-01	5.2000000000000002	1.6000000000000001	4	19	1	2010-08-06 11:15:52.489272	2010-08-06 11:15:52.489272	no	298
299	2010-07-02	5.2000000000000002	11.800000000000001	16	14	2	2010-08-06 11:18:07.289021	2010-08-06 11:18:07.289021	no	299
344	2010-08-08	4.7000000000000002	27.699999999999999	64	3	1	2010-08-08 10:36:38.455893	2010-08-08 10:36:38.455893	no	344
301	2010-07-02	4.9000000000000004	5.7000000000000002	10	3	2	2010-08-06 11:26:18.894716	2010-08-06 11:26:18.894716	no	301
302	2010-07-02	4.7000000000000002	13	30	3	1	2010-08-06 11:27:50.32424	2010-08-06 11:27:50.32424	no	302
303	2010-07-03	5.5	18	60	2	2	2010-08-06 11:31:05.09767	2010-08-06 11:31:05.09767	no	303
304	2010-07-03	4.9000000000000004	6.5999999999999996	4	2	1	2010-08-06 11:32:40.794221	2010-08-06 11:32:40.794221	no	304
305	2010-07-03	4.9000000000000004	2.2999999999999998	6	3	2	2010-08-06 11:34:36.01572	2010-08-06 11:34:36.01572	no	305
306	2010-07-03	4.7000000000000002	8.5	26	3	1	2010-08-06 11:35:54.622705	2010-08-06 11:35:54.622705	no	306
307	2010-07-03	5.2000000000000002	9.1999999999999993	16	19	2	2010-08-06 11:39:21.187246	2010-08-06 11:39:21.187246	no	307
309	2010-07-04	4.9000000000000004	11	6	3	2	2010-08-06 11:46:35.16219	2010-08-06 11:46:35.16219	no	308
310	2010-07-04	4.7000000000000002	46.899999999999999	70	3	1	2010-08-06 11:48:15.929315	2010-08-06 11:48:15.929315	no	310
311	2010-07-04	14	0.14999999999999999	2	7	3	2010-08-06 11:50:25.675302	2010-08-06 11:50:25.675302	no	311
312	2010-07-05	8.5	2	1	2	5	2010-08-06 11:53:33.258404	2010-08-06 11:53:33.258404	no	312
313	2010-07-06	5.2000000000000002	44.299999999999997	36	2	2	2010-08-06 11:59:03.923821	2010-08-06 11:59:03.923821	no	313
314	2010-07-06	4.9000000000000004	1.6000000000000001	7	3	2	2010-08-06 12:52:12.970539	2010-08-06 12:52:12.970539	no	314
315	2010-07-07	4.9000000000000004	4	8	3	2	2010-08-06 12:53:49.806013	2010-08-06 12:53:49.806013	no	315
316	2010-07-07	14	0.40000000000000002	2	7	3	2010-08-06 12:55:33.649054	2010-08-06 12:55:33.649054	no	316
317	2010-07-07	5.2000000000000002	10	40	19	2	2010-08-06 12:57:07.51174	2010-08-06 12:57:07.51174	no	317
318	2010-07-08	5.2000000000000002	4.2999999999999998	16	19	2	2010-08-06 12:58:50.341197	2010-08-06 12:58:50.341197	no	318
319	2010-07-08	5.2000000000000002	7.2000000000000002	12	14	2	2010-08-06 13:00:58.189633	2010-08-06 13:00:58.189633	no	319
320	2010-07-08	14	1.1000000000000001	6	7	3	2010-08-06 13:02:54.293395	2010-08-06 13:02:54.293395	no	320
321	2010-07-09	4.9000000000000004	10.800000000000001	6	3	2	2010-08-06 13:04:37.011364	2010-08-06 13:04:37.011364	no	321
322	2010-07-09	4.7000000000000002	26.199999999999999	70	3	1	2010-08-06 13:05:55.868994	2010-08-06 13:05:55.868994	no	322
323	2010-07-10	8.5	1.2	2	2	5	2010-08-06 13:08:35.177698	2010-08-06 13:08:35.177698	no	323
324	2010-07-10	4.9000000000000004	3.2999999999999998	2	2	1	2010-08-06 13:10:03.097251	2010-08-06 13:10:03.097251	no	324
345	2010-08-08	5.2000000000000002	6.5	4	2	2	2010-08-08 10:38:02.333558	2010-08-08 10:38:02.333558	no	345
346	2010-08-08	10	0.80000000000000004	8	19	10	2010-08-08 10:39:25.534248	2010-08-08 10:39:25.534248	no	346
325	2010-07-01	4.7000000000000002	49.799999999999997	150	3	1	2010-08-07 13:07:18.036267	2010-08-07 13:07:18.036267	no	325
326	2010-07-05	4.9000000000000004	3	3	2	1	2010-08-07 13:08:57.828282	2010-08-07 13:08:57.828282	no	326
300	2010-07-02	4.9000000000000004	17	16	2	1	2010-08-06 11:24:03.992981	2010-08-07 13:11:08.367887	no	300
327	2010-07-02	5.2000000000000002	1.25	0	2	2	2010-08-07 13:11:53.162559	2010-08-07 13:11:53.162559	no	327
328	2010-08-07	5.2000000000000002	5.7000000000000002	9	15	22	2010-08-07 16:24:35.192718	2010-08-07 16:24:35.192718	no	328
329	2010-08-07	0	0	2	26	6	2010-08-07 16:26:04.535414	2010-08-07 16:26:04.535414	yes	329
330	2010-08-07	14	3.5	4	1	3	2010-08-07 16:27:46.567993	2010-08-07 16:27:46.567993	yes	330
331	2010-08-07	5.2000000000000002	2.7999999999999998	2	32	2	2010-08-07 16:29:45.675065	2010-08-07 16:29:45.675065	no	331
332	2010-08-07	5.2000000000000002	42.299999999999997	97	6	22	2010-08-07 16:31:19.766118	2010-08-07 16:31:19.766118	no	332
333	2010-08-07	5.2000000000000002	62.600000000000001	210	6	14	2010-08-07 16:33:15.484349	2010-08-07 16:33:15.484349	no	333
334	2010-08-07	5.2000000000000002	3.7000000000000002	14	24	2	2010-08-07 16:34:49.282111	2010-08-07 16:34:49.282111	no	334
335	2010-08-07	5.2000000000000002	18	93.400000000000006	6	14	2010-08-07 16:36:36.327636	2010-08-07 16:36:36.327636	no	335
336	2010-08-07	5.2000000000000002	9.8000000000000007	10	14	2	2010-08-07 16:38:25.707012	2010-08-07 16:38:25.707012	no	336
338	2010-08-07	5.2000000000000002	6.7999999999999998	12	32	2	2010-08-07 16:41:49.203244	2010-08-07 16:41:49.203244	no	338
339	2010-08-07	5.2000000000000002	11.300000000000001	28	19	2	2010-08-07 16:43:44.982713	2010-08-07 16:43:44.982713	no	339
337	2010-08-07	0	0	13	1	6	2010-08-07 16:39:57.938044	2010-08-07 16:53:40.585795	yes	337
341	2010-07-05	0	0	20	3	6	2010-08-08 09:45:23.089753	2010-08-08 09:45:23.089753	no	341
342	2010-07-05	4.7999999999999998	1.8	6	2	1	2010-08-08 09:47:49.80143	2010-08-08 09:47:49.80143	no	342
343	2010-08-08	4.9000000000000004	15.1	20	3	2	2010-08-08 10:35:16.123629	2010-08-08 10:35:16.123629	no	343
347	2010-08-08	0	0	5	32	6	2010-08-08 10:40:36.388291	2010-08-08 10:40:52.351354	yes	347
348	2010-08-08	4.7999999999999998	4.7999999999999998	0.080000000000000002	1	1	2010-08-08 10:42:14.404966	2010-08-08 10:42:14.404966	yes	348
349	2010-08-08	10	1.5	4	1	10	2010-08-08 10:43:40.625654	2010-08-08 10:43:40.625654	yes	349
350	2010-08-08	5.2000000000000002	2	9.5999999999999996	6	14	2010-08-08 10:45:10.193689	2010-08-08 10:45:10.193689	no	350
351	2010-08-08	10	1	2	1	10	2010-08-08 10:46:29.773045	2010-08-08 10:46:29.773045	yes	351
352	2010-08-08	5.2000000000000002	2.1000000000000001	2	14	14	2010-08-08 10:47:42.946929	2010-08-08 10:47:42.946929	no	352
353	2010-08-08	4.9000000000000004	14.699999999999999	16	3	2	2010-08-08 10:49:11.885153	2010-08-08 10:49:11.885153	no	353
354	2010-08-08	4.7000000000000002	42.5	96	3	1	2010-08-08 10:50:22.755616	2010-08-08 10:50:22.755616	no	354
355	2010-08-08	14	37.600000000000001	0	9	20	2010-08-08 10:51:37.421648	2010-08-08 10:51:37.421648	no	355
356	2010-08-08	0	0	2	26	6	2010-08-08 10:52:54.00014	2010-08-08 10:52:54.00014	no	356
357	2010-08-09	4.9000000000000004	10	16	3	2	2010-08-09 11:49:08.180936	2010-08-09 11:49:08.180936	no	357
358	2010-08-09	0	0	2	1	6	2010-08-09 11:50:24.812523	2010-08-09 11:50:24.812523	yes	358
359	2010-08-09	0	0	4	32	6	2010-08-09 11:51:18.928177	2010-08-09 11:51:18.928177	yes	359
360	2010-08-09	8.5	31.5	26	11	9	2010-08-09 11:52:46.597666	2010-08-09 11:52:46.597666	no	360
361	2010-08-09	8	95.5	91	11	4	2010-08-09 11:53:44.315898	2010-08-09 11:53:44.315898	no	361
362	2010-08-10	4.9000000000000004	20	20	3	2	2010-08-10 11:31:24.480311	2010-08-10 11:31:24.480311	no	362
363	2010-08-10	4.7000000000000002	47.700000000000003	96	3	1	2010-08-10 11:32:52.656603	2010-08-10 11:32:52.656603	no	363
365	2010-08-10	5.2000000000000002	0.5	5	19	2	2010-08-10 11:38:52.963412	2010-08-10 11:38:52.963412	no	365
366	2010-08-10	5.2000000000000002	3.7999999999999998	8	2	2	2010-08-10 11:40:18.40135	2010-08-10 11:40:18.40135	no	366
370	2010-08-10	10	26.5	26	8	9	2010-08-10 13:28:53.790609	2010-08-10 13:28:53.790609	no	370
371	2010-08-10	4.9000000000000004	10.1	16	3	2	2010-08-10 13:30:22.881558	2010-08-10 13:30:22.881558	no	371
372	2010-08-10	4.7000000000000002	28.600000000000001	56	3	1	2010-08-10 13:32:12.865739	2010-08-10 13:32:12.865739	no	372
373	2010-08-10	5.2000000000000002	5.7000000000000002	2	1	14	2010-08-10 13:34:12.20167	2010-08-10 13:34:12.20167	yes	373
376	2010-08-10	0	0	3	1	6	2010-08-10 13:38:23.134628	2010-08-10 13:38:23.134628	yes	376
369	2010-08-10	0	0	3	1	6	2010-08-10 13:27:35.955078	2010-08-10 13:38:59.337103	yes	369
368	2010-08-10	5.2000000000000002	30.100000000000001	8	1	14	2010-08-10 11:45:10.74518	2010-08-10 13:39:37.962932	yes	368
421	2010-08-15	14	0.29999999999999999	2	7	3	2010-08-15 11:27:18.395	2010-08-15 11:27:18.395	no	421
364	2010-08-10	0	0	3	1	6	2010-08-10 11:35:21.203752	2010-08-10 13:40:38.554862	yes	364
374	2010-08-10	7.5	68	48	33	15	2010-08-10 13:35:52.800891	2010-08-10 13:53:31.565443	no	374
367	2010-08-10	10	3.7999999999999998	28	34	10	2010-08-10 11:42:47.398644	2010-08-10 13:54:11.178772	yes	367
375	2010-08-10	4.7999999999999998	92	64	33	1	2010-08-10 13:37:25.164797	2010-08-10 13:54:27.798844	no	375
340	2010-08-07	7.5	13.6	8	33	16	2010-08-07 16:46:02.984286	2010-08-10 13:56:12.384029	yes	340
280	2010-08-05	5.2000000000000002	5.9000000000000004	6	34	14	2010-08-05 16:31:34.537698	2010-08-10 13:56:40.840349	yes	280
377	2010-08-07	1.46	239	0	1	13	2010-08-10 14:02:44.184804	2010-08-10 14:05:29.995838	yes	377
261	2010-08-03	4.7999999999999998	65.5	28	33	1	2010-08-03 11:05:50.668724	2010-08-10 16:18:50.624911	no	261
262	2010-08-03	7.5	54	32	33	15	2010-08-03 11:07:09.352161	2010-08-10 16:19:04.105274	no	262
378	2010-08-11	14	0.40000000000000002	2	15	3	2010-08-11 15:41:41.061754	2010-08-11 15:41:41.061754	no	378
379	2010-08-11	5.2000000000000002	9.0999999999999996	13	15	22	2010-08-11 15:43:19.752687	2010-08-11 15:43:19.752687	no	379
380	2010-08-11	4.7999999999999998	4.5999999999999996	8	19	1	2010-08-11 15:45:59.495715	2010-08-11 15:45:59.495715	no	380
381	2010-08-11	5.2000000000000002	2.5	8	1	2	2010-08-11 15:47:24.800307	2010-08-11 15:47:41.824848	yes	381
382	2010-08-11	14	0.69999999999999996	0	23	3	2010-08-11 15:49:22.638371	2010-08-11 15:49:22.638371	no	382
383	2010-08-11	4.7999999999999998	75.5	64	32	1	2010-08-11 15:50:49.933504	2010-08-11 15:50:49.933504	yes	383
384	2010-08-11	9	25.699999999999999	16	32	4	2010-08-11 15:53:43.868891	2010-08-11 15:53:54.613395	yes	384
385	2010-08-11	5.2000000000000002	8.9000000000000004	12	32	2	2010-08-11 15:55:37.968828	2010-08-11 15:55:37.968828	yes	385
386	2010-08-11	5.2000000000000002	65.5	4.2000000000000002	30	2	2010-08-11 15:59:23.40356	2010-08-11 15:59:23.40356	yes	386
387	2010-08-11	6	177.40000000000001	55	30	17	2010-08-11 16:01:24.96805	2010-08-11 16:17:59.145496	yes	387
388	2010-08-12	0	0	55	1	6	2010-08-12 12:31:57.655554	2010-08-12 12:33:03.860842	yes	388
389	2010-08-12	4.9000000000000004	23.699999999999999	0	3	2	2010-08-12 12:35:13.179194	2010-08-12 12:35:13.179194	yes	389
390	2010-08-12	4.7000000000000002	38.600000000000001	132	3	1	2010-08-12 12:37:54.807022	2010-08-12 12:37:54.807022	no	390
391	2010-08-12	7.5	106.5	140	19	15	2010-08-12 12:40:32.628878	2010-08-12 12:40:32.628878	no	391
392	2010-08-12	4.7999999999999998	248	312	19	1	2010-08-12 12:43:03.860504	2010-08-12 12:43:03.860504	no	392
422	2010-08-15	5.2000000000000002	0.80000000000000004	4	7	2	2010-08-15 11:28:41.712907	2010-08-15 11:28:41.712907	no	422
394	2010-08-12	4.9000000000000004	4.5	8	3	2	2010-08-12 12:48:15.617472	2010-08-12 12:48:15.617472	no	394
395	2010-08-12	4.7000000000000002	11.5	32	3	1	2010-08-12 12:52:08.835549	2010-08-12 12:52:08.835549	no	395
393	2010-08-12	5.2999999999999998	3.1000000000000001	16	1	24	2010-08-12 12:45:41.599883	2010-08-12 12:55:29.614108	yes	393
397	2010-08-12	10	0.5	7	14	10	2010-08-12 12:57:28.263009	2010-08-12 12:57:28.263009	no	397
398	2010-08-12	5.2000000000000002	10.5	4	2	2	2010-08-12 13:00:43.411079	2010-08-12 13:00:43.411079	no	398
399	2010-08-12	5.2000000000000002	8.0999999999999996	4	2	2	2010-08-12 13:02:21.014611	2010-08-12 13:02:21.014611	no	399
401	2010-08-13	7	13	8	19	11	2010-08-13 11:48:15.103516	2010-08-13 11:48:15.103516	no	401
402	2010-08-13	0	0	8	14	6	2010-08-13 11:49:56.538029	2010-08-13 11:49:56.538029	yes	402
403	2010-08-13	5.2000000000000002	1.2	4	1	23	2010-08-13 11:51:49.198505	2010-08-13 11:51:49.198505	yes	403
404	2010-08-13	5.2000000000000002	5.7000000000000002	22	26	2	2010-08-13 11:53:10.962685	2010-08-13 11:53:10.962685	no	404
405	2010-08-13	0	0	6	14	6	2010-08-13 11:54:17.901696	2010-08-13 11:54:17.901696	no	405
396	2010-08-12	5.2000000000000002	3.1000000000000001	7	1	2	2010-08-12 12:53:37.382252	2010-08-13 12:59:02.942024	yes	396
400	2010-08-12	5.2000000000000002	2.3999999999999999	4	34	14	2010-08-12 13:04:13.69478	2010-08-13 12:59:50.146653	yes	400
406	2010-08-14	5.2000000000000002	0.59999999999999998	4	2	2	2010-08-14 10:56:18.881447	2010-08-14 10:56:18.881447	no	406
407	2010-08-14	8	47.5	75.5	11	4	2010-08-14 10:58:04.608885	2010-08-14 10:58:04.608885	no	407
408	2010-08-14	0	0	6	32	6	2010-08-14 10:59:26.605353	2010-08-14 10:59:42.698898	yes	408
409	2010-08-14	17	11.4	40	1	20	2010-08-14 11:01:21.00993	2010-08-14 11:01:21.00993	yes	409
410	2010-08-14	5.2000000000000002	3.8999999999999999	4	1	2	2010-08-14 11:04:14.333107	2010-08-14 11:04:14.333107	yes	410
411	2010-08-14	5.2000000000000002	1.8999999999999999	0	34	14	2010-08-14 11:05:37.327943	2010-08-14 11:05:37.327943	yes	411
412	2010-08-14	4.9000000000000004	6.0999999999999996	8	3	2	2010-08-14 11:06:55.876157	2010-08-14 11:06:55.876157	no	412
413	2010-08-14	0	0	2	14	6	2010-08-14 11:08:12.682649	2010-08-14 11:08:12.682649	no	413
414	2010-08-15	2	185	0	1	13	2010-08-15 11:10:17.120681	2010-08-15 11:10:17.120681	yes	414
415	2010-08-15	14	0.80000000000000004	2	7	3	2010-08-15 11:12:16.235382	2010-08-15 11:12:16.235382	no	415
416	2010-08-15	17	2.6000000000000001	8	7	18	2010-08-15 11:13:44.344216	2010-08-15 11:13:44.344216	no	416
417	2010-08-15	5.2000000000000002	6.4000000000000004	32	7	2	2010-08-15 11:15:02.972803	2010-08-15 11:15:02.972803	no	417
418	2010-08-15	5.2000000000000002	8.1999999999999993	8	1	2	2010-08-15 11:21:38.035469	2010-08-15 11:21:38.035469	yes	418
419	2010-08-15	14	1.1499999999999999	2	1	3	2010-08-15 11:23:51.735475	2010-08-15 11:23:51.735475	yes	419
420	2010-08-15	5.2000000000000002	7.5	6	1	14	2010-08-15 11:25:16.893307	2010-08-15 11:25:16.893307	yes	420
423	2010-08-15	4.7000000000000002	12.300000000000001	32	3	1	2010-08-15 11:29:54.513423	2010-08-15 11:29:54.513423	no	423
424	2010-08-15	5.2000000000000002	6	6	19	2	2010-08-15 11:31:10.558079	2010-08-15 11:31:10.558079	no	424
425	2010-08-15	0	0	2	3	8	2010-08-15 11:32:05.187721	2010-08-15 11:32:05.187721	no	425
426	2010-08-16	0	0	15	32	6	2010-08-16 12:06:10.264337	2010-08-16 12:06:26.55199	yes	426
427	2010-08-16	10	26.5	26	8	9	2010-08-16 12:07:40.798518	2010-08-16 12:07:40.798518	no	427
428	2010-08-16	5.2000000000000002	270	640	6	14	2010-08-16 12:09:18.193315	2010-08-16 12:09:18.193315	no	428
429	2010-08-16	0	0	6	3	6	2010-08-16 12:10:33.070783	2010-08-16 12:10:33.070783	no	429
430	2010-08-16	4.9000000000000004	12.300000000000001	16	3	2	2010-08-16 12:11:52.47481	2010-08-16 12:11:52.47481	no	430
431	2010-08-16	4.7000000000000002	26.300000000000001	64	3	1	2010-08-16 12:13:06.370673	2010-08-16 12:13:06.370673	no	431
432	2010-08-17	5.2000000000000002	40.799999999999997	76	30	2	2010-08-17 12:49:56.764921	2010-08-17 12:49:56.764921	yes	432
433	2010-08-17	17	5	4	20	18	2010-08-17 12:53:20.334727	2010-08-17 12:53:20.334727	no	433
434	2010-08-17	4.7999999999999998	8.6999999999999993	12	20	1	2010-08-17 12:55:31.722208	2010-08-17 12:55:31.722208	no	434
435	2010-08-17	5.2000000000000002	17.699999999999999	8	20	2	2010-08-17 12:57:15.021809	2010-08-17 12:57:15.021809	no	435
436	2010-08-17	7.5	67	16	30	15	2010-08-17 13:00:44.501261	2010-08-17 13:00:44.501261	yes	436
437	2010-08-17	7	37.5	32	30	2	2010-08-17 13:02:15.65124	2010-08-17 13:02:15.65124	yes	437
438	2010-08-18	5.2000000000000002	1.6000000000000001	2	1	14	2010-08-18 13:05:06.203698	2010-08-18 13:05:06.203698	yes	438
439	2010-08-18	5.2000000000000002	1.2	1	1	14	2010-08-18 13:06:30.529198	2010-08-18 13:06:30.529198	yes	439
440	2010-08-18	4.7999999999999998	83	40	32	1	2010-08-18 13:08:10.308452	2010-08-18 13:08:38.763413	no	440
441	2010-08-18	4.7999999999999998	40	18	2	1	2010-08-18 13:10:34.609832	2010-08-18 13:10:34.609832	no	441
442	2010-08-18	5.2000000000000002	3.7000000000000002	2	7	22	2010-08-18 13:13:47.417319	2010-08-18 13:13:47.417319	no	442
443	2010-08-18	4.9000000000000004	5.9000000000000004	8	3	2	2010-08-18 13:16:40.759537	2010-08-18 13:16:40.759537	no	443
444	2010-08-18	4.7000000000000002	8.9000000000000004	28	3	1	2010-08-18 13:18:11.220052	2010-08-19 13:08:58.643153	no	444
446	2010-08-18	8	48	52	11	4	2010-08-18 14:28:19.518204	2010-08-18 14:28:19.518204	no	445
447	2010-08-18	4.7999999999999998	1.3	6	1	1	2010-08-18 14:30:04.877059	2010-08-18 14:30:04.877059	yes	447
448	2010-08-18	7.5	13	8	19	15	2010-08-18 14:31:26.577211	2010-08-18 14:31:26.577211	no	448
449	2010-08-18	5.2000000000000002	18	40	19	2	2010-08-18 14:32:55.53085	2010-08-18 14:32:55.53085	no	449
450	2010-08-19	5.2000000000000002	62.799999999999997	24	5	2	2010-08-19 11:35:50.253697	2010-08-19 11:35:50.253697	no	450
451	2010-08-19	5.2000000000000002	9.5	18	15	22	2010-08-19 11:37:10.89921	2010-08-19 11:37:10.89921	no	451
453	2010-08-19	5.2000000000000002	2	2	1	2	2010-08-19 11:40:34.378427	2010-08-19 11:40:34.378427	yes	452
454	2010-08-19	5.2000000000000002	0.29999999999999999	0	32	2	2010-08-19 11:42:17.456232	2010-08-19 11:42:17.456232	no	454
455	2010-08-19	10	22	26	8	9	2010-08-19 11:43:46.698554	2010-08-19 11:43:46.698554	no	455
456	2010-08-19	5.2000000000000002	5	16	19	2	2010-08-19 11:45:26.631966	2010-08-19 11:45:26.631966	no	456
457	2010-08-20	5.2000000000000002	0.90000000000000002	65	7	14	2010-08-20 13:32:01.501101	2010-08-20 13:32:01.501101	no	457
459	2010-08-20	7.5	9.5	5	1	15	2010-08-20 13:34:53.026829	2010-08-20 13:34:53.026829	yes	459
460	2010-08-20	5.2000000000000002	3.7999999999999998	8	1	2	2010-08-20 13:36:22.186124	2010-08-20 13:36:22.186124	yes	460
461	2010-08-20	5.2000000000000002	7.2999999999999998	8	33	2	2010-08-20 13:37:36.332489	2010-08-20 13:37:36.332489	yes	461
462	2010-08-20	5.2000000000000002	7.2999999999999998	8	19	2	2010-08-20 13:38:56.714988	2010-08-20 13:38:56.714988	no	462
463	2010-08-20	14	30	0	28	20	2010-08-20 13:40:12.545875	2010-08-20 13:40:12.545875	no	463
464	2010-08-20	5.2000000000000002	0.59999999999999998	1	1	2	2010-08-20 13:41:41.835755	2010-08-20 13:41:41.835755	yes	464
465	2010-08-20	5.2000000000000002	2.5	10	26	2	2010-08-20 13:43:43.537907	2010-08-20 13:43:43.537907	yes	465
466	2010-08-20	10	4.0999999999999996	11	29	10	2010-08-20 13:45:03.434721	2010-08-20 13:45:03.434721	no	466
467	2010-08-20	14	1.2	2	34	3	2010-08-20 13:47:02.75373	2010-08-20 13:47:02.75373	yes	467
468	2010-08-20	5.2000000000000002	8.5	3	34	14	2010-08-20 13:48:24.585152	2010-08-20 13:48:24.585152	yes	468
469	2010-08-20	5.2000000000000002	104.3	124	30	2	2010-08-20 13:49:45.985276	2010-08-20 15:13:32.661034	yes	469
458	2010-08-20	7.5	68.5	30	30	15	2010-08-20 13:33:30.44151	2010-08-20 15:14:02.516764	yes	458
470	2010-08-21	9	21	26	1	4	2010-08-21 11:50:01.266568	2010-08-21 11:50:01.266568	yes	470
471	2010-08-21	0	0	55	26	6	2010-08-21 11:51:43.824395	2010-08-21 11:51:43.824395	no	471
472	2010-08-21	5.2000000000000002	0.59999999999999998	2	34	14	2010-08-21 11:52:56.651332	2010-08-21 11:52:56.651332	yes	472
473	2010-08-21	5.2000000000000002	5	4	1	2	2010-08-21 11:54:42.664546	2010-08-21 11:54:42.664546	yes	473
474	2010-08-21	0	0	168	22	6	2010-08-21 11:55:46.420441	2010-08-21 11:55:46.420441	no	474
475	2010-08-21	4.9000000000000004	7.4000000000000004	12	3	2	2010-08-21 11:57:13.033878	2010-08-21 11:57:13.033878	no	475
476	2010-08-21	4.7000000000000002	17	32	3	1	2010-08-21 11:58:23.176555	2010-08-21 11:58:23.176555	no	476
477	2010-08-21	5.2000000000000002	5.5	7	1	2	2010-08-21 11:59:48.893217	2010-08-21 11:59:48.893217	yes	477
478	2010-08-21	10	4.5999999999999996	2	34	10	2010-08-21 12:01:00.673463	2010-08-21 12:01:00.673463	yes	478
479	2010-08-21	10	30.5	26	8	9	2010-08-21 12:02:13.712074	2010-08-21 12:02:13.712074	no	479
480	2010-08-21	8.5	56.5	52	11	9	2010-08-21 12:03:35.363165	2010-08-21 12:03:35.363165	no	480
481	2010-08-21	5.2000000000000002	5.0999999999999996	4	1	2	2010-08-21 12:04:54.853606	2010-08-21 12:04:54.853606	yes	481
482	2010-08-22	5.2000000000000002	5	7	1	2	2010-08-22 11:45:58.630895	2010-08-22 11:45:58.630895	yes	482
483	2010-08-22	5.2000000000000002	6.25	4	1	2	2010-08-22 11:47:03.20287	2010-08-22 11:47:03.20287	yes	483
484	2010-08-22	4.9000000000000004	9.8000000000000007	16	3	2	2010-08-22 11:48:22.020981	2010-08-22 11:48:22.020981	no	484
485	2010-08-22	4.7000000000000002	16.600000000000001	32	3	1	2010-08-22 11:50:01.005441	2010-08-22 11:50:01.005441	no	485
486	2010-08-22	0	0	10	3	8	2010-08-22 11:50:46.861581	2010-08-22 11:50:46.861581	no	486
487	2010-08-22	4.7999999999999998	96.5	32	14	1	2010-08-22 11:52:12.032356	2010-08-22 11:52:12.032356	no	487
488	2010-08-22	4.7999999999999998	26	24	2	1	2010-08-22 11:53:43.529796	2010-08-22 11:53:43.529796	no	488
489	2010-08-22	4.7999999999999998	40.5	32	31	1	2010-08-22 11:55:23.71644	2010-08-22 11:55:23.71644	no	489
491	2010-08-22	5.2000000000000002	1.3999999999999999	0	34	14	2010-08-22 11:59:43.239573	2010-08-22 11:59:43.239573	no	491
492	2010-08-22	5.2000000000000002	15.300000000000001	20	1	2	2010-08-22 12:02:26.978822	2010-08-22 12:02:26.978822	yes	492
493	2010-08-22	5.2000000000000002	13.199999999999999	12	1	2	2010-08-22 12:03:57.758787	2010-08-22 12:04:10.859716	yes	493
494	2010-08-22	5.2000000000000002	4.9000000000000004	8	1	2	2010-08-22 12:05:47.350774	2010-08-22 12:06:00.353434	yes	494
495	2010-08-22	5.2000000000000002	5.7999999999999998	8	1	2	2010-08-22 12:07:30.452384	2010-08-22 12:07:40.799154	yes	495
496	2010-08-22	5.2000000000000002	1.2	2	34	14	2010-08-22 12:10:56.790222	2010-08-22 12:10:56.790222	yes	496
490	2010-08-22	4.7999999999999998	36	38	31	1	2010-08-22 11:56:58.81883	2010-08-22 12:21:08.075428	no	490
497	2010-08-23	2	125	0	1	13	2010-08-23 11:52:02.719988	2010-08-23 11:52:11.910612	yes	497
498	2010-08-23	0	0	4	22	6	2010-08-23 11:53:22.386372	2010-08-23 11:53:22.386372	no	498
499	2010-08-23	9	11.199999999999999	8	29	4	2010-08-23 11:54:38.204817	2010-08-23 11:54:38.204817	no	499
500	2010-08-23	10	7.3499999999999996	2	34	10	2010-08-23 11:56:13.577384	2010-08-23 11:56:13.577384	yes	500
501	2010-08-23	5.2000000000000002	4.5999999999999996	2	34	2	2010-08-23 11:58:34.775063	2010-08-23 11:58:34.775063	yes	501
502	2010-08-23	4.7999999999999998	21	56	1	1	2010-08-23 12:00:30.383653	2010-08-23 12:00:30.383653	yes	502
503	2010-08-23	0	0	6	29	6	2010-08-23 12:02:01.420428	2010-08-23 12:02:01.420428	no	503
504	2010-08-23	9	31.5	24	32	4	2010-08-23 12:04:54.616882	2010-08-23 12:04:54.616882	no	504
505	2010-08-23	5.5	2.7999999999999998	8	32	24	2010-08-23 12:06:56.931259	2010-08-23 12:06:56.931259	no	505
506	2010-08-23	9	57.5	48	32	4	2010-08-23 12:08:34.032406	2010-08-23 12:08:34.032406	no	506
507	2010-08-24	5.2000000000000002	1.3	4	1	2	2010-08-24 11:31:32.031698	2010-08-24 11:31:32.031698	yes	507
508	2010-08-24	0	0	6	14	6	2010-08-24 11:32:58.802088	2010-08-24 11:32:58.802088	no	508
509	2010-08-24	5.2000000000000002	22	32	32	2	2010-08-24 11:34:54.992663	2010-08-24 11:34:54.992663	no	509
510	2010-08-24	5.2000000000000002	4	12	6	22	2010-08-24 11:36:18.76754	2010-08-24 11:36:18.76754	no	510
511	2010-08-24	5.2000000000000002	4.2000000000000002	16	33	2	2010-08-24 11:37:40.284565	2010-08-24 11:37:40.284565	yes	511
512	2010-08-24	5.2000000000000002	2.2000000000000002	8	22	2	2010-08-24 11:38:56.401512	2010-08-24 11:38:56.401512	no	512
513	2010-08-24	5.2000000000000002	4.5	8	34	14	2010-08-24 11:41:14.156709	2010-08-24 11:41:14.156709	yes	513
514	2010-08-24	5.2000000000000002	8.3000000000000007	0	21	22	2010-08-24 11:42:44.661167	2010-08-24 11:42:44.661167	no	514
515	2010-08-24	0	0	6	32	6	2010-08-24 11:43:58.708385	2010-08-24 11:43:58.708385	no	515
516	2010-08-24	0	0	5	22	6	2010-08-24 11:44:58.167867	2010-08-24 11:44:58.167867	no	516
518	2010-08-25	5.2000000000000002	2	0	34	14	2010-08-25 12:19:26.680794	2010-08-25 12:19:46.035943	yes	518
517	2010-08-25	8.5	3.2999999999999998	0	34	5	2010-08-25 12:18:05.035342	2010-08-25 12:20:00.277761	yes	517
519	2010-08-25	5	2.5	8	3	2	2010-08-25 12:21:31.427311	2010-08-25 12:21:31.427311	no	519
520	2010-08-25	4.7999999999999998	22.199999999999999	60	3	1	2010-08-25 12:22:51.347465	2010-08-25 12:22:51.347465	no	520
521	2010-08-25	5.2000000000000002	20	32	2	2	2010-08-25 12:24:38.063446	2010-08-25 12:24:38.063446	no	521
522	2010-08-25	5.2000000000000002	19.399999999999999	12	24	14	2010-08-25 12:26:42.414537	2010-08-25 12:26:42.414537	no	522
523	2010-08-25	14.5	9.6999999999999993	12	24	3	2010-08-25 12:27:51.601061	2010-08-25 12:27:51.601061	no	523
524	2010-08-25	17	5.5	22	24	18	2010-08-25 12:29:21.998103	2010-08-25 12:29:21.998103	no	524
525	2010-08-25	4.7999999999999998	117	96	31	1	2010-08-25 12:30:53.643943	2010-08-25 12:30:53.643943	no	525
526	2010-08-25	10	121.5	104	8	9	2010-08-25 12:32:11.892208	2010-08-25 12:32:11.892208	no	526
527	2010-08-25	8	19	26	10	4	2010-08-25 12:33:43.099607	2010-08-25 12:33:43.099607	no	527
528	2010-08-25	8	63	52	11	4	2010-08-25 12:35:18.050214	2010-08-25 12:35:18.050214	no	528
529	2010-08-25	5.2000000000000002	5.5999999999999996	16	2	2	2010-08-25 12:36:37.657714	2010-08-25 12:36:37.657714	no	529
530	2010-08-25	4.7999999999999998	3.7999999999999998	26	14	1	2010-08-25 12:38:22.521015	2010-08-25 12:38:22.521015	no	530
531	2010-08-25	5.2000000000000002	13	48	19	2	2010-08-25 12:39:56.540113	2010-08-25 12:39:56.540113	no	531
532	2010-08-25	9	0	6	14	6	2010-08-25 12:40:49.765634	2010-08-25 12:40:49.765634	no	532
533	2010-08-26	5	25.300000000000001	28	3	2	2010-08-26 11:45:13.572257	2010-08-26 11:45:13.572257	no	533
534	2010-08-26	4.7999999999999998	55.399999999999999	128	3	1	2010-08-26 11:46:49.506171	2010-08-26 11:46:49.506171	no	534
535	2010-08-26	5.2000000000000002	7.2999999999999998	22	29	2	2010-08-26 11:48:03.886578	2010-08-26 11:48:03.886578	yes	535
537	2010-08-26	5.2000000000000002	3.2999999999999998	4	32	2	2010-08-26 11:51:05.005244	2010-08-26 11:51:05.005244	no	537
542	2010-08-26	5.2000000000000002	2.3999999999999999	6	1	14	2010-08-26 11:59:58.5441	2010-08-26 11:59:58.5441	no	542
543	2010-08-26	0	0	5	22	6	2010-08-26 12:00:57.249732	2010-08-26 12:00:57.249732	no	543
544	2010-08-27	8	53.5	105	11	9	2010-08-27 11:38:09.172524	2010-08-27 11:38:09.172524	no	544
545	2010-08-27	5.2000000000000002	2.1000000000000001	0	1	22	2010-08-27 11:39:48.073738	2010-08-27 11:39:48.073738	yes	545
546	2010-08-27	5.2000000000000002	5.7999999999999998	2	34	14	2010-08-27 11:41:24.651983	2010-08-27 11:41:24.651983	yes	546
547	2010-08-27	5.2000000000000002	72	32	30	2	2010-08-27 11:42:39.601579	2010-08-27 11:42:39.601579	yes	547
548	2010-08-27	5.2000000000000002	73.599999999999994	45	1	2	2010-08-27 11:44:09.791014	2010-08-27 11:44:09.791014	no	548
549	2010-08-27	5.2000000000000002	135.09999999999999	128	1	2	2010-08-27 11:45:07.794151	2010-08-27 11:45:07.794151	no	549
550	2010-08-27	19	4.5	49	10	18	2010-08-27 11:46:42.070519	2010-08-27 11:46:42.070519	no	550
551	2010-08-27	5.2000000000000002	2.2999999999999998	0	34	14	2010-08-27 11:47:49.328641	2010-08-27 11:47:49.328641	yes	551
552	2010-08-27	5.2000000000000002	6.7000000000000002	8	14	23	2010-08-27 11:49:16.455694	2010-08-27 11:49:16.455694	no	552
553	2010-08-27	5	16	20	3	2	2010-08-27 11:50:15.947561	2010-08-27 11:50:15.947561	no	553
554	2010-08-27	4.7999999999999998	40.600000000000001	64	3	1	2010-08-27 11:51:15.303254	2010-08-27 11:51:15.303254	no	554
540	2010-08-26	7	77	60	30	11	2010-08-26 11:55:18.174463	2010-08-27 11:51:44.059817	yes	540
539	2010-08-26	5.2000000000000002	10	20	30	2	2010-08-26 11:54:07.70512	2010-08-27 11:52:12.379302	yes	539
536	2010-08-26	5.2000000000000002	75	32	30	2	2010-08-26 11:49:50.989793	2010-08-27 11:52:40.633574	yes	536
541	2010-08-26	5.2000000000000002	9.0999999999999996	32	34	14	2010-08-26 11:56:42.325111	2010-08-27 11:53:21.414195	yes	541
538	2010-08-26	17	10	10	29	18	2010-08-26 11:52:46.190493	2010-08-27 11:53:46.898273	yes	538
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY products (id, name, price, created_at, updated_at) FROM stdin;
9	原钢板	6.7999999999999998	2010-07-12 12:38:00.055862	2010-07-21 12:53:49.107187
5	冲头柄	6	2010-07-11 13:16:50.925067	2010-07-21 13:00:33.12482
8	2钨8	38	2010-07-12 12:33:57.084385	2010-07-21 13:01:07.660829
10	弹簧钢	7.5	2010-07-15 13:26:22.584052	2010-07-21 13:01:23.151229
11	中碳锻件	6.5	2010-07-15 13:28:12.78282	2010-07-21 13:01:44.543842
13	铁削	0.5	2010-07-16 12:46:09.376583	2010-07-21 13:12:03.938122
15	40铬锻件	7.0999999999999996	2010-07-19 18:15:12.441836	2010-07-21 15:35:26.14649
7	40铬	5.7999999999999998	2010-07-12 12:31:41.70436	2010-07-21 15:41:37.834128
18	铬12板	14	2010-07-21 15:53:01.522713	2010-07-21 15:53:01.522713
19	铬12一般	7.5	2010-07-22 13:57:11.881216	2010-07-22 13:57:11.881216
20	4铬13	11.199999999999999	2010-07-22 14:03:37.163971	2010-07-22 14:03:37.163971
4	42Cy板	6.7999999999999998	2010-07-10 10:43:56.561367	2010-07-22 14:05:07.626506
21	42Cy锻	8.4000000000000004	2010-07-22 14:05:29.57258	2010-07-22 14:05:29.57258
16	40铬板	5.7999999999999998	2010-07-19 18:15:38.53075	2010-07-22 14:08:04.900016
3	铬12圆钢	12	2010-07-10 10:43:56.552027	2010-07-22 14:19:32.821139
1	A3板	4.5999999999999996	2010-07-09 17:56:12.251746	2010-07-22 14:32:21.205372
22	A3圆	4.5	2010-07-22 14:32:46.992869	2010-07-22 14:32:46.992869
14	中碳圆	4.5	2010-07-19 18:13:44.486842	2010-07-22 14:36:29.029249
23	中碳板12	5	2010-07-27 13:35:11.135868	2010-07-27 13:35:11.135868
24	中碳板10	5.2000000000000002	2010-07-27 13:35:35.160121	2010-07-27 13:35:35.160121
2	中碳板16	4.7999999999999998	2010-07-10 10:43:55.795157	2010-07-27 13:36:02.867819
17	中碳方块50	5.5	2010-07-21 13:04:38.492183	2010-08-11 16:15:50.240274
25	中碳方块55	5.5999999999999996	2010-08-11 16:16:28.949346	2010-08-11 16:16:28.949346
12	铬12正锻	14.380000000000001	2010-07-15 13:28:42.526965	2010-08-21 14:08:26.24296
6	加工	0	2010-07-11 15:36:15.581661	2010-08-22 03:14:18.114805
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY purchases (id, date, product_id, price, volume, created_at, updated_at, seq_no) FROM stdin;
52	2010-08-14	14	4.7000000000000002	38	2010-08-14 11:15:22.401978	2010-08-14 11:15:22.401978	52
53	2010-08-16	15	7.0999999999999996	3.2000000000000002	2010-08-16 15:03:21.735584	2010-08-16 15:03:21.735584	53
54	2010-08-17	15	7.0999999999999996	67	2010-08-17 13:03:54.530717	2010-08-17 13:03:54.530717	54
55	2010-08-17	11	6.2000000000000002	37.5	2010-08-17 13:05:38.506505	2010-08-17 13:05:38.506505	55
57	2010-08-17	6	55	2	2010-08-17 13:07:46.235852	2010-08-17 13:07:46.235852	57
58	2010-08-10	1	4.5999999999999996	75.5	2010-08-18 14:37:47.825972	2010-08-18 14:37:47.825972	58
59	2010-08-10	1	4.5999999999999996	92	2010-08-18 14:38:59.963958	2010-08-18 14:38:59.963958	59
1	2010-07-19	1	4.5999999999999996	279	2010-07-19 18:11:23.636713	2010-08-01 15:49:40.906588	1
6	2010-07-18	16	5.7999999999999998	197	2010-07-20 12:32:34.021728	2010-08-01 15:49:40.985438	6
9	2010-07-20	16	5.7999999999999998	186	2010-07-20 12:35:52.83438	2010-08-01 15:49:40.988236	9
10	2010-07-22	12	14	11.5	2010-07-22 14:24:53.228107	2010-08-01 15:49:40.99078	10
11	2010-07-22	11	6.5	11	2010-07-22 14:26:19.447497	2010-08-01 15:49:40.99353	11
12	2010-07-22	15	7.0999999999999996	120.5	2010-07-22 14:29:11.749044	2010-08-01 15:49:40.996278	12
5	2010-07-18	15	7.0999999999999996	40	2010-07-20 12:31:12.708206	2010-08-01 15:49:40.998739	5
8	2010-07-17	2	4.7000000000000002	568	2010-07-20 12:34:41.137553	2010-08-01 15:49:41.001259	8
2	2010-07-20	14	4.2000000000000002	57	2010-07-20 12:25:07.756401	2010-08-01 15:49:41.003815	2
7	2010-07-18	2	4.7000000000000002	36	2010-07-20 12:33:34.072992	2010-08-01 15:49:41.006332	7
13	2010-07-11	1	4.4000000000000004	557	2010-07-25 13:19:34.143676	2010-08-01 15:49:41.008781	13
14	2010-07-14	1	4.4000000000000004	442.5	2010-07-25 13:21:28.776819	2010-08-01 15:49:41.01149	14
16	2010-07-14	1	4.5999999999999996	76.5	2010-07-25 13:23:40.819298	2010-08-01 15:49:41.014038	16
18	2010-07-18	1	4.5999999999999996	279	2010-07-25 13:27:22.18995	2010-08-01 15:49:41.016514	18
19	2010-07-23	1	4.5999999999999996	235	2010-07-25 13:30:21.830422	2010-08-01 15:49:41.019108	19
20	2010-07-18	11	6.5	5.5	2010-07-25 13:32:39.540401	2010-08-01 15:49:41.021527	20
21	2010-07-19	12	14.5	9	2010-07-25 13:33:49.872481	2010-08-01 15:49:41.024014	21
22	2010-07-25	2	4.7000000000000002	493	2010-07-25 13:35:50.345914	2010-08-01 15:49:41.026702	22
23	2010-07-19	14	4.2000000000000002	57	2010-07-25 13:52:36.958862	2010-08-01 15:49:41.029163	23
24	2010-07-19	14	4.25	175	2010-07-25 13:53:44.589343	2010-08-01 15:49:41.031617	24
25	2010-07-24	22	4.2999999999999998	174	2010-07-25 13:56:13.759103	2010-08-01 15:49:41.034164	25
26	2010-07-27	2	4.7999999999999998	217.5	2010-07-27 13:29:56.164546	2010-08-01 15:49:41.036652	26
27	2010-07-27	23	5	104	2010-07-27 13:31:36.718437	2010-08-01 15:49:41.039158	27
28	2010-07-29	12	14.5	8.8000000000000007	2010-07-29 11:48:59.35421	2010-08-01 15:49:41.041692	28
29	2010-07-29	24	5.4000000000000004	228	2010-07-29 11:50:41.588259	2010-08-01 15:49:41.044209	29
30	2010-08-01	15	7.0999999999999996	8	2010-08-01 11:30:18.398529	2010-08-01 15:49:41.046739	30
31	2010-08-01	2	4.7999999999999998	299	2010-08-01 11:31:25.099456	2010-08-01 15:49:41.049197	31
32	2010-08-01	16	5.7000000000000002	225.5	2010-08-01 11:32:59.49655	2010-08-01 15:49:41.051662	32
33	2010-08-03	1	4.5999999999999996	415.5	2010-08-03 11:27:03.62044	2010-08-03 11:27:33.845546	33
34	2010-08-03	1	4.4000000000000004	343	2010-08-03 11:28:32.813065	2010-08-03 11:28:32.813065	34
35	2010-08-03	15	7.0999999999999996	54	2010-08-03 11:29:27.560494	2010-08-03 11:29:27.560494	35
36	2010-08-04	12	14.5	17.5	2010-08-04 13:40:38.242148	2010-08-04 13:40:38.242148	36
37	2010-08-04	2	4.7999999999999998	187.5	2010-08-04 13:42:06.086869	2010-08-04 13:42:06.086869	37
39	2010-08-05	1	4.5999999999999996	185	2010-08-05 17:29:49.066951	2010-08-05 17:29:49.066951	39
40	2010-08-05	1	4.5999999999999996	17	2010-08-05 17:30:47.429243	2010-08-05 17:30:47.429243	40
38	2010-08-05	15	7.0999999999999996	6.2000000000000002	2010-08-05 17:28:30.145036	2010-08-06 13:19:11.765595	38
41	2010-08-09	15	7.0999999999999996	171	2010-08-09 11:54:43.671725	2010-08-09 11:54:43.671725	41
42	2010-08-09	11	6.2000000000000002	13	2010-08-09 11:57:19.583008	2010-08-09 11:57:19.583008	42
44	2010-08-10	16	5.7000000000000002	716	2010-08-10 13:44:45.506562	2010-08-10 13:44:45.506562	43
45	2010-08-10	16	5.7000000000000002	216.5	2010-08-10 13:45:51.14827	2010-08-10 13:45:51.14827	45
46	2010-08-11	15	7.0999999999999996	36.5	2010-08-11 16:09:21.922252	2010-08-11 16:09:21.922252	46
47	2010-08-11	2	5	439	2010-08-11 16:10:27.429639	2010-08-11 16:10:27.429639	47
60	2010-08-10	1	4.5999999999999996	248	2010-08-18 14:40:55.808427	2010-08-18 14:40:55.808427	60
48	2010-08-11	17	5.5	94	2010-08-11 16:11:48.295192	2010-08-11 16:16:54.211529	48
49	2010-08-11	25	5.5999999999999996	68.5	2010-08-11 16:13:38.142648	2010-08-11 16:17:10.350541	49
50	2010-08-14	22	4.5	86	2010-08-14 11:12:53.552006	2010-08-14 11:12:53.552006	50
51	2010-08-14	14	4.5999999999999996	90	2010-08-14 11:14:34.588774	2010-08-14 11:14:34.588774	51
61	2010-08-18	15	7.0999999999999996	13	2010-08-18 14:42:02.960598	2010-08-18 14:42:02.960598	61
62	2010-08-18	1	4.5999999999999996	83	2010-08-18 14:42:56.283152	2010-08-18 14:42:56.283152	62
63	2010-08-18	1	4.5999999999999996	40	2010-08-18 14:44:25.442625	2010-08-18 14:44:25.442625	63
64	2010-08-18	1	4.4000000000000004	122	2010-08-18 14:46:44.065526	2010-08-18 14:46:44.065526	64
65	2010-08-18	1	4.4000000000000004	322	2010-08-18 14:48:06.895274	2010-08-18 14:48:06.895274	65
66	2010-08-19	15	7.0999999999999996	68.5	2010-08-19 11:47:11.130295	2010-08-19 11:47:11.130295	66
56	2010-08-17	6	110	2	2010-08-17 13:07:12.042086	2010-08-19 13:11:44.152754	56
67	2010-08-20	2	5	115.5	2010-08-20 13:50:48.231653	2010-08-20 13:50:48.231653	67
68	2010-08-20	23	5.2000000000000002	45.5	2010-08-20 13:51:47.629214	2010-08-20 13:51:47.629214	68
69	2010-08-21	23	5.2000000000000002	33.5	2010-08-21 12:06:55.724936	2010-08-21 12:06:55.724936	69
70	2010-08-21	1	4.5999999999999996	199	2010-08-21 12:07:35.502695	2010-08-21 12:07:35.502695	70
71	2010-08-23	21	8	10	2010-08-23 12:11:51.209711	2010-08-23 12:11:51.209711	71
72	2010-08-23	20	11.5	895	2010-08-23 12:17:05.181619	2010-08-23 12:17:05.181619	72
73	2010-08-23	4	6.7999999999999998	2315	2010-08-23 12:18:47.43556	2010-08-23 12:18:47.43556	73
74	2010-08-23	18	12.699999999999999	360	2010-08-23 12:21:46.20652	2010-08-23 12:22:40.222645	74
75	2010-08-23	3	12.199999999999999	89	2010-08-23 12:24:13.303584	2010-08-23 12:24:13.303584	75
76	2010-08-23	3	11.699999999999999	106	2010-08-23 12:25:43.017137	2010-08-23 12:26:33.450896	76
77	2010-08-24	1	4.5999999999999996	117	2010-08-24 11:46:25.536856	2010-08-24 11:46:25.536856	77
78	2010-08-25	15	7.0999999999999996	78	2010-08-25 12:42:29.362259	2010-08-25 12:42:29.362259	78
79	2010-08-25	11	6.2000000000000002	77	2010-08-25 12:43:18.417853	2010-08-25 12:43:18.417853	79
80	2010-08-25	3	12.199999999999999	46	2010-08-25 12:44:04.568485	2010-08-25 12:44:04.568485	80
81	2010-08-26	15	7.0999999999999996	118	2010-08-26 12:01:59.853417	2010-08-26 12:01:59.853417	81
82	2010-08-27	2	5	94.5	2010-08-27 12:00:36.825262	2010-08-27 12:00:36.825262	82
\.


--
-- Data for Name: receivables; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY receivables (id, seq_no, date, customer_id, amount, created_at, updated_at) FROM stdin;
2	1	2010-08-02	5	10000	2010-08-03 11:32:14.690084	2010-08-03 11:32:14.690084
3	3	2010-07-01	28	-5215	2010-08-03 11:36:48.51923	2010-08-03 11:36:48.51923
4	4	2010-07-01	10	-8123	2010-08-03 11:37:29.845313	2010-08-03 11:37:29.845313
5	5	2010-07-01	11	-26653	2010-08-03 11:38:06.903435	2010-08-03 11:38:32.42744
6	6	2010-07-01	12	-9766	2010-08-03 11:39:24.55479	2010-08-03 11:39:24.55479
7	7	2010-07-01	13	-7413	2010-08-03 11:40:06.148901	2010-08-03 11:40:06.148901
8	8	2010-07-01	2	-9692	2010-08-03 11:40:42.41345	2010-08-03 11:40:42.41345
9	9	2010-07-01	14	-2058	2010-08-03 11:41:27.208269	2010-08-03 11:41:27.208269
10	10	2010-07-01	3	-31761	2010-08-03 11:42:00.336718	2010-08-03 11:42:00.336718
12	12	2010-07-01	15	-12080	2010-08-03 11:43:28.059292	2010-08-03 11:43:28.059292
13	13	2010-07-01	7	-7312	2010-08-03 11:43:54.000739	2010-08-03 11:43:54.000739
15	15	2010-07-01	17	-7093	2010-08-03 11:45:08.008545	2010-08-03 11:45:08.008545
17	17	2010-07-16	18	7000	2010-08-03 13:23:59.774823	2010-08-03 13:23:59.774823
18	18	2010-07-01	19	-25155	2010-08-03 13:25:29.834875	2010-08-03 13:25:29.834875
19	19	2010-07-16	12	9766	2010-08-03 13:28:51.180026	2010-08-03 13:28:51.180026
20	20	2010-07-26	12	2000	2010-08-03 13:29:26.661778	2010-08-03 13:29:26.661778
21	21	2010-08-04	25	2870	2010-08-04 13:43:24.101625	2010-08-04 13:44:05.978074
22	22	2010-08-05	32	1980	2010-08-05 17:32:00.906245	2010-08-05 17:32:00.906245
24	24	2010-08-08	16	8000	2010-08-08 10:55:21.69474	2010-08-08 10:55:21.69474
25	25	2010-08-08	32	350	2010-08-08 10:55:56.288306	2010-08-08 10:55:56.288306
11	11	2010-07-01	5	-14076	2010-08-03 11:42:49.654201	2010-08-08 10:59:37.394225
26	26	2010-07-01	18	-7028	2010-08-10 15:01:40.419155	2010-08-10 15:01:40.419155
27	27	2010-07-01	16	-8144	2010-08-10 15:02:14.639257	2010-08-10 15:02:14.639257
23	23	2010-08-06	33	848	2010-08-06 11:00:38.436031	2010-08-10 15:06:42.727135
28	28	2010-07-01	32	-1242	2010-08-10 16:24:04.337575	2010-08-10 16:24:04.337575
29	29	2010-08-11	33	1090	2010-08-11 16:03:37.528707	2010-08-11 16:08:03.419857
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY schema_migrations (version) FROM stdin;
20100703101301
20100705150624
20100705151124
20100705151548
20100707144524
20100707144821
20100709125613
20100710084758
20100710085040
20100711152631
20100715141845
20100719163739
20100801142229
20100801160437
20100814143227
20100819142530
20100820173049
20100826132305
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY suppliers (id, seq_no, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: oeulrfrvfh
--

COPY users (id, username, email, crypted_password, password_salt, persistence_token, name, address, telephone, cell_phone, id_no, business_no, company, addtional, created_at, updated_at) FROM stdin;
1	057788813958		968c6f3aa38f7c9ca70346e914092f27f67a2585e6fd5c0a6fd2943502247c3b8c543a4a4d7df9dd118b90ccd6eeec273cef5729c3b36d962c8ee2ad1fcfa673	WO74lWsR8Zhvfy2jogaW	4f980e199b24b4522d1ec8e9088134e8e5077b15fade12dcb9c5edff59fd931770b820c5d64bc586e3f7cc48cae4e958f76897b3e282becc48fc6d59f36b7e75	杨荣华	浙江省温州市蒲鞋市路241号	057788813958	13867728369			彩娒磨具店	爸爸的账号	2010-08-27 16:38:40.475694	2010-08-27 16:38:40.475694
2	000000	888888@qq.com	236615a4c86f0d9c22648bd57740913a10177d8e33f0f60461bcdb5a3086b10c5693c9a019a01ffaeb708098c71c318b41c885740e1d4dcfc190c93ef2199198	3l4br5m4wx3aZrVJiFA	1a07026df1a7ab7dd61c423825629ae1c813ea1fef23367ce548121f13ad2a5322c6855fdb1752d5236bdc05e414985b519a20f405c7a560eb6a0aa81df3a798	试用用户	浙江省温州市人民路88号	057788855888	13868818188	330302196302281688		兆兴磨具店	附加信息	2010-08-27 16:50:55.502028	2010-08-27 17:06:09.131226
\.


SET search_path = leaf_000000, pg_catalog;

--
-- Name: customers_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: orders_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchases_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: receivables_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY receivables
    ADD CONSTRAINT receivables_pkey PRIMARY KEY (id);


--
-- Name: suppliers_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


SET search_path = leaf_057788813958, pg_catalog;

--
-- Name: customers_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: orders_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchases_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: receivables_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY receivables
    ADD CONSTRAINT receivables_pkey PRIMARY KEY (id);


--
-- Name: suppliers_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


SET search_path = public, pg_catalog;

--
-- Name: customers_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: orders_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: receivables_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY receivables
    ADD CONSTRAINT receivables_pkey PRIMARY KEY (id);


--
-- Name: suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


SET search_path = leaf_000000, pg_catalog;

--
-- Name: unique_schema_migrations; Type: INDEX; Schema: leaf_000000; Owner: oeulrfrvfh; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


SET search_path = leaf_057788813958, pg_catalog;

--
-- Name: unique_schema_migrations; Type: INDEX; Schema: leaf_057788813958; Owner: oeulrfrvfh; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


SET search_path = public, pg_catalog;

--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: oeulrfrvfh; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

