class OrdersController < ApplicationController
  before_filter :require_user
  # before_filter :authorize
  
  # GET /orders
  # GET /orders.xml
  def index
    if params[:start]!=nil
      session[:start] = Order.str_civil params[:start][:year], params[:start][:month], params[:start][:day]
    end
    # if session[:start] == nil
      session[:start] ||= Date.today-1.days
    # end
    @start_date = session[:start]
    if params[:end]!=nil
        session[:end] = Order.str_civil params[:end][:year], params[:end][:month], params[:end][:day]
    end
    # if session[:end] == nil
      session[:end] ||= Date.today
    # end
    @end_date = session[:end]    
    
    unless params[:qry_ord].blank?
        session[:product_id] = params[:qry_ord][:product_id].to_i
        session[:customer_id] = params[:qry_ord][:customer_id].to_i
    end
    session[:product_id] ||= '0'
    session[:customer_id] ||= '0'
      
    @qry_ord = Order.new(:product_id=>session[:product_id], :customer_id=>session[:customer_id])
    
    @orders = Order.search_orders(@start_date, @end_date, @qry_ord)
    
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @orders }
    end
  end

  # GET /orders/1
  # GET /orders/1.xml
  def show
    @order = Order.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @order }
    end
  end

  # GET /orders/new
  # GET /orders/new.xml
  def new
    @order = Order.new
    @order.seq_no = get_next_id(Order)
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @order }
    end
  end

  # GET /orders/1/edit
  def edit
    @order = Order.find(params[:id])
  end

  # POST /orders
  # POST /orders.xml
  def create
    @order = Order.new(params[:order])

    respond_to do |format|
      if @order.save
        format.html { redirect_to(@order, :notice => 'Order was successfully created.') }
        format.xml  { render :xml => @order, :status => :created, :location => @order }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @order.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /orders/1
  # PUT /orders/1.xml
  def update
    @order = Order.find(params[:id])

    respond_to do |format|
      if @order.update_attributes(params[:order])
        format.html { redirect_to(@order, :notice => 'Order was successfully updated.') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @order.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /orders/1
  # DELETE /orders/1.xml
  def destroy
    @order = Order.find(params[:id])
    @order.destroy

    respond_to do |format|
      format.html { redirect_to(orders_url) }
      format.xml  { head :ok }
    end
  end
end
