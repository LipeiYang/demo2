class Supplier < ActiveRecord::Base
end
